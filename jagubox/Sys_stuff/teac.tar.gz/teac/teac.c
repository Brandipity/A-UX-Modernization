/*
 * TEAC MT-2ST/N50 cassette tape driver
 */

#include <sys/types.h>
#include <sys/vio.h>
#include <sys/scsiccs.h>
#include <sys/scsireq.h>
#include <sys/errno.h>
#include <sys/param.h>
#include <sys/ioctl.h>
#include <sys/sysmacros.h>
#include <sys/mtio.h>
#include <sys/buf.h>
#include <sys/file.h>
#include "teac.h"

#define TRUE	1
#define FALSE	0

#undef WAIT
#define WAIT	TRUE
#define NOWAIT	FALSE

#define	F_OPEN	0x01

typedef int	Boolean;

int			teacChar = SDC_RDPOLL | SDC_WRPOLL | SDC_NODISC;
Boolean			teacDebug = FALSE;
struct buf		rteacbuf;
static Boolean		lastWasWrite = FALSE;
static Boolean		fileMarkRead = FALSE;
static int		flags = 0;
static int		nretry;
static int		unit;
static struct scsireq	req;                /* scsi request packet */
static struct scsireq	sreq;                /* scsi request packet */
static u_char		cmdbuf[10];         /* cmd block for scsi commands */
static struct sense	sense;
static struct inquiry	inquiry;
static u_char		sensecmd[6] = {OP_SENSE, 0, 0, 0, sizeof(sense), 0};

void
teacCDB(op, two, n)
int	op;
int	two;
int	n;
{
	cmdbuf[0] = op;
	cmdbuf[1] = two;
	cmdbuf[2] = (n >> 16) & 0xff;
	cmdbuf[3] = (n >> 8) & 0xff;
	cmdbuf[4] = n & 0xff;
	cmdbuf[5] = 0;
}

void
teacinit()
{
	int	teacret();

	req.faddr = teacret;
	req.cmdbuf = (caddr_t) cmdbuf;
	req.sensebuf = (caddr_t) &sense;
	req.senselen = sizeof(sense);
	req.driver = (long) &rteacbuf;
	sreq.faddr = teacret;
	sreq.cmdbuf = (caddr_t) sensecmd;
	sreq.cmdlen = 6;
	sreq.databuf = (caddr_t) &sense;
	sreq.datalen = sizeof(sense);
	sreq.sensebuf = NULL;
	sreq.senselen = 0;
	sreq.flags = SRQ_READ;
	sreq.driver = (long) &rteacbuf;
	strncpy(req.revcode, REVCODE, sizeof(req.revcode));
	printf("teac: MT-2ST/N50 cassette tape driver\n");
}

int
teacopen(dev, flag, ndevp)
dev_t	dev;
int	flag;
dev_t	*ndevp;
{
	if (flags & F_OPEN) {
		printf("teacopen: already open\n");
		return(EBUSY);
	}

	unit = UNIT(dev);
	teacCDB(OP_INQUIRY, 0, sizeof(inquiry));
	if (teacCmd((caddr_t) &inquiry, sizeof(inquiry), SRQ_READ, 4, WAIT)) {
		if (teacDebug)
			printf("teacopen: INQUIRY failed\n");

		return(ENXIO);
	}

	if (
		(inquiry.type != 1) || (inquiry.rmb != 1) ||
		(inquiry.al != 31) ||
		strncmp(inquiry.vendor, "TEAC", 4) ||
		strncmp(inquiry.product, "MT-2ST/N50", 10)
	) {
		if (teacDebug)
			printf("teac: not MT-2ST/N50 (SCSI unit %dtype %d)\n",
					inquiry.type, unit);

		return(ENXIO);
	}

	teacCDB(OP_SENSE, 0, sizeof(sense));
	if (teacCmd((caddr_t) &sense, sizeof(sense), SRQ_READ, 4, WAIT)) {
		if (teacDebug)
			printf("teacopen: SENSE failed\n");

		return(ENXIO);
	}

	if (!sense.cld) {
		printf("teac: no cassette in drive\n");
		return(ENXIO);
	}

	if ((flag & FWRITE) && sense.wpt) {
		printf("teac: cassette is write protected\n");
		return(EROFS);
	}

	scsichar(unit, teacChar, -1);
	flags = F_OPEN;
	lastWasWrite = FALSE;
	fileMarkRead = FALSE;
	return(0);
}

void
teacclose(dev, flag)
dev_t	dev;
int	flag;
{
	int	n;

	if (flags & F_OPEN) {
		teacCDB(OP_SENSE, 0, sizeof(sense));
		if (teacCmd((caddr_t) &sense, sizeof(sense), SRQ_READ, 4,
				WAIT)) {
			if (teacDebug)
				printf("teacclose: SENSE failed\n");
		} else {
			/*
			 * Check data error counter for worn tape.
			 */
			n = (sense.dec[0] << 8) | sense.dec[1];
			if (teacDebug)
				printf("teacclose: data error count %d\n", n);

			if (n > 1500)
				printf("teac: WARNING: tape may be worn\n");
		}

		flags = 0;
		scsichar(unit, SDC_DISC, SDC_NODISC | SDC_DISC);
		if (lastWasWrite) {
			n = NRWD(dev) ? 1 : 2;
			teacCDB(OP_WFM, 0, n);
			(void) teacCmd(NULL, 0, 0, 10, WAIT);
		}

		if (!NRWD(dev)) {
			teacCDB(OP_REWIND, 0, 0);
			(void) teacCmd(NULL, 0, 0, 90, WAIT);
		}

	} else
		printf("teacclose: not open\n");
}

void
teacstrat(bp)
struct buf	*bp;
{
	int	blocks;
	int	cmd;
	int	flags;

	if ((blocks = bp->b_resid = bp->b_bcount) & 511) {
		bp->b_flags |= B_ERROR | B_DONE;
		bp->b_error = EINVAL;
		return;
	}

	blocks /= 512;
	if (bp->b_flags & B_READ) {
		cmd = OP_READ;
		flags = SRQ_READ;
		lastWasWrite = FALSE;

	} else {
		cmd = OP_WRITE;
		flags = 0;
		lastWasWrite = TRUE;
	}

	teacCDB(cmd, FIXED, blocks);
	(void) teacCmd(bp->b_un.b_addr, bp->b_bcount, flags,
			10 + blocks, NOWAIT);
}

int
teacread(dev, uio)
dev_t		dev;
struct uio	*uio;
{
	if (flags & F_OPEN) {
		if (fileMarkRead) {
			fileMarkRead = FALSE;
			return(0);
		}

		return(physio(teacstrat, &rteacbuf, dev, B_READ, uio));
	}
	
	return(ENXIO);
}

int
teacwrite(dev, uio)
dev_t		dev;
struct uio	*uio;
{
	if (flags & F_OPEN)
		return(physio(teacstrat, &rteacbuf, dev, B_WRITE, uio));
	
	return(ENXIO);
}

int
teacioctl(dev, cmd, addr, mode)
dev_t	dev;
int	cmd;
caddr_t	addr;
int	mode;
{
	int		ret;
	int		timeout;
	struct mtop	*mtop;

	if (!(flags & F_OPEN))
		return(ENXIO);

	switch (cmd) {
	case MTIOCTOP:
		mtop = (struct mtop *)addr;
		switch (mtop->mt_op) {
		case MTWEOF:
			teacCDB(OP_WFM, 0, mtop->mt_count);
			timeout = 10;
			break;

		case MTFSF:
			teacCDB(OP_SPACE, FILEMARKS, mtop->mt_count);
			timeout = 90;
			break;

		case MTFSR:
			teacCDB(OP_SPACE, BLOCKS, mtop->mt_count);
			timeout = 90;
			break;
			
		case MTREW:
			teacCDB(OP_REWIND, 0, 0);
			timeout = 90;
			break;

		case MTOFFL:
			teacCDB(OP_REWIND, IMMEDIATE, 0);
			timeout = 4;
			break;

		case MTRETEN:
			teacCDB(OP_PREWIND, 0, 0);
			timeout = 180;
			break;
			
		case MTFORMAT:
			teacCDB(OP_ERASE, 1, 0);
			timeout = 180;
			break;
			
		default:
			return(EINVAL);
		}

		scsichar(unit, SDC_DISC, SDC_NODISC | SDC_DISC);
		ret = teacCmd(NULL, 0, 0, timeout, WAIT);
		scsichar(unit, SDC_NODISC, SDC_NODISC | SDC_DISC);
		break;

	default:
		ret = EINVAL;
		break;
	}

	return(ret);
}

int
teacCmd(buf, len, flags, timeout, wait)
caddr_t	buf;
int	len;
int	flags;
int	timeout;
Boolean	wait;
{
	struct buf	*bp;

	/*if (teacDebug)
		printf("teacCmd(%x, %x, %d, %x, %d, %d)\n",
				cmdbuf[0], buf, len, flags, timeout, wait);*/
	req.cmdlen = 6;
	req.databuf = buf;
	req.datalen = len;
	req.flags = flags;
	req.timeout = timeout;
	bp = (struct buf *) req.driver;
	bp->b_flags &= ~(B_DONE | B_ERROR);
	bp->b_error = 0;
	nretry = 0;
	if (scsireq(unit, &req, NULL) != 0) {
		if (teacDebug)
			printf("teacCmd scsireq: ret %d %s\n", req.ret,
					scsi_strings[req.ret]);

		bp->b_flags |= B_DONE | B_ERROR;
		return(EIO);
	}

	if (wait)
		biowait(bp);

	return(bp->b_error);
}

static char *codestr[] = {
	"NO SENSE", "?", "NOT READY", "MEDIUM ERROR", "HARDWARE ERROR",
	"ILLEGAL REQUEST", "UNIT ATTENTION", "DATA PROTECT", "NO DATA",
	"?", "?", "ABORTED COMMAND", "?", "VOLUME OVERFLOW", "?", "?"
};

int
teacCheckSense(s, bp)
struct sense	*s;
struct buf	*bp;
{
	switch (s->key) {
	case S_NOSENSE:
		fileMarkRead = s->fmk;
		if (s->eom) {
			bp->b_flags |= B_ERROR;
			bp->b_error = ENOSPC;
		}

		bp->b_resid = ((s->info[0] << 24) | (s->info[1] << 16) |
				(s->info[2] << 8) | s->info[3]) * 512;
		return(FALSE);

	case S_MEDERROR:
		printf("teac: unrecovered medium error!\n");
		bp->b_error = EIO;
		break;

	case S_HDERROR:
		printf("teac: hardware error!\n");
		bp->b_error = EIO;
		break;

	case S_VOLOVER:
		printf("teac: cassette full\n");
		bp->b_error = ENOSPC;
		break;

	case S_DATAPROTECT:
		printf("teac: cassette is write protected\n");
		bp->b_error = EROFS;
		break;

	case S_NODATA:
		printf("teac: blank cassette?\n");
		bp->b_error = EIO;
		break;

	default:
		printf("teac: SCSI unhandled sense for op %x:\n", cmdbuf[0]);
		printf("\tvalid %d class %d code %d: %s\n", s->valid, s->class,
				s->code, codestr[s->code]);
		printf("\tsegment %d fmk %d eom %d ili %d key %x\n", s->segment,
				s->fmk, s->eom, s->ili, s->key);
		printf("\tinfo %x %x %x %x asl %d\n", s->info[0],
				s->info[1], s->info[2], s->info[3], s->asl);
		printf("\tmfault %d stall %d hole %d parity %d\n", s->mfault,
				s->stall, s->hole, s->parity);
		printf("\tcld %d wpt %d bom %d run %d strm %d ident %d\n",
				s->cld, s->wpt, s->bom, s->run,
				s->strm, s->ident);

		bp->b_error = EIO;
		break;
	}

	bp->b_flags |= B_ERROR;
	return(FALSE);
}

int
teactimer(arg)
caddr_t	arg;
{
	if (scsireq(unit, &req, NULL) != 0) {
		struct buf	*bp = (struct buf *) req.driver;

		printf("teac: teactimer scsireq: %s\n", scsi_strings[req.ret]);
		bp->b_flags |= B_ERROR;
		bp->b_error = EIO;
		biodone(bp);
	}

	return(0);
}

int
teacret(req)
struct scsireq	*req;
{
	struct buf	*bp = (struct buf *) req->driver;

	if (teacDebug && (req->ret || req->stat || req->msg))
		printf("teacret: ret = %d msg = %x stat = %x datasent %d sensesent %d\n",
				req->ret, req->msg, req->stat, req->datasent,
				req->sensesent);

	if (req == &sreq)
		req->ret = SST_STAT;

	switch (req->ret) {
	case 0:
		bp->b_resid = 0;
		break;

	case SST_STAT:
		if (!teacCheckSense(&sense, bp))
			break;

		/* FALL THROUGH */

	case SST_AGAIN:
		if (++nretry < 10) {
			/*if (teacDebug)*/
				printf("teac: retrying\n");

			timeout(teactimer, 0, HZ / 10 * 2);
			return(0);
		}

		printf("teac: retries exhausted\n");
		bp->b_flags |= B_ERROR;
		bp->b_error = EIO;
		break;

	case SST_MORE:
		if (scsireq(unit, &sreq, NULL) == 0)
			return(0);

		printf("teac: SST_MORE sense failure ret %d %s\n",
				sreq.ret, scsi_strings[sreq.ret]);
		bp->b_flags |= B_ERROR;
		bp->b_error = EIO;
		break;

	case SST_SEL:
		printf("teac: no response from SCSI ID %d\n", unit);
		bp->b_flags |= B_ERROR;
		bp->b_error = ENXIO;
		break;

	default:
		printf("teac: unhandled scsireq ret %d: %s\n", req->ret,
				scsi_strings[req->ret]);
		printf("teac: msg = %x stat = %x datasent %d sensesent %d\n",
				req->msg, req->stat, req->datasent,
				req->sensesent);
		bp->b_flags |= B_ERROR;
		bp->b_error = EIO;
		break;
	}

	biodone(bp);
	return(0);
}

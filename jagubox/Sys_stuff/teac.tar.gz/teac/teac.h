/*
 * TEAC MT-2ST/N50 cassette tape driver
 */

#define UNIT(x)	(minor(x) & 7)
#define NRWD(x)	(minor(x) & 8)

#define OP_READY	0x00	/* test unit ready */
#define OP_REWIND	0x01	/* rewind */
#define OP_ERAALT	0x02	/* erase (alternate) */
#define OP_SENSE	0x03	/* request sense */
#define OP_RBL		0x05	/* read block limits */
#define OP_RAS		0x06	/* request auxiliary sense */
#define OP_READ		0x08	/* read */
#define OP_WRITE	0x0a	/* write */
#define OP_WFM		0x10	/* write file marks */
#define OP_SPACE	0x11	/* space */
#define OP_INQUIRY	0x12	/* inquiry */
#define OP_RBD		0x14	/* read buffered data */
#define OP_MODESEL	0x15	/* mode select */
#define OP_RESERVE	0x16	/* reserve unit */
#define OP_RELEASE	0x17	/* release unit */
#define OP_ERASE	0x19	/* erase */
#define OP_MODESEN	0x1a	/* mode sense */
#define OP_PREWIND	0x1b	/* prewind */
#define OP_LOCK		0x1e	/* lock cassette (light LED) */

#define S_NOSENSE	0x0
#define S_NOTREADY	0x2
#define S_MEDERROR	0x3
#define S_HDERROR	0x4
#define S_ILLREQ	0x5
#define S_UNITATTN	0x6
#define S_DATAPROTECT	0x7
#define S_NODATA	0x8
#define S_ABORTED	0xb
#define S_VOLOVER	0xd

#define IMMEDIATE	1
#define WAIT		0

#define FIXED		1
#define VARIABLE	0

#define BLOCKS		0
#define FILEMARKS	1
#define SEQFM		2	/* sequential file marks */
#define EOD		3	/* physical end of data */

struct sense {
	unsigned char	valid:1;
	unsigned char	class:3;
	unsigned char	code:4;
	unsigned char	segment;
	unsigned char	fmk:1;
	unsigned char	eom:1;
	unsigned char	ili:1;
	unsigned char	rsvd0:1;
	unsigned char	key:4;
	unsigned char	info[4];
	unsigned char	asl;
	unsigned char	rsvd1[10];
	unsigned char	rsvd2:4;
	unsigned char	mfault:1;
	unsigned char	stall:1;
	unsigned char	hole:1;
	unsigned char	parity:1;
	unsigned char	rsvd3;
	unsigned char	cld:1;
	unsigned char	wpt:1;
	unsigned char	bom:1;
	unsigned char	run:1;
	unsigned char	strm:1;
	unsigned char	ident:3;
	unsigned char	dec[2];
	unsigned char	uc[2];
	unsigned char	cba[4];
	unsigned char	ebc[2];
	unsigned char	tpc[2];
	unsigned char	cebc[2];
	unsigned char	tdec[17];
};

struct inquiry {
	unsigned char	type;
	unsigned char	rmb:1;
	unsigned char	qualifier:7;
	unsigned char	isov:2;
	unsigned char	ecmav:3;
	unsigned char	ansiv:3;
	unsigned char	rsvd1;
	unsigned char	al;
	unsigned char	rsvd2[3];
	unsigned char	vendor[8];
	unsigned char	product[16];
	unsigned char	revision[4];
};

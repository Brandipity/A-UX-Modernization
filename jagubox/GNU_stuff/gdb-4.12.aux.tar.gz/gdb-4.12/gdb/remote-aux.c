/* Remote target communications for an A/UX kernel in modified GDB protocol *

This program is a derivative work of remote.c, and as such is copyright by
John L. Coolidge and the FSF. It is covered by the GPL.

This file is part of GDB.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

/* The remote communication protocol is as documented in remote.c except
   for the following additions.

   All values are encoded in ascii hex digits.

	Request		Packet
	breakpoint	BAA..AA[,DDDD]
					AA..AA is address,
					DDDD is the old contents of the
					address. If DDDD is omitted, the
					address is set to a breakpoint
	reply		XXXX		the former contents of the address,
					if DDDD is omitted.
			OK		if DDDD was specified and the breakpoint
					was successfully set
			ENN		for an error

	extended cmd	Xcmd[,ARGS...]
					cmd is an extended command
	reply		XX..XX		XX.XX and so forth are strings
			YY..YY		giving the output of the extended
			...		command. Output is terminated by
			OK		an 'OK' value
			ENN		for an error

*/

#include "defs.h"
#include <string.h>
#include <fcntl.h>
#include "frame.h"
#include "inferior.h"
#include "target.h"
#include "wait.h"
#include "terminal.h"
#include "gdbcmd.h"

#if !defined(DONT_USE_REMOTE)
#ifdef USG
#include <sys/types.h>
#endif

#include <signal.h>

#ifndef HAVE_TERMIO
extern int alarm ();			/* Many systems don't declare it */
#endif

/* Prototypes for local functions */

static int
remote_aux_insert_breakpoint PARAMS ((CORE_ADDR, char *));

static int
remote_aux_remove_breakpoint PARAMS ((CORE_ADDR, char *));

extern struct target_ops remote_aux_ops;	/* Forward decl */
extern struct target_ops remote_ops;

static void        (*remote_open_fn) PARAMS ((char *, int));

#define PBUFSIZ 1024

remote_aux_open (name, from_tty)
     char *name;
     int from_tty;
{
	(*remote_open_fn)(name, from_tty);

	if (current_target == &remote_ops)
	{
		current_target = current_target->to_next;
		push_target (&remote_aux_ops);
	}
}

static void
remote_aux_mourn ()
{
  unpush_target (&remote_aux_ops);
  generic_mourn_inferior ();
}

/* install a breakpoint on the remote machine */

static int
remote_aux_insert_breakpoint(addr, contents_cache)
     CORE_ADDR addr;
     char *contents_cache;
{
  char buf[PBUFSIZ];
  int i;
  char *p;

  sprintf (buf, "B%x", addr);

  remote_send (buf);

  /* reply indicates the old value */

  p = buf;
  for (i = 0; i < 2; i++)
    {
      if (p[0] == 0 || p[1] == 0)
	error ("Remote reply is too short: %s", buf);
      contents_cache[i] = fromhex (p[0]) * 16 + fromhex (p[1]);
      p += 2;
    }
  return 0;
}

/* remove a breakpoint */

static int
remote_aux_remove_breakpoint(addr, contents_cache)
     CORE_ADDR addr;
     char *contents_cache;
{
  char buf[PBUFSIZ];
  int i;
  char *p;

  sprintf (buf, "B%x,%04x", addr, *(unsigned short*)contents_cache);
  remote_send (buf);
  return 0;
}

/* Send an extended command to the target system. Prints out the results. */
static int
remote_aux_extended(command)
char * command;
{
   char buf[PBUFSIZ];

   sprintf (buf, "X%s", command);
   remote_send (buf);

   if (*buf == 'E')
       error ("extended command %s got an error %s\n", command, buf);

   while (*buf && strncmp(buf, "OK", 2)) {
       puts_filtered(buf);
       puts_filtered("\n");
       getpkt(buf,0);
   }
}
struct target_ops remote_aux_ops = {
  "aux-kernel",			/* to_shortname */
  "Remote serial target in A/UX kernel gdb protocol",	/* to_longname */
  "Debug an A/UX kernel via a serial line, using modified gdb protocol.\n\
Specify the serial device it is connected to (e.g. /dev/ttya).",  /* to_doc */
  remote_aux_open,		/* to_open */
  NULL,				/* to_close */
  NULL,				/* to_attach */
  NULL,				/* to_detach */
  NULL,				/* to_resume */
  NULL,				/* to_wait */
  NULL,				/* to_fetch_registers */
  NULL,				/* to_store_registers */
  NULL,				/* to_prepare_to_store */
  NULL,				/* to_xfer_memory */
  NULL,				/* to_files_info */
  remote_aux_insert_breakpoint,	/* to_insert_breakpoint */
  remote_aux_remove_breakpoint,	/* to_remove_breakpoint */
  NULL,				/* to_terminal_init */
  NULL,				/* to_terminal_inferior */
  NULL,				/* to_terminal_ours_for_output */
  NULL,				/* to_terminal_ours */
  NULL,				/* to_terminal_info */
  NULL,				/* to_kill */
  NULL,				/* to_load */
  NULL,				/* to_lookup_symbol */
  NULL,				/* to_create_inferior */
  remote_aux_mourn,		/* to_mourn_inferior */
  0,				/* to_can_run */
  0,				/* to_notice_signals */
  process_stratum,		/* to_stratum */
  NULL,				/* to_next */
  1,				/* to_has_all_memory */
  1,				/* to_has_memory */
  1,				/* to_has_stack */
  1,				/* to_has_registers */
  1,				/* to_has_execution */
  NULL,				/* sections */
  NULL,				/* sections_end */
  OPS_MAGIC			/* to_magic */
};

void
_initialize_remote_aux ()
{
  /* This function depends on _initialize_remote being called first */
  remote_aux_ops.to_close = remote_ops.to_close;
  remote_aux_ops.to_detach = remote_ops.to_detach;
  remote_aux_ops.to_resume = remote_ops.to_resume;
  remote_aux_ops.to_wait = remote_ops.to_wait;
  remote_aux_ops.to_fetch_registers = remote_ops.to_fetch_registers;
  remote_aux_ops.to_store_registers = remote_ops.to_store_registers;
  remote_aux_ops.to_prepare_to_store = remote_ops.to_prepare_to_store;
  remote_aux_ops.to_xfer_memory = remote_ops.to_xfer_memory;
  remote_aux_ops.to_files_info = remote_ops.to_files_info;
  remote_aux_ops.to_kill = remote_ops.to_kill;

  add_target (&remote_aux_ops);

  add_com ("extended", no_class, remote_aux_extended,
  	"Send an extended command to the remote host.\n");

  remote_open_fn = remote_ops.to_open;
}
#endif /* DONT_USE_REMOTE */

/* Definitions for all PA machines.  */

/* This was created for "makeva", which is obsolete.  This file can
   probably go away (unless someone can think of some other host thing
   which is common to various pa machines).  */

/* Parameters for execution on an HP PA-RISC machine running BSD, for GDB.
   Contributed by the Center for Software Science at the
   University of Utah (pa-gdb-bugs@cs.utah.edu).  */

/* It's all just the common stuff.  */
#include "pa/tm-hppa.h"

/* Parameters for execution on Apple A/UX, for GDB, the GNU debugger.
   Copyright (C) 1992 Thomas Eberhardt (thomas@mathematik.uni-Bremen.de)

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

/* Define HAVE_68881 if that is the case.  */

#define HAVE_68881

/* Define BPT_VECTOR if it is different than the default.
   This is the vector number used by traps to indicate a breakpoint. */

#define BPT_VECTOR 0x1

/* Are we currently handling a signal */

#define IN_SIGTRAMP(pc, name) \
 name && *name == '_' && !strcmp ("_sigcode", name)

/* If your kernel resets the pc after the trap happens you may need to
   define this before including this file.  */

#define DECR_PC_AFTER_BREAK 0

/* Extract from an array REGBUF containing the (raw) register state
   a function return value of type TYPE, and copy that, in virtual format,
   into VALBUF.  This is assuming that floating point values are returned
   as doubles in fp0.  */

#define EXTRACT_RETURN_VALUE(TYPE,REGBUF,VALBUF) \
  { if (TYPE_CODE (TYPE) == TYPE_CODE_FLT) \
      { \
	REGISTER_CONVERT_TO_VIRTUAL (FP0_REGNUM, \
				REGISTER_VIRTUAL_TYPE (FP0_REGNUM), \
				&REGBUF[REGISTER_BYTE (FP0_REGNUM)], \
				VALBUF); \
      } \
    else \
      memcpy (VALBUF, REGBUF, TYPE_LENGTH (TYPE)); }

/* Write into appropriate registers a function return value
   of type TYPE, given in virtual format.  Assumes floats are passed
   in fp0.  */

#define STORE_RETURN_VALUE(TYPE,VALBUF) \
  { if (TYPE_CODE (TYPE) == TYPE_CODE_FLT) \
      { \
	char raw_buf[REGISTER_RAW_SIZE (FP0_REGNUM)]; \
	REGISTER_CONVERT_TO_RAW (REGISTER_VIRTUAL_TYPE (FP0_REGNUM), \
				 FP0_REGNUM, VALBUF, raw_buf); \
	write_register_bytes (FP0_REGNUM, \
			      raw_buf, REGISTER_RAW_SIZE (FP0_REGNUM)); \
      } \
    else \
      write_register_bytes (0, VALBUF, TYPE_LENGTH (TYPE)); }

/* Needed for child_xfer_memory in aux-xdep.c */

#define NEED_TEXT_START_END

/* We don't have this */
#define NO_PTRACE_H

#define JB_ELEMENT_SIZE 4

#define JB_D2 0
#define JB_D3 1
#define JB_D4 2
#define JB_D5 3
#define JB_D6 4
#define JB_D7 5
#define JB_PC 6
#define JB_A2 7
#define JB_A3 8
#define JB_A4 9
#define JB_A5 10
#define JB_A6 11
#define JB_A7 12
#define JB_SIGMASK 13

/* Figure out where the longjmp will land.  Slurp the args out of the stack.
   We expect the first arg to be a pointer to the jmp_buf structure from which
   we extract the pc (JB_PC) that we will land at.  The pc is copied into ADDR.
   This routine returns true on success */

#define GET_LONGJMP_TARGET(ADDR) get_longjmp_target(ADDR)

#include "m68k/tm-m68k.h"

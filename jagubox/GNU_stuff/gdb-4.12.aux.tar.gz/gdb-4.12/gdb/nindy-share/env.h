/* Copyright 1990, 1992 Free Software Foundation, Inc.
 *
 * This code was donated by Intel Corp.
 * 
 * GNU/960 tool runtime environment
 */


/* Base directory at which GNU/960 tools are assumed to be installed, if
 * the environment variable G960BASE is not defined.
 */
#define DEFAULT_BASE	"/usr/local/g960"

/* Host-dependent code for Apple A/UX for GDB, the GNU debugger.
   Copyright (C) 1992 Thomas Eberhardt (thomas@mathematik.uni-Bremen.de)

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

#include <stdio.h>
#include "defs.h"
#include "inferior.h"
#include "gdbcore.h"
#include "target.h"

#include <sys/types.h>
#include <sys/reg.h>
#include <sys/param.h>
#include <sys/time.h>
#include <sys/user.h>

extern int errno;

#define PT_READ_I	1
#define	PT_READ_D	2
#define PT_READ_U	3
#define PT_WRITE_I	4
#define PT_WRITE_D	5
#define PT_WRITE_U	6
#define PT_CONTINUE	7
#define PT_KILL		8
#define PT_STEP		9
#define PT_READ_R	10
#define PT_WRITE_R	11
#ifdef ATTACH_DETACH
#define PT_ATTACH	12
#define PT_DETACH	13
#endif

#ifndef PT_ATTACH
#define PT_ATTACH PTRACE_ATTACH
#endif
#ifndef PT_DETACH
#define PT_DETACH PTRACE_DETACH
#endif


/* This function simply calls ptrace with the given arguments.  
   It exists so that all calls to ptrace are isolated in this 
   machine-dependent file. */
int
call_ptrace (request, pid, addr, data)
     int request, pid;
     PTRACE_ARG3_TYPE addr;
     int data;
{
  return ptrace (request, pid, addr, data);
}

#ifdef DEBUG_PTRACE
/* For the rest of the file, use an extra level of indirection */
/* This lets us breakpoint usefully on call_ptrace. */
#define ptrace call_ptrace
#endif

/* This is used when GDB is exiting.  It gives less chance of error.*/

void
kill_inferior_fast ()
{
  if (inferior_pid == 0)
    return;
  ptrace (PT_KILL, inferior_pid, (PTRACE_ARG3_TYPE) 0, 0);
  wait ((int *)0);
}

void
kill_inferior ()
{
  kill_inferior_fast ();
  target_mourn_inferior ();
}

/* Resume execution of the inferior process.
   If STEP is nonzero, single-step it.
   If SIGNAL is nonzero, give it that signal.  */

void
child_resume (pid, step, signal)
     int pid;
     int step;
     enum target_signal signal;
{
  errno = 0;

  if (pid == -1)
    pid = inferior_pid;

  /* An address of (PTRACE_ARG3_TYPE) 1 tells ptrace to continue from where
     it was. (If GDB wanted it to start some other way, we have already
     written a new PC value to the child.)  */

  if (step)
    ptrace (PT_STEP, pid, (PTRACE_ARG3_TYPE) 1,
	    target_signal_to_host(signal));
  else
    ptrace (PT_CONTINUE, pid, (PTRACE_ARG3_TYPE) 1,
	    target_signal_to_host(signal));

  if (errno)
    perror_with_name ("ptrace");
}

#ifdef ATTACH_DETACH
/* Start debugging the process whose number is PID.  */
int
attach (pid)
     int pid;
{
  errno = 0;
  ptrace (PT_ATTACH, pid, (PTRACE_ARG3_TYPE) 0, 0);
  if (errno)
    perror_with_name ("ptrace");
  attach_flag = 1;
  return pid;
}

/* Stop debugging the process whose number is PID
   and continue it with signal number SIGNAL.
   SIGNAL = 0 means just continue it.  */

void
detach (signal)
     int signal;
{
  errno = 0;
  ptrace (PT_DETACH, inferior_pid, (PTRACE_ARG3_TYPE) 1, signal);
  if (errno)
    perror_with_name ("ptrace");
  attach_flag = 0;
}
#endif /* ATTACH_DETACH */
           
void
fetch_register (int regno)
{
  register unsigned int regaddr;
  char buf[MAX_REGISTER_RAW_SIZE];
  register int i;

  if (regno < FP0_REGNUM)
    *(int *) &buf[0] =
      ptrace (PT_READ_R, inferior_pid,
	      (PTRACE_ARG3_TYPE) (regno < PS_REGNUM ? regno
				  : (regno == PS_REGNUM ? 17 : 16)), 0);
  else
    {
      regaddr = FP_REGISTER_ADDR (regno);
      for (i = 0; i < REGISTER_RAW_SIZE (regno); i += sizeof (int))
	{
	  *(int *) &buf[i] = ptrace (PT_READ_U, inferior_pid,
				     (PTRACE_ARG3_TYPE) regaddr, 0);
	  regaddr += sizeof (int);
	}
    }
  supply_register (regno, buf);
}

void
fetch_inferior_registers (regno)
     int regno;
{
  if (regno == -1)
    for (regno = 0; regno < NUM_REGS; regno++)
      fetch_register (regno);
  else
    fetch_register (regno);
}

void
store_inferior_registers (regno)
     int regno;
{
  register unsigned int regaddr;
  char buf[80];

  if (regno >= 0)
    {
      errno = 0;
      if (regno < FP0_REGNUM)
        ptrace (PT_WRITE_R, inferior_pid,
		(PTRACE_ARG3_TYPE) (regno < PS_REGNUM ? regno
				    : (regno == PS_REGNUM ? 17 : 16)),
		read_register (regno));
      else
	{
	  int i;
          regaddr = FP_REGISTER_ADDR (regno);
	  for (i = 0; i < REGISTER_RAW_SIZE(regno); i += sizeof(int))
	    {
	      errno = 0;
              ptrace (PT_WRITE_U, inferior_pid,
		  (PTRACE_ARG3_TYPE) regaddr, *(int *)
			&registers[REGISTER_BYTE (regno) + i]);
	      if (errno != 0)
	        {
		  sprintf (buf, "writing register number %d(%d)", regno, i);
		  perror_with_name (buf);
		}
              regaddr += sizeof(int);
            }
	}
      if (errno != 0)
	{
	  sprintf (buf, "writing register number %d", regno);
	  perror_with_name (buf);
	}
    }
  else
    {
      for (regno = 0; regno < NUM_REGS; regno++)
	{
	  errno = 0;

	  if (regno < FP0_REGNUM)
	    ptrace (PT_WRITE_R, inferior_pid,
		    (PTRACE_ARG3_TYPE) (regno < PS_REGNUM ? regno
					: (regno == PS_REGNUM ? 17 : 16)),
		    read_register (regno));
	  else
	    {
	      int i;
              regaddr = FP_REGISTER_ADDR (regno);
	      for (i = 0; i < REGISTER_RAW_SIZE(regno); i += sizeof(int))
	        {
	          errno = 0;
                  ptrace (PT_WRITE_U, inferior_pid,
		      (PTRACE_ARG3_TYPE) regaddr, *(int *)
			    &registers[REGISTER_BYTE (regno) + i]);
	          if (errno != 0)
	            {
		      sprintf (buf, "writing register number %d(%d)", regno, i);
		      perror_with_name (buf);
		    }
                  regaddr += sizeof(int);
                }
            }
	  if (errno != 0)
	    {
	      sprintf (buf, "writing all regs, number %d", regno);
	      perror_with_name (buf);
	    }
	}
    }
}

int
child_xfer_memory (memaddr, myaddr, len, write, target)
     CORE_ADDR memaddr;
     char *myaddr;
     int len;
     int write;
     struct target_ops *target;		/* ignored */
{
  register int i;
  /* Round starting address down to longword boundary.  */
  register CORE_ADDR addr = memaddr & - sizeof (int);
  /* Round ending address up; get number of longwords that makes.  */
  register int count
    = (((memaddr + len) - addr) + sizeof (int) - 1) / sizeof (int);
  /* Allocate buffer of that many longwords.  */
  register int *buffer = (int *) alloca (count * sizeof (int));
  int pt_read, pt_write;
  extern CORE_ADDR text_start, text_end;

  /* A/UX distinguishes between text and data space accesses */
  pt_read = addr >= text_start && addr < text_end ? PT_READ_I : PT_READ_D;
  pt_write = addr >= text_start && addr < text_end ? PT_WRITE_I : PT_WRITE_D;

  if (write)
    {
      /* Fill start and end extra bytes of buffer with existing memory data.  */

      if (addr != memaddr || len < (int)sizeof (int)) {
	/* Need part of initial word -- fetch it.  */
        buffer[0] = ptrace (pt_read, inferior_pid, (PTRACE_ARG3_TYPE) addr,
			    0);
      }

      if (count > 1)		/* FIXME, avoid if even boundary */
	{
	  buffer[count - 1]
	    = ptrace (pt_read, inferior_pid,
		      (PTRACE_ARG3_TYPE) (addr + (count - 1) * sizeof (int)),
		      0);
	}

      /* Copy data to be written over corresponding part of buffer */

      memcpy ((char *) buffer + (memaddr & (sizeof (int) - 1)), myaddr, len);

      /* Write the entire buffer.  */

      for (i = 0; i < count; i++, addr += sizeof (int))
	{
	  errno = 0;
	  ptrace (pt_write, inferior_pid, (PTRACE_ARG3_TYPE) addr,
		  buffer[i]);
	  if (errno)
	    return 0;
	}
    }
  else
    {
      /* Read all the longwords */
      for (i = 0; i < count; i++, addr += sizeof (int))
	{
	  errno = 0;
	  buffer[i] = ptrace (pt_read, inferior_pid,
			      (PTRACE_ARG3_TYPE) addr, 0);
	  if (errno)
	    return 0;
	  QUIT;
	}

      /* Copy appropriate bytes out of the buffer.  */
      memcpy (myaddr, (char *) buffer + (memaddr & (sizeof (int) - 1)), len);
    }
  return len;
}

void
fetch_core_registers (core_reg_sect, core_reg_size, which, reg_addr)
     char *core_reg_sect;
     unsigned core_reg_size;
     int which;
     unsigned reg_addr;
{
  register int regno;
  register unsigned int addr;
  int bad_reg = -1;
  register reg_ptr = -reg_addr;		/* Original u.u_ar0 is -reg_addr. */

  for (regno = 0; regno < FP0_REGNUM; regno++)
    {
      addr = REGISTER_ADDR (reg_ptr, regno);
      if (addr >= core_reg_size)
	{
	  if (bad_reg < 0)
	    bad_reg = regno;
	}
      else
	supply_register (regno, core_reg_sect + addr);
    }
  for (; regno < NUM_REGS; regno++)
    {
      addr = FP_REGISTER_ADDR (regno);
      if (addr >= core_reg_size)
	{
	  if (bad_reg < 0)
	    bad_reg = regno;
	}
      else
	supply_register (regno, core_reg_sect + addr);
    }
  if (bad_reg >= 0)
    error ("Register %s not found in core file.", reg_names[bad_reg]);
}

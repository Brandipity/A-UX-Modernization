/* Configuration for GCC for Intel i386 running System V Release 3.  */

#include "i386/xm-i386.h"
#include "xm-svr3.h"

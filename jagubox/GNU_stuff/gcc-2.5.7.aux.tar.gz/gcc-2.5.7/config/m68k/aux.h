/* Definitions of target machine for GNU compiler.
   Copyright (C) 1987, 1988, 1982 Free Software Foundation, Inc.
   Contributed by John L. Coolidge (coolidge@cs.uiuc.edu, coolidge@apple.com)
   
   This file supports gcc 2.0 on A/UX using the GNU gas assembler.

   Rewritten for A/UX 2.0.1 by John L. Coolidge (coolidge@cs.uiuc.edu).
   Thanks to David W. Berry, formerly of Apple, for the first version of
   these patches, which served for many years.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/* 68020 plus 68881 */
#define TARGET_DEFAULT 7

#include "m68k/m68k.h"

#define CPP_PREDEFINES \
"-Dunix -Dm68k -DAUX -DmacII"

#define CPP_SPEC \
"%{!msoft-float:%{!ansi:-Dmc68881 }-D__HAVE_68881__ }\
%{!mc68000:%{!m68000:-Dmc68020 }}\
%{!ansi:-D__STDC__=2 }\
%{sbsd:-D_BSD_SOURCE -DBSD }%{ZB:-D_BSD_SOURCE -DBSD }\
%{ssysv:-D_SYSV_SOURCE -DSYSV -DUSG }%{ZS:-D_SYSV_SOURCE -DSYSV -DUSG }\
%{sposix:-D_POSIX_SOURCE -DPOSIX }%{ZP:-D_POSIX_SOURCE -DPOSIX }\
%{saux:-D_AUX_SOURCE }%{ZA:-D_AUX_SOURCE }\
%{!sbsd:%{!ZB:%{!ssysv:%{!ZS:%{!sposix:%{!ZP:\
-D_BSD_SOURCE -D_AUX_SOURCE -D_SYSV_SOURCE }}}}}}"

#define LINK_SPEC "%{!nostdlib:-L/usr/local/lib -L/usr/local/Gnu/lib }"

#define LIB_SPEC "%{smac:low.o%s }%{p:-L/lib/libp }%{pg:-L/lib/libp }\
%{sbsd:-lbsd }%{ZB:-lbsd }\
%{ssysv:-lsvid }%{ZS:-lsvid }\
%{sposix:-lposix }%{ZP:-lposix }\
%{static:%{smac:-lmac -lat -lld -lmr }-lc }\
%{!static:%{smac:-lmac_s -lat -lld -lmr }-lc_s } crtn.o%s"

#define STARTFILE_SPEC \
"%{pg:gcrt0.o%s }%{!pg:%{p:mcrt0.o%s }%{!p:%{smac:maccrt0.o%s }\
%{!smac:crt1.o%s }}}\
crt2.o%s -u exit -u main libgcc.a%s"

#define ENDFILE_SPEC "%{smac:low.ld%s }%{!smac:shlib.ld%s }"

#define NM_FLAGS ""
#define NO_SYS_SIGLIST

#undef SIZE_TYPE
#define SIZE_TYPE "unsigned int"

/* We want SDB format for use with gdb-4.x under COFF.  */

#define SDB_DEBUGGING_INFO

/* We use collect2, not the GNU ld. Not needed here in 2.4.x
#define USE_COLLECT2
*/

/* Use native COFF support in collect2 */
#ifdef COLLECT
#define OBJECT_FORMAT_COFF
#define MY_ISCOFF(magic) ((magic) == MC68MAGIC)
#endif

/* Every structure or union's size must be a multiple of 2 bytes.  */

#define STRUCTURE_SIZE_BOUNDARY 16

/* Generate calls to memcpy, memcmp and memset, as opposed to bcopy, bcmp,
   and bzero */
#define TARGET_MEM_FUNCTIONS

/* We're trying to support pascal stuff under A/UX */
#define AUX_PASCAL_SUPPORT

#undef REGISTER_PREFIX
#undef LOCAL_LABEL_PREFIX
#undef USER_LABEL_PREFIX
#undef REGISTER_NAMES

#define REGISTER_PREFIX "%"
#define LOCAL_LABEL_PREFIX "."
#define USER_LABEL_PREFIX ""

#undef REGISTER_NAMES
#define REGISTER_NAMES \
{"%d0", "%d1", "%d2", "%d3", "%d4", "%d5", "%d6", "%d7",        \
 "%a0", "%a1", "%a2", "%a3", "%a4", "%a5", "%a6", "%sp",        \
 "%fp0", "%fp1", "%fp2", "%fp3", "%fp4", "%fp5", "%fp6", "%fp7" }

#define ASM_RETURN_CASE_JUMP   return "jmp %%pc@(2,%0:w)"

/* For compatibility with the large body of existing code which does not
   always properly declare external functions returning pointer types, the
   A/UX convention is to copy the value returned for pointer functions
   from a0 to d0 in the function epilogue, so that callers that have
   neglected to properly declare the callee can still find the correct return
   value. */

#define FUNCTION_EXTRA_EPILOGUE(FILE, SIZE)                             \
{ extern int current_function_returns_pointer;                          \
  if ((current_function_returns_pointer) &&                             \
      ! find_equiv_reg (0, get_last_insn (), 0, 0, 0, 8, Pmode))        \
    asm_fprintf (FILE, "\tmovl %Ra0,%Rd0\n");                          \
}

/* We call a different function for profiling (mcount_, which is actually
   a glue routine which calls A/UX's mcount%, which gas cannot generate). */

#undef FUNCTION_PROFILER
#define FUNCTION_PROFILER(FILE, LABELNO)  \
  asm_fprintf (FILE, "\tlea %LLP%d,%Ra0\n\tjsr mcount_\n", (LABELNO))

#undef FUNCTION_VALUE
#undef LIBCALL_VALUE
#undef FUNCTION_VALUE_REGNO_P

/* Define how to generate (in the callee) the output value of a function
   and how to find (in the caller) the value returned by a function.  VALTYPE
   is the data type of the value (as a tree).  If the precise function being
   called is known, FUNC is its FUNCTION_DECL; otherwise, FUNC is 0.
   For A/UX generate the result in d0, a0, or fp0 as appropriate. */

#undef FUNCTION_VALUE
#define FUNCTION_VALUE(VALTYPE, FUNC)                                   \
  (TREE_CODE (VALTYPE) == REAL_TYPE && TARGET_68881                     \
   ? gen_rtx (REG, TYPE_MODE (VALTYPE), 16)                             \
   : (TREE_CODE (VALTYPE) == POINTER_TYPE                               \
      ? gen_rtx (REG, TYPE_MODE (VALTYPE), 8)                           \
      : gen_rtx (REG, TYPE_MODE (VALTYPE), 0)))
                    
#define LIBCALL_VALUE(MODE) \
 gen_rtx (REG, (MODE), ((TARGET_68881 && ((MODE) == SFmode || (MODE) == DFmode)) ? 16 : 0))

/* 1 if N is a possible register number for a function value.
   For A/UX allow d0, a0, or fp0 as return registers, for integral,
   pointer, or floating types, respectively. Reject fp0 if not using a
   68881 coprocessor. */

#undef FUNCTION_VALUE_REGNO_P
#define FUNCTION_VALUE_REGNO_P(N) \
  ((N) == 0 || (N) == 8 || (TARGET_68881 && (N) == 16))

/* Define this to be true when FUNCTION_VALUE_REGNO_P is true for
   more than one register.  */

#undef NEEDS_UNTYPED_CALL
#define NEEDS_UNTYPED_CALL 1

#undef ASM_FILE_START
#define ASM_FILE_START(FILE)					\
do { fprintf((FILE), "#NO_APP\n");				\
     output_file_directive ((FILE), main_input_filename);	\
   } while (0)

#include <pwd.h>
main()
{
struct passwd *p;
p=getpwnam("dennisg");
printf ("\n");
}

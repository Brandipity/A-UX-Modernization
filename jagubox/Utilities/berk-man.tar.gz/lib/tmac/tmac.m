'\"@(#)Copyright Apple Computer 1987\tVersion 1.1 of tmac.m on 87/05/04 13:44:18
'\"		Copyright (c) 1984 AT&T
'\"		  All Rights Reserved
'\"     THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF AT&T
'\"   The copyright notice above does not evidence any actual
'\"   or intended publication of such source code.
.if n .so /usr/lib/macros/mmn
.if t .so /usr/lib/macros/mmt

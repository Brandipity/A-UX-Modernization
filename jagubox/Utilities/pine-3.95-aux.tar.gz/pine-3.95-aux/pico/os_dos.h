/*
 * $Id: os_dos.h,v 4.15 1996/06/12 17:16:32 mikes Exp $
 *
 * Program:	Operating system dependent routines - Ultrix 4.1
 *
 *
 * Michael Seibel
 * Networks and Distributed Computing
 * Computing and Communications
 * University of Washington
 * Administration Builiding, AG-44
 * Seattle, Washington, 98195, USA
 * Internet: mikes@cac.washington.edu
 *
 * Please address all bugs and comments to "pine-bugs@cac.washington.edu"
 *
 *
 * Pine and Pico are registered trademarks of the University of Washington.
 * No commercial use of these trademarks may be made without prior written
 * permission of the University of Washington.
 * 
 * Pine, Pico, and Pilot software and its included text are Copyright
 * 1989-1996 by the University of Washington.
 * 
 * The full text of our legal notices is contained in the file called
 * CPYRIGHT, included with this distribution.
 */

#ifndef	OSDEP_H
#define	OSDEP_H

#include	<stdlib.h>
#include	<string.h>
#include	<dos.h>
#include	<direct.h>
#include	<search.h>
#undef	CTRL
#include	<ctype.h>
#include	<sys/types.h>
#include	<sys/stat.h>

/* define machine specifics */
#define	IBMPC	1

#ifdef	PCTCP
#define	sleep	_sleep
#define	_O_RDONLY O_RDONLY
#endif

/*
 *  IBM PC ROM BIOS Services used
 */
#define	BIOS_VIDEO	0x10
#define	BIOS_KEYBRD	0x16
#define	BIOS_MOUSE	0x33
#define	DOS_MULTIPLEX	0x2f


/*
 * type qsort expects
 */
#define	QSType	void
#define QcompType const void


/*
 * File name separators, char and string
 */
#define	C_FILESEP	'\\'
#define	S_FILESEP	"\\"


/*
 * What and where the tool that checks spelling is located.  If this is
 * undefined, then the spelling checker is not compiled into pico.
 */
#undef	SPELLER


/*
 * Mode passed chmod() to make tmp files exclusively user read/write-able
 */
#define	MODE_READONLY	(S_IREAD | S_IWRITE)


#ifdef	maindef
/*	possible names and paths of help files under different OSs	*/

char *pathname[] = {
	"picorc",
	"pico.hlp",
	"\\usr\\local\\",
	"\\usr\\lib\\",
	""
};

#define	NPNAMES	(sizeof(pathname)/sizeof(char *))

jmp_buf got_hup;

#endif
#endif	/* !OSDEP_H */

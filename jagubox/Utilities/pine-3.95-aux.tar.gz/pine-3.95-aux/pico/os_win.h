#line 2 "os_win.h"
/*
 * $Id: os_win.h,v 4.13 1996/03/15 07:41:11 hubert Exp $
 *
 * Program:	Operating system dependent routines - Ultrix 4.1
 *
 *
 * Michael Seibel
 * Networks and Distributed Computing
 * Computing and Communications
 * University of Washington
 * Administration Builiding, AG-44
 * Seattle, Washington, 98195, USA
 * Internet: mikes@cac.washington.edu
 *
 * Please address all bugs and comments to "pine-bugs@cac.washington.edu"
 *
 *
 * Pine and Pico are registered trademarks of the University of Washington.
 * No commercial use of these trademarks may be made without prior written
 * permission of the University of Washington.
 * 
 * Pine, Pico, and Pilot software and its included text are Copyright
 * 1989-1996 by the University of Washington.
 * 
 * The full text of our legal notices is contained in the file called
 * CPYRIGHT, included with this distribution.
 */

#ifndef	OSDEP_H
#define	OSDEP_H

#include	<stdlib.h>
#include	<string.h>
#include	<dos.h>
#include	<direct.h>
#include	<search.h>
#undef	CTRL
#include	<ctype.h>
#include	<sys/types.h>
#include	<sys/stat.h>


/* define machine specifics */
#define	IBMPC	1



/*
 * type qsort expects
 */
#define	QSType	void
#define QcompType const void


/*
 * File name separators, char and string
 */
#define	C_FILESEP	'\\'
#define	S_FILESEP	"\\"


/*
 * What and where the tool that checks spelling is located.  If this is
 * undefined, then the spelling checker is not compiled into pico.
 */
#define	SPELLER


/*
 * Mode passed chmod() to make tmp files exclusively user read/write-able
 */
/*#define	MODE_READONLY	(S_IREAD | S_IWRITE) */


#ifdef	maindef
/*	possible names and paths of help files under different OSs	*/

char *pathname[] = {
	"picorc",
	"pico.hlp",
	"\\usr\\local\\",
	"\\usr\\lib\\",
	""
};

#define	NPNAMES	(sizeof(pathname)/sizeof(char *))


jmp_buf got_hup;

#endif


/* Define function that mswin.c calls back for scrolling. */
int	pico_scroll_callback ();


#include "mswin.h"
#include "msmenu.h"


#endif	/* !OSDEP_H */

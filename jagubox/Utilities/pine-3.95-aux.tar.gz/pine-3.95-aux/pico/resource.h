//{{NO_DEPENDENCIES}}
// App Studio generated include file.
// Used by MSWIN.RC
//
#define IDD_OK                          1
#define ABOUTDLGBOX                     100
#define IDM_OPT_SETFONT                 103
#define IDM_ABOUT                       104
#define IDM_EDIT_CUT                    105
#define IDM_EDIT_COPY                   106
#define IDM_EDIT_PASTE                  107
#define TEXTWINMENU                     108
#define IDM_EDIT_CANCEL_PASTE           109
#define IDM_HELP                        110
#define IDD_TOOLBAR                     110
#define IDM_EDIT_COPY_APPEND            111
#define IDD_COMPOSER_TB                 111
#define IDM_FILE_EXIT                   112
#define IDD_OPTIONALYENTER              112
#define IDM_OPT_FONTSAMEAS              113
#define IDD_SELECT                      113
#define IDM_OPT_SETPRINTFONT            114
#define IDD_SELECTSORT                  114
#define IDM_FILE_CLOSE                  115
#define IDR_ACCEL_PINE                  115
#define IDM_FILE_PRINT                  116
#define IDM_OPT_TOOLBAR                 117
#define IDM_OPT_TOOLBARPOS              118
#define IDM_OPT_USEDIALOGS              119
#define IDM_OPT_USEACCEL                120
#define IDM_MI_VIEW                     150
#define IDM_MI_EXPUNGE                  151
#define IDM_MI_ZOOM                     152
#define IDM_MI_SORT                     153
#define IDM_MI_HDRMODE                  154
#define IDM_MI_MAINMENU                 155
#define IDM_MI_FLDRLIST                 156
#define IDM_MI_FLDRINDEX                157
#define IDM_MI_COMPOSER                 158
#define IDM_MI_PREVPAGE                 159
#define IDM_MI_PREVMSG                  160
#define IDM_MI_NEXTMSG                  161
#define IDM_MI_ADDRBOOK                 162
#define IDM_MI_WHEREIS                  163
#define IDM_MI_PRINT                    164
#define IDM_MI_REPLY                    165
#define IDM_MI_FORWARD                  166
#define IDM_MI_BOUNCE                   167
#define IDM_MI_DELETE                   168
#define IDM_MI_UNDELETE                 169
#define IDM_MI_FLAG                     170
#define IDM_MI_SAVE                     171
#define IDM_MI_EXPORT                   172
#define IDM_MI_TAKEADDR                 173
#define IDM_MI_SELECT                   174
#define IDM_MI_APPLY                    175
#define IDM_MI_POSTPONE                 176
#define IDM_MI_SEND                     177
#define IDM_MI_CANCEL                   178
#define IDM_MI_ATTACH                   179
#define IDM_MI_TOADDRBOOK               180
#define IDM_MI_READFILE                 181
#define IDM_MI_JUSTIFY                  182
#define IDM_MI_ALTEDITOR                183
#define IDM_MI_GENERALHELP              184
#define IDM_MI_SCREENHELP               185
#define IDM_MI_EXIT                     186
#define IDM_MI_NEXTPAGE                 187
#define IDM_MI_SAVEFILE                 188
#define IDM_MI_CURPOSITION              189
#define IDM_MI_GOTOFLDR                 190
#define IDM_MI_JUMPTOMSG                191
#define IDM_MI_RICHHDR                  192
#define IDM_MI_EXITMODE                 193
#define IDM_MI_REVIEW                   194
#define IDM_MI_KEYMENU                  195
#define IDM_MI_SELECTCUR                196
#define IDM_MI_UNDO                     197
#define IDM_MI_SPELLCHK                 198
#define PINEMENU                        300
#define COMPOSERMENU                    301
#define PINEICON                        400
#define NEWMAILICON                     401
#define PINEBITMAP                      500
#define IDD_ABOUTICON                   0x210
#define IDD_VERSION                     0x212
#define IDD_BYLINE                      0x213
#define IDS_BYLINE                      773
#define IDS_APPNAME                     774
#define IDS_APPIDENT                    775
#define IDC_RESPONCE                    1002
#define IDC_PROMPT                      1003
#define IDC_GETHELP                     1004
#define IDC_SORTARRIVAL                 1005
#define IDC_SORTORDERSUB                1006
#define IDC_SORTSUBJECT                 1007
#define IDC_SORTSIZE                    1008
#define IDC_SORTCC                      1009
#define IDC_SORTTO                      1010
#define IDC_SORTFROM                    1011
#define IDC_SORTDATE                    1012
#define IDC_SORTREVERSE                 1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         121
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif

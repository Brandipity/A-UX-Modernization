char datestamp[]="Tue Aug 6 11:40:07 EDT 1996";
char hoststamp[]="tigana";

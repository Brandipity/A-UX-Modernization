

/*----------------------------------------------------------------------------

	Common includes for custom dialogs.
		
	( This file included by os-win.h and os-wnt.h)

*/

typedef	struct DLG_SORTPARAM {
    int		rval;		/* Return value. */
    int		reverse;	/* Indicates a reversed sort. */
    int		cursort;	/* Current sort (pineid). */
    char	**helptext;	/* Pointer to help text. */
    int		sortcount;	/* Number of different sorts. */
    struct sorttypemap *types;  /* Pointer to array of conversion between
				 * the pine sort types and the radio button
				 * ids. */
} DLG_SORTPARAM;

/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#ifdef AUX
#include <sys/types.h>
#include "bbs.h"
#ifndef XINU
#include <sys/stat.h>
#endif
#endif

#ifndef AUX
#include "bbs.h"
#include <sys/types.h>
#ifndef XINU
#include <sys/stat.h>
#endif
#endif
int
readln(fp,buf)
FILE *fp ;
char *buf ;
{
    int i ;
    int ch ;
    int bytes ;
    i = 0 ;
    bytes = 0 ;
    while((ch = getc(fp)) != EOF) {
        bytes++ ;
        if(ch == '\n') {
            buf[i] = '\0' ;
            return bytes ;
        }
#ifdef BIT8
	if(isprint2(ch))
#else
        if(isprint(ch))
#endif
            buf[i++] = ch ;
        if(i == 80) {
            buf[i] = '\0' ;
            return bytes ;
        }
    }
    if(i == 0)
      return 0 ;
    else {
        buf[i] = '\0' ;
        return bytes ;
    }
}

int
more(filename,promptend)
char *filename ;
{
    FILE *fp ;
    char ch ;
    int i ;
    int viewed, pos ;
    long tsize ;
    struct stat st ;
    int numbytes ;
    char buf[81] ;
    extern int t_lines ;

    if((fp = fopen(filename,"r")) == NULL) {
/*        perror(filename) ;*/
        return -1;
    }
    if(fstat(fileno(fp), &st)) {
/*        perror("fstat") ;*/
        return -1;
    }
    tsize = st.st_size ;
    clr() ;
    i = 0 ;
    pos = 0 ;
    viewed = 0 ;
    if (uinfo.mode == LOGIN) {
	if (currentuser.lasthost[0] != '\0') {
	  prints("Last logged in from %s on %s", currentuser.lasthost,
                ctime(&currentuser.lastlogin));
	  pos++;
	}
#ifdef VOTE
	if (HAS_PERM(PERM_VOTE) && !stat("vote/control", &st) && 
		!(int)(currentuser.flags[0] & VOTE_FLAG)) {
	  prints("You have not voted in the current election.\n");
	  pos++;
	}
#endif
    }
    numbytes = readln(fp,buf) ;
    do {
        if(!numbytes)
          break ;
        viewed += numbytes ;
        prints("%s\n",buf) ;
        pos++ ;
        i++ ;
        if(pos == t_lines) {
            scroll() ;
            pos-- ;
        }
        numbytes = readln(fp,buf) ;
        if(!numbytes)
          break ;
        if(i == t_lines -1) {
            move(t_lines-1,0) ;
            if(!dumb_term) {
                standout() ;
                prints("--More-- (%d%%)",(viewed*100)/tsize) ;
                standend() ;
            } else
              bell() ;
            while((ch = igetch()) != EOF) {
                if(ch == ' ') {
                    move(t_lines-1,0) ;
                    clrtoeol() ;
                    refresh() ;
                    i = 1 ;
                    break ;
                }
                if(ch == 'q') {
                    move(t_lines-1,0) ;
                    clrtoeol() ;
                    refresh() ;
                    fclose(fp) ;
                    return  0;
                }
                if(ch == '\r') {
                    move(t_lines-1,0) ;
                    clrtoeol() ;
                    refresh() ;
                    i = t_lines-2 ;
                    break ;
                }
                bell() ;
            }
        }
    } while(numbytes) ;
    fclose(fp) ;
    move(t_lines-1,0) ;
    if(promptend)
      pressreturn() ;
    return 0 ;
}



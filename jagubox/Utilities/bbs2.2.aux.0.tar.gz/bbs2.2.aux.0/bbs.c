/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
			Guy Vega, gtvega@seabass.st.usm.edu
			Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#ifdef AUX
#include <sys/file.h>
#include "bbs.h"
#endif
#ifndef AUX
#include "bbs.h"
#include <sys/file.h>
#endif

int mot ;
static int quiting ;
int scrint = 0 ;

struct userec currentuser ;
int usernum ;
char currboard[STRLEN] ;
int selboard = 0 ;

extern char *boardmargin() ;
extern char *filemargin() ;
extern int numboards;
extern char *ctime();
char genbuf[4096] ;

exit_warning()
{
	bell() ;
	return 0 ;
}

Maintenance()
{
	uinfo.mode = ADMIN;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	docmd("Maintenance Menu","Enter maintenance command: ",'h',maintlist,boardmargin) ;
	clr() ;
	uinfo.mode = MMENU;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	return 0 ;
}


Xyz()
{
/*	report("XYZ menu") ;*/
	uinfo.mode = XMENU;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	docmd("MISC utilities Menu.","Enter utility command: ",'h',xyzlist,boardmargin) ;
	clr() ;
	uinfo.mode = MMENU;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	return 0 ;
}

Talk()
{
/*	report("Enter Talk menu") ;*/
        uinfo.mode = TMENU;
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	docmd("Interactive Talk Menu","Enter command: ",'h',talklist,boardmargin) ;
/*	report("Exit Talk menu") ;*/
        uinfo.mode = MMENU;
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	clr() ;
	return 0 ;
}


#ifdef FILES
Files()
{
/*	report("Files menu") ; */
	uinfo.mode = ULDL ;
	substitute_record(ULIST,(void *)&uinfo, sizeof(uinfo), utmpent) ;
	docmd("FILE Transfer Menu.","Enter File Transfer command: ",'s',filelist,filemargin) ;
	clr() ;
	uinfo.mode = MMENU ;
	substitute_record(ULIST,(void *)&uinfo, sizeof(uinfo), utmpent) ;
	return 0 ;
}
#endif

Mail()
{
	int cmd ;

/*	report("Mail menu") ;*/
	uinfo.mode = MAIL ;
	substitute_record(ULIST,(void *)&uinfo,sizeof(uinfo),utmpent) ;
	if(chkmail())
	  cmd = 'n' ;
	else
	  cmd = 's' ;
	docmd("MAIL System Menu.","Enter MAIL command: ",cmd,maillist,boardmargin) ;
	uinfo.mode = MMENU ;
	substitute_record(ULIST,(void *)&uinfo,sizeof(uinfo),utmpent) ;
	clr() ;
	return 0 ;
}

#ifdef PERMS
char uleveltochar(lvl)
unsigned lvl;
{
	lvl &= ~PERM_POSTMASK;
	if (lvl == PERM_DEFAULT) return ' ';
	else if (lvl < PERM_DEFAULT) return '-';
	else return '+';
}

char bleveltochar(lvl)
unsigned lvl;
{
	unsigned reallvl = lvl & ~PERM_POSTMASK;
	if (!reallvl) return ' ';
	else if (lvl & PERM_POSTMASK) return 'P';
	else return 'R';
}
#endif

char *
Ctime(clock)
time_t *clock;
{
    char *foo;
    char *ptr = ctime(clock);
    if (foo = rindex(ptr, '\n')) *foo = '\0';
    return (ptr);
}

int usercounter;

printuent(uentp)
struct userec *uentp ;
{
	static int i ;
	char tmpstring[10]; 
	char *field2;
#if defined(REALINFO) && defined(ACTS_REALNAMES)
	field2 = "Real Name";
#else
	field2 = "User Name";
#endif
	if(uentp == NULL) {
		move(3,0) ;
		prints("%-14s %-25s %-6s %-6s %-6s %-11s\n","User Id",field2,
#ifdef PERMS
		"#Login", "#Post",HAS_PERM(PERM_SEEULEVELS)?"Lvl":" ","LastLogin") ;
#else
		"#Login", "#Post",(currentuser.userlevel>=SEEUSRLEVELS)?"Level":" ","LastLogin") ;
#endif
		i = 3 ;
		return 0;
	}
	if(uentp->userid[0] == '\0')
	  return 0 ;
	if(i == 22) {
		int ch ;
		standout() ;
		prints("--MORE--") ;
		standend() ;
		clrtoeol();
		while((ch = igetch()) != EOF) {
			if(ch == '\n' || ch == '\r' || ch == ' ')
			  break ;
			if(ch == 'q' || ch == CTRL('C')) {
				move(23,0) ;
				clrtoeol() ;
				return QUIT ;
			}
			bell() ;
		}
		move(3,0) ;
		prints("%-14s %-25s %-6s %-6s %-6s %-11s\n","User Id","User Name",
#ifdef PERMS
		"#Login", "#Post",HAS_PERM(PERM_SEEULEVELS)?"Lvl":" ","LastLogin") ;
#else
		"#Login", "#Post",(currentuser.userlevel>=SEEUSRLEVELS)?"Level":" ","LastLogin") ;
#endif
		i = 3 ;
		clrtobot() ;
	}
#ifdef PERMS
	sprintf(tmpstring," %c ", uleveltochar(uentp->userlevel));
#else
	sprintf(tmpstring,"%d",uentp->userlevel); 
#endif
	prints("%-14s %-25s  %5d %5d  %-3s %-16s %c\n",uentp->userid,
#if defined(REALINFO) && defined(ACTS_REALNAMES)
		uentp->realname,
#else
		uentp->username,
#endif 
#ifdef PERMS
		uentp->numlogins, uentp->numposts,HAS_PERM(PERM_SEEULEVELS)?tmpstring:" ",Ctime(&uentp->lastlogin),(HAS_PERM(PERM_UCLEAN) && (uentp->flags[0] & NOCLEAN_FLAG) ? 'X':' '));
#else
		uentp->numlogins, uentp->numposts,(currentuser.userlevel>=SEEUSRLEVELS)?tmpstring:" ",Ctime(&uentp->lastlogin),(currentuser.userlevel>=SEEUSRLEVELS && (uentp->flags[0] & NOCLEAN_FLAG) ? 'X':' '));
#endif
	i++ ;
	usercounter++;
	return 0 ;
}

countusers(uentp)
struct userec *uentp;
{
	if (uentp->userid[0] != '\0')
		usercounter++;
}

Users()
{
	int totalusers;
	usercounter = 0;
	apply_record(PASSFILE,countusers,sizeof(struct userec));
	totalusers = usercounter; 
	usercounter = 0;
/*	report("User List") ;*/
        uinfo.mode = LAUSERS;
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	printuent((struct userec *)NULL) ;
	if(apply_record(PASSFILE,printuent,sizeof(struct userec)) == -1) {
		prints("No Users Exist") ;
		pressreturn() ;
	        uinfo.mode = MMENU;
        	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
		return 0;
	}
	clrtobot() ;
	move(t_lines-1,0);
	prints("%d of %d users displayed (%d max on system)", usercounter,
		totalusers, MAXUSERS);
        uinfo.mode = MMENU;
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	return 0;
}

#ifndef PERMS
SetBoardAccess(lineno)
int lineno;
{
	char instr[7];
	int lvl;
	getdata(lineno,0,"Enter Level To Access This Board: ", instr,
		   7,DOECHO,NULL);
	lvl = abs(atoi(instr));
	prints("Board access level is set to %u\n", lvl);
	return lvl;
}
#endif

Create()
{
	struct fileheader newboard ;
	char *s ;
	char ans[4];
	extern int numboards ;
	clr() ;
        uinfo.mode = ADMIN;
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	bzero(&newboard, sizeof(newboard));
	prints("Create a Board:Enter Board Name (use single word):") ;
cagain:
    getdata(3,0,"Enter Board Name (use single word): ",newboard.filename,
            18,DOECHO,NULL) ;
	for(s = newboard.filename;*s!='\0';s++)
	  if(!isalpha(*s)) {
		  prints("boardname is invalid\n") ;
		  goto cagain ;
	  }
	getdata(4,0,"Enter Board description: ",newboard.title,60,DOECHO,NULL) ;
	strcpy(genbuf,"boards/") ;
	strcat(genbuf,newboard.filename) ;
        uinfo.mode = MMENU;
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	if(getbnum(newboard.filename) > 0 || mkdir(genbuf,0755) == -1) {
		prints("\nError: Bad Board Name\n") ;
		pressreturn() ;
		clr() ;
		return -1 ;
	}
#ifdef PERMS
	getdata(5,0,"Permissions needed to access this board (Y/N)? [N]: ",
		ans,4,DOECHO,NULL);	
	if (*ans == 'y' || *ans == 'Y') {
		getdata(6,0,"Restrict (R)eading or (P)osting? [R]: ",ans,4,DOECHO, NULL);		
		if (*ans == 'P' || *ans == 'p') newboard.level = PERM_POSTMASK;
		else newboard.level = 0;
		move(1,0);
		clrtobot();
		move(2,0);
		prints("Set the desired %s permissions for board  '%s'\n",
			(newboard.level & PERM_POSTMASK ? "POST" : "READ"), newboard.filename);
		newboard.level = setperms(newboard.level);
		clr();
	}
	else newboard.level = 0;	
#else
	newboard.level = SetBoardAccess(5);	
#endif
	if(append_record(BOARDS,&newboard,sizeof(newboard)) == -1) {
		pressreturn() ;
		clr() ;
		return -1 ;
	}
	numboards = -1 ;
	prints("\nNew Board Added\n") ;
	sprintf(genbuf, "added board %s", newboard.filename);
	report(genbuf);
	pressreturn() ;
	clr()  ;
	return 0 ;
}

int at ;

filepr(fhdrp)
struct fileheader *fhdrp ;
{
	char level[10];
	if(at == -1)
	  return 0;
	if(at == 23) {
		int ch ;

		standout() ;
		prints("-- More --") ;
		standend() ;
		while((ch = igetch()) != EOF) {
			if(ch == 'q' || ch == CTRL('C')) {
				move(23,0) ;
				clrtoeol() ;
				return QUIT;
			}
			if(ch == '\n' || ch == '\r' || ch == ' ')
			  break ;
			bell() ;
		}
		move(5,0) ;
		clrtobot() ;
		at = 5 ;
	}
#ifdef PERMS
	if (HAS_PERM(PERM_SEEBLEVELS))
		sprintf(level, "    %c ", bleveltochar(fhdrp->level));
	if ((fhdrp->level & PERM_POSTMASK) || HAS_PERM(fhdrp->level)) {
#else
	if (currentuser.userlevel >= SEEBRDLEVELS)
		sprintf(level, "%6d", fhdrp->level);
	if (currentuser.userlevel >= fhdrp->level) {
#endif
		prints("%c%-20s %s %s\n", (fhdrp->accessed[0] & ZAPPED) ? '*' : ' ', fhdrp->filename,
#ifdef PERMS
		  HAS_PERM(PERM_SEEBLEVELS)?level:"", fhdrp->title) ;
#else
		  currentuser.userlevel>=SEEBRDLEVELS?level:"", fhdrp->title) ;
#endif
		at++ ;
	}
    return 0 ;
}

getstats(fname, total, owned, visited, unread, lastpost)
char *fname;
int *total, *owned, *visited, *unread;
char *lastpost;
{
	int i, dir, offset;
	char c, bname[STRLEN];
	struct fileheader fh;
	struct stat stbuf;
	lastpost[0] = '\0';
        *total = *owned = *visited = *unread = 0;
	offset = (int)(&((struct fileheader *)0)->accessed[usernum]);
	sprintf(bname, "boards/%s/.DIR", fname);
	if ((dir=open(bname, O_RDONLY))==-1) return;
	fstat(dir, &stbuf);
	*total = *unread = stbuf.st_size/sizeof(struct fileheader);
	for (i=1; i<=*total; i++) {
	    if (i == 1) lseek(dir, offset, L_SET);
	    else lseek(dir, sizeof(struct fileheader)-1, L_INCR);
	    read(dir, &c, 1);
	    c = c & (FILE_OWND | FILE_VISIT | FILE_READ);
	    if (c) {
	        (*unread)--;
    	        if(c & FILE_OWND) (*owned)++;
	        else if(c & FILE_VISIT) (*visited)++;
            }
	}
	close(dir);
	if (*total > 0) {
	   char datestr[15], *pptr;
	   time_t posttime;
	   get_record(bname, &fh, sizeof(fh), *total);
	   strcpy(datestr, fh.filename+2);
	   if (pptr = index(datestr, '.')) *pptr = '\0';
	   posttime = atol(datestr);
	   strcpy(lastpost, ctime(&posttime));
	   lastpost[16] = '\0';  /* chop off year */
	}
	else lastpost[0] = '\0';	   
}

#define ZAPPED_BRDS	1
#define UNZAPPED_BRDS	2
int whichboards;

postcount(fhdrp)
struct fileheader *fhdrp ;
{
	int total, owned, visited, unread;
	static int ttotal, ototal, vtotal, utotal;
	int zapped;
	char lastpost[30];
	if(at == -1)
	  return 0;
	if(at == 23) {
		int ch ;

		standout() ;
		prints("-- More --") ;
		standend() ;
		while((ch = igetch()) != EOF) {
			if(ch == 'q' || ch == 'Q') {
				move(23,0) ;
				clrtoeol() ;
				ttotal = ototal = vtotal = utotal = 0;
				return QUIT;
			}
			if(ch == '\n' || ch == '\r' || ch == ' ')
			  break ;
			bell() ;
		}
		move(5,0) ;
		clrtobot() ;
		at = 5 ;
	}
	if (fhdrp == NULL) {
		prints(" %-20s  %4d    %4d     %4d    %4d\n", "*** TOTALS ***",
		  ttotal, ototal, vtotal, utotal);
		ttotal = ototal = vtotal = utotal = 0;
		return;
	}
	zapped = ((int)fhdrp->accessed[0] & ZAPPED) ? ZAPPED_BRDS : UNZAPPED_BRDS;
#ifdef PERMS
	if (((fhdrp->level & PERM_POSTMASK) || HAS_PERM(fhdrp->level)) && 
#else
	if (currentuser.userlevel >= fhdrp->level && 
#endif
            (whichboards & zapped)) {
		getstats(fhdrp->filename, &total, &owned, &visited, &unread, lastpost);
		prints("%c%-20s  %4d    %4d     %4d    %4d   %16s\n", (fhdrp->accessed[0] & ZAPPED) ? '*' : ' ', fhdrp->filename,
		  total, owned, visited, unread, lastpost) ;
		at++ ;
	        ttotal += total;
		ototal += owned;
		vtotal += visited;
		utotal += unread;
	}
    return 0 ;
}

Boards()
{
        uinfo.mode = SHOW;
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	move(3,0) ;
	clrtobot() ;
	prints("List of Boards (* = zapped board)\n") ;
#ifdef PERMS
	prints(" Name                    %s Title\n", HAS_PERM(PERM_SEEBLEVELS)?"Lvl":"   ") ;
#else
	prints(" Name                    %s Title\n", currentuser.userlevel>=SEEBRDLEVELS?"Lvl":"   ") ;
#endif
	at = 5 ;
	apply_boards(filepr) ;
        uinfo.mode = MMENU;
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	return 0 ;
}

CountBoards()
{
	char ans [2];
        uinfo.mode = CNTBRDS;
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	move(3,0) ;
	clrtobot() ;
	getdata(3,0,"(A)ll, (Z)apped only, or (U)nzapped only? [U]: ",ans,2,DOECHO,NULL);
	*ans = toupper(*ans);
	if (*ans == 'A') whichboards = ZAPPED_BRDS | UNZAPPED_BRDS;
	else if (*ans == 'Z') whichboards = ZAPPED_BRDS;
	else whichboards = UNZAPPED_BRDS;
	move(3,0);
	clrtoeol();
	if (whichboards & ZAPPED_BRDS) prints("Post Counts (* = zapped board)\n") ;
	else prints("Post Counts\n");
	prints(" Name                 #Posts   Owned   Visited   New   LastPost\n") ;
	at = 5 ;
	if (apply_boards(postcount) != QUIT)
	    postcount(NULL);
        uinfo.mode = MMENU;
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	return 0 ;
}

char *
bfile(boardname)
char *boardname ;
{
	static char buf[STRLEN] ;
	strcpy(buf,"boards/") ;
	strcat(buf,boardname) ;
	return buf ;
}

g_board_names(fhdrp)
struct fileheader *fhdrp ;
{
#ifdef PERMS
    if ((fhdrp->level & PERM_POSTMASK) || HAS_PERM(fhdrp->level))
#else
    if (currentuser.userlevel >= fhdrp->level)
#endif
	AddNameList(fhdrp->filename) ;
    return 0 ;
}

make_blist()
{
	CreateNameList() ;
	apply_boards(g_board_names) ;
}

Select()
{
	char bname[STRLEN] ;
	struct stat st ;
        uinfo.mode = SELECT;
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	make_blist() ;
	move(0,0) ;
	prints("Select a Board Name (upper/lower case does not matter)\n") ;
	prints("Select Board: ") ;
	clrtoeol() ;
	namecomplete((char *)NULL,bname) ;
        uinfo.mode = MMENU;
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	if((*bname == '\0') || (stat(bfile(bname),&st) == -1)) {
		move(2,0) ;
		prints("Invalid Board Name") ;
		pressreturn() ;
		move(0,0) ;
		clrtoeol() ;
		move(1,0) ;
		clrtoeol() ;
		move(2,0) ;
		clrtoeol() ;
		return 1 ;
	}
	if(!(st.st_mode & S_IFDIR)) {
		move(1,0) ;
		prints("Invalid Board Name\n") ;
		pressreturn() ;
		move(0,0) ;
		clrtoeol() ;
		move(1,0) ;
		clrtoeol() ;
		move(2,0) ;
		clrtoeol() ;
		return 1 ;
	}
/*	sprintf(genbuf,"Select board '%s'",bname) ;
	report(genbuf) ;*/
	selboard = 1;
	strcpy(currboard, bname) ;
	move(0,0) ;
	clrtoeol() ;
	move(1,0) ;
	clrtoeol() ;
	return 0 ;
}


Post()
{
	struct fileheader postfile ;
	char fname[STRLEN] ;
	char *ip ;
	int fp, aborted ;

	if(!selboard) {
		prints("\n\nUse (S)elect to select a board first.\n") ;
		pressreturn() ;
		clr() ;
		return 0 ;
	}
#ifdef PERMS
 	if (!haspostperm(currboard)) {
		prints("\n\nPosting is restricted on this board.\n");
		pressreturn();
		clr();
		return 0;
	}
#endif	
	bzero((void *)&postfile,sizeof(postfile)) ;
	postfile.accessed[usernum] = FILE_READ|FILE_OWND ;
	clr() ;
	prints("Posting message on Board '%s'\n\n",currboard) ;
	sprintf(fname,"M.%d.A",time(0)) ;
	sprintf(genbuf,"boards/%s/%s",currboard,fname) ;
	ip = rindex(fname,'A') ;
	while((fp = open(genbuf,O_CREAT|O_EXCL|O_WRONLY,0644)) == -1) {
		if(*ip == 'Z')
		  ip++,*ip = 'A', *(ip + 1) = '\0' ;
		else
		  (*ip)++ ;
		sprintf(genbuf,"boards/%s/%s",currboard,fname) ;
	}
	close(fp) ;
	strcpy(postfile.filename,fname) ;
	getdata(1,0,"Title: ",postfile.title,STRLEN,DOECHO,NULL) ;
	strncpy(save_title,postfile.title,STRLEN) ;
	strncpy(save_filename,fname,4096) ;
	in_mail = NA ;
	strncpy(postfile.owner,currentuser.userid,STRLEN) ;
	sprintf(genbuf,"boards/%s/%s",currboard,postfile.filename) ;
	uinfo.mode = POSTING ;
	substitute_record(ULIST,(void *)&uinfo,sizeof(uinfo),utmpent) ;
	aborted = vedit(genbuf,YEA) ;
	uinfo.mode = MMENU ;
	substitute_record(ULIST,(void *)&uinfo,sizeof(uinfo),utmpent) ;
	clr() ;
	if (!aborted) {
	    if(append_record(strcat(bfile(currboard),DIR),&postfile,
					 sizeof(postfile)) == -1) {
		sprintf(genbuf, "posting '%s' on '%s': append_record failed!",
	      		postfile.title, currboard);
		report(genbuf);
		pressreturn() ;
		clr() ;
		return -1 ;
	    }
	    sprintf(genbuf,"posted '%s' on '%s'", postfile.title, currboard) ;
	    report(genbuf) ;
	    prints("File Posted\n") ;
	    currentuser.numposts++;
	    substitute_record(PASSFILE, &currentuser, sizeof(currentuser), usernum);
	}
	pressreturn() ;
	return FULLUPDATE;
}

ztest()
{
	pressreturn() ;
	return 0 ;
}

readtitle()
{
	prints("Interactive Read Menu                              Current Board '%s'\n",currboard) ;
	prints("(n)ext Message     (p)revious Message     (r)ead Message     (e)xit Read Menu\n");
	prints("##<cr> go to message ##     <CTRL-P> post a message     (h) Get a HELP screen\n");
	prints(" ENT   %-20s %s\n","Owner","Title") ;
	clrtobot() ;
}


char *
readdoent(num,ent)
struct fileheader *ent ;
{
	static char buf[512] ;
	int type ;

    if(ent->accessed[usernum] & FILE_VISIT)
      type = 'U' ;
    else if(!(ent->accessed[usernum] & FILE_READ))
      type = 'N' ;
    else
      type = ' ' ;
#ifdef PERMS
    if ((ent->accessed[0] & FILE_MARKED) && HAS_PERM(PERM_MARKPOST))
#else
    if ((ent->accessed[0] & FILE_MARKED) && currentuser.userlevel >= DELPOSTLEVEL)
#endif
    {
       if (type == ' ') type = 'm';
       else type = 'M';
    }
	sprintf(buf," %3d %c %-20s %s",num, type, ent->owner, ent->title) ;
	return buf ;
}

char currfile[STRLEN] ;

cmpfilename(fhdr)
struct fileheader *fhdr ;
{
	if(!strncmp(fhdr->filename,currfile,STRLEN))
	  return 1 ;
	return 0 ;
}

void
updatefile(fhdr)
struct fileheader *fhdr ;
{
	fhdr->accessed[usernum] |= FILE_READ ;
	fhdr->accessed[usernum] &= ~FILE_VISIT ;
}

read_post(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	char *t ;
	char ans[6];
	char buf[512];

	clr() ;
	strcpy(buf,direct) ;
	if (t = rindex(buf,'/'))
	  *t = '\0' ;
	sprintf(genbuf,"%s/%s",buf,fileinfo->filename) ;
#ifndef NOREPLY
	more(genbuf,NA) ;
#else
        more(genbuf,YEA) ;
#endif
/*	sprintf(genbuf,"Read '%s' on '%s'",fileinfo->title,currboard) ;
	report(genbuf) ; */
	strncpy(currfile,fileinfo->filename,STRLEN) ;
	update_file(direct,sizeof(struct fileheader),ent,cmpfilename,updatefile) ;
#ifndef NOREPLY
#ifdef PERMS
	if (haspostperm(currboard)) {
#endif
	   getdata(t_lines-1,0,"Reply (Y/N)? [N]: ",ans,6,DOECHO,NULL);
	   if (ans[0] == 'Y' || ans[0] == 'y')
	       do_reply(fileinfo->title);
#ifdef PERMS
	}
	else pressreturn();
#endif
#endif
	return FULLUPDATE ;
}

do_select()
{
	char bname[STRLEN] ;
	struct stat st ;
	extern char dirbuf[4096] ;

	make_blist() ;
	move(0,0) ;
	prints("Select a Board Name (upper/lower case does not matter)\n") ;
	prints("Select Board: ") ;
	clrtoeol() ;
	namecomplete((char *)NULL,bname) ;
	if((*bname == '\0') || (stat(bfile(bname),&st) == -1)) {
		move(2,0) ;
		prints("Invalid Board Name") ;
	        clrtoeol() ;
		pressreturn() ;
		move(0,0) ;
		clrtoeol() ;
		move(1,0) ;
		clrtoeol() ;
		move(2,0) ;
		clrtoeol() ;
		return FULLUPDATE ;
	}
	if(!(st.st_mode & S_IFDIR)) {
		move(1,0) ;
		prints("Invalid Board Name") ;
	        clrtoeol() ;
		pressreturn() ;
		move(0,0) ;
		clrtoeol() ;
		move(1,0) ;
		clrtoeol() ;
		move(2,0) ;
		clrtoeol() ;
		return FULLUPDATE ;
	}
/*	sprintf(genbuf,"read menu Select board '%s'",bname) ;
	report(genbuf) ;*/
	selboard = 1;
	strcpy(currboard, bname) ;
	move(0,0) ;
	clrtoeol() ;
	move(1,0) ;
	clrtoeol() ;
	strcpy(dirbuf,strcat(bfile(currboard),DIR)) ;
	return NEWDIRECT ;
}

#ifndef NOREPLY
char replytitle[STRLEN];

do_reply(oldtitle)
char *oldtitle;
{
	strcpy(replytitle, oldtitle);
	do_post();
	replytitle[0] = '\0';
}
#endif

do_post()
{
	struct fileheader postfile ;
	char fname[STRLEN], ans[4], buf[256];
	char *ip ;
	int fp, aborted;
	int savemode;

#ifdef PERMS
	if (!haspostperm(currboard)) {
		bell();
		return DONOTHING;
	}
#endif
	bzero(&postfile,sizeof(postfile)) ;
	postfile.accessed[usernum] = FILE_READ|FILE_OWND ;
	clr() ;
	prints("Posting message on Board '%s'\n\n",currboard) ;
	sprintf(fname,"M.%d.A",time(0)) ;
	sprintf(genbuf,"boards/%s/%s",currboard,fname) ;
	ip = rindex(fname,'A') ;
	while((fp = open(genbuf,O_CREAT|O_EXCL|O_WRONLY,0644)) == -1) {
		if(*ip == 'Z')
		  ip++,*ip = 'A', *(ip + 1) = '\0' ;
		else
		  (*ip)++ ;
		sprintf(genbuf,"boards/%s/%s",currboard,fname) ;
	}
	close(fp) ;
	strcpy(postfile.filename,fname) ;
#ifndef NOREPLY
	if (replytitle[0] != '\0') {
	    if (toupper(replytitle[0]) == 'R' && replytitle[1] == 'e' && replytitle[2] == ':')
		strcpy(buf, replytitle);
	    else sprintf(buf,"Re: %s", replytitle);
	    sprintf(replytitle, "Use title \"%s\" (Y/N)? [N]: ", buf);
	    getdata(1,0, replytitle,ans, 4, DOECHO, NULL);
	    if (ans[0] == 'Y' || ans[0] == 'y')
		strcpy(postfile.title, buf);
	    else getdata(1,0,"Title: ",postfile.title,STRLEN,DOECHO,NULL) ;
	}
	else
#endif
   	    getdata(1,0,"Title: ",postfile.title,STRLEN,DOECHO,NULL);
	strncpy(save_title,postfile.title,STRLEN) ;
	strncpy(save_filename,fname,4096) ;
	in_mail = NA ;
	strncpy(postfile.owner,currentuser.userid,STRLEN) ;
	sprintf(genbuf,"boards/%s/%s",currboard,postfile.filename) ;
	savemode = uinfo.mode;
	uinfo.mode = POSTING ;
	substitute_record(ULIST,(void *)&uinfo,sizeof(uinfo),utmpent) ;
	aborted = vedit(genbuf,YEA) ;
	uinfo.mode = savemode;
	substitute_record(ULIST,(void *)&uinfo,sizeof(uinfo),utmpent) ;
	clr() ;
	if (aborted) {
                pressreturn() ;
                clr() ;
                return FULLUPDATE ;
        }
	if (append_record(strcat(bfile(currboard),DIR),&postfile,
					 sizeof(postfile)) == -1) {
		sprintf(buf, "posting '%s' on '%s': append_record failed!",
	      		postfile.title, currboard);
		report(buf);
		pressreturn() ;
		clr() ;
		return FULLUPDATE ;
	}
	sprintf(buf,"posted '%s' on '%s'", postfile.title, currboard) ;
	report(buf) ;
	prints("File Posted\n") ;
	currentuser.numposts++;
	substitute_record(PASSFILE, &currentuser, sizeof(currentuser), usernum);
	pressreturn() ;
	return FULLUPDATE ;
}


/*ARGSUSED*/
edit_post(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	char buf[512] ;
	char *t ;

#ifdef PERMS
	if(!HAS_PERM(PERM_SYSOP)) {
#else
	if(currentuser.userlevel < 255) {
#endif
            bell() ;
            return DONOTHING ;
	}
	clr() ;
	strcpy(buf,direct) ;
	if (t = rindex(buf,'/'))
	  *t = '\0' ;
	sprintf(genbuf,"%s/%s",buf,fileinfo->filename) ;
	vedit(genbuf,NA) ;
	sprintf(genbuf, "edited post '%s' on %s", fileinfo->title, currboard);
	report(genbuf);
	strncpy(currfile,fileinfo->filename,STRLEN) ;
	return FULLUPDATE ;
}

mark_post(ent,fileinfo,direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
#ifdef PERMS
    if (!HAS_PERM(PERM_MARKPOST)) {
#else
    if (currentuser.userlevel < DELPOSTLEVEL) {
#endif
	bell();
	return DONOTHING;
    }
    if (fileinfo->accessed[0] & FILE_MARKED)
	fileinfo->accessed[0] &= ~FILE_MARKED;
    else fileinfo->accessed[0] |= FILE_MARKED;
    substitute_record(direct, fileinfo, sizeof(*fileinfo), ent);
    return PARTUPDATE;
}

del_range(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
    char num1[10],num2[10] ;
    int inum1, inum2 ;
    
#ifdef PERMS
    if(uinfo.mode == READING && !HAS_PERM(PERM_BOARDS)) {
#else
    if(uinfo.mode == READING && currentuser.userlevel < DELPOSTLEVEL) {
#endif
        bell() ;
        return DONOTHING ;
    }
    clr() ;
    prints("Delete RANGE\n") ;
    getdata(1,0,"Enter Low End of Range (inclusive): ",num1,10,DOECHO,NULL) ;
    inum1 = atoi(num1) ;
    if(inum1 <= 0) {
        prints("Invalid Low range number\n") ;
        pressreturn() ;
        return FULLUPDATE ;
    }
    getdata(2,0,"Enter High End of Range (inclusive): ",num2,10,DOECHO,NULL) ;
    inum2 = atoi(num2) ;
    if(inum2 <= inum1) {
        prints("Invalid High range number\n") ;
        pressreturn() ;
        return FULLUPDATE ;
    }
    getdata(3,0,"Are You Sure?  (Yes, or No) [N]: ",num1,10,DOECHO,NULL) ;
    if(*num1 == 'Y' || *num1 == 'y') {
        delete_range(direct,inum1,inum2) ;
	fixkeep(direct, inum1, inum2);
        if (uinfo.mode == READING)
    	  sprintf(genbuf, "delete range %d-%d on %s", inum1, inum2, currboard);
        else sprintf(genbuf, "mail delete range %d-%d", inum1, inum2);
	report(genbuf);
        prints("Delete Complete\n") ;
        pressreturn() ;
        return FULLUPDATE ;
    }
    prints("Delete Aborted\n") ;
    pressreturn() ;
    return FULLUPDATE ;
}

del_post(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	char buf[512] ;
	char *t ;
	int owned;

	owned = fileinfo->accessed[usernum]&FILE_OWND;	
#ifdef PERMS
	if((!HAS_PERM(PERM_BOARDS)) && !(owned)) {
#else
	if((currentuser.userlevel < DELPOSTLEVEL) && !(owned)) {
#endif
		bell() ;
		return DONOTHING ;
	}
	clr() ;
	prints("Delete Message '%s'.",fileinfo->title) ;
	getdata(1,0,"(Yes, or No) [N]: ",genbuf,STRLEN,DOECHO,NULL) ;
	if(genbuf[0] != 'Y' && genbuf[0] != 'y') { /* if not yes quit */
		move(2,0) ;
		prints("Quitting Delete Post\n") ;
		pressreturn() ;
		clr() ;
		return FULLUPDATE ;
	}		
	strcpy(buf,direct) ;
	if (t = rindex(buf,'/'))
	  *t = '\0' ;
	sprintf(genbuf,"Deleted '%s' on '%s'",fileinfo->title,currboard) ;
	report(genbuf) ;
	strncpy(currfile,fileinfo->filename,STRLEN) ;
	if(!delete_file(direct,sizeof(struct fileheader),ent,cmpfilename)) {
		sprintf(genbuf,"%s/%s",buf,fileinfo->filename) ;
		unlink(genbuf) ;
		if (owned) {
		    if (currentuser.numposts > 0) currentuser.numposts--;
		    substitute_record(PASSFILE, &currentuser, sizeof(currentuser), usernum);		
		}
		return FULLUPDATE ;
	}
	move(2,0) ;
	prints("Delete failed\n") ;
	pressreturn() ;
	clr() ;
	return FULLUPDATE ;
}

static int sequent_ent ;

sequent_messages(fptr)
struct fileheader *fptr ;
{
	static int idc ;
	char ans[6];	
	if(fptr == NULL) {
		idc = 0 ;
		return 0 ;
	}
	idc++ ;
	if(idc < sequent_ent)
          return 0;
	if(fptr->accessed[usernum] & FILE_READ && !(fptr->accessed[usernum] & FILE_VISIT))
	  return 0 ;
	mot = 1 ;
	prints("Read Message on board '%s' entitled:\n\"%s\" posted by %s.\n",
		currboard,fptr->title,fptr->owner) ;
	getdata(3,0,"(Yes or No or Quit) [Y]: ",genbuf,5,DOECHO,NULL) ;
	if(genbuf[0] != 'y' && genbuf[0] != 'Y' && genbuf[0] != '\0') {
		if(genbuf[0] == 'q' || genbuf[0] == 'Q') {
            clr() ;
            return QUIT ;
        }
		clr() ;
		return 0;
	}
	sprintf(genbuf,"boards/%s/%s",currboard,fptr->filename) ;
#ifdef NOREPLY
	more(genbuf,YEA);
#else
        more(genbuf,NA) ;
#ifdef PERMS
	if (haspostperm(currboard)) {
#endif
	   getdata(t_lines-1,0,"Reply (Y/N)? [N]: ",ans,6,DOECHO,NULL);
	   if (ans[0] == 'Y' || ans[0] == 'y')
	       do_reply(fptr->title);
#ifdef PERMS
	}
	else pressreturn();
#endif
#endif
	clr() ;
	sprintf(genbuf,"boards/%s/%s",currboard,DIR) ;
	strncpy(currfile,fptr->filename,STRLEN) ;
	update_file(genbuf,sizeof(struct fileheader),idc,cmpfilename,updatefile) ;
	return 0 ;
}

/*ARGSUSED*/
sequential_read(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	clr() ;
	sequent_messages((struct fileheader *)NULL) ;
	sequent_ent = ent ;
	quiting = NA ;
	apply_record(strcat(bfile(currboard),DIR),sequent_messages,sizeof(struct fileheader)) ;
	return FULLUPDATE ;
}

#ifdef INTERNET_EMAIL
forward_post(ent,fileinfo,direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
	return(mail_forward(ent, fileinfo, direct));
}
#endif

extern int mainreadhelp() ;

struct one_key  read_comms[] = {
    'r',       read_post,
    'd',       del_post,
    'D',       del_range,
    'm',       mark_post,
    'E',       edit_post,
    's',       do_select,
    CTRL('P'),   do_post,
    'S',       sequential_read,
#ifdef INTERNET_EMAIL
    'F',       forward_post,
#endif
    'h',       mainreadhelp,
    CTRL('J'),   mainreadhelp,
    '\0',      NULL
  } ;


Read()
{
	if(!selboard) {
		move(2,0) ;
		prints("You must select a board first (Use (S)elect)\n") ;
		pressreturn() ;
		move(2,0) ;
		clrtoeol() ;
		return -1 ;
	}
        uinfo.mode = READING;
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	in_mail = NA;
	i_read(strcat(bfile(currboard),DIR),readtitle,readdoent,&read_comms[0]) ;
        uinfo.mode = MMENU;
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	return 0 ;
}

Goodbye()
{
	extern int started ;
	clr() ;
	refresh() ;
	reset_tty() ;
	printf("Goodbye!\n") ;
	report("exit") ;
	if(started)
	  if((ufp = fopen("usies","a")) != NULL) {
		  flock(fileno(ufp),LOCK_EX) ;
		  ti = time(0) ;
		  fprintf(ufp,"EXIT  %-10s %-20s %s",currentuser.userid,currentuser.username,ctime(&ti)) ;
		  fflush(ufp) ;
		  u_exit() ;
		  flock(fileno(ufp),LOCK_UN) ;
		  fclose(ufp) ;
	  }
	exit(0) ;
}


report(s)
char *s ;
{
	static int disable = NA ;
	int fd ;

	if(disable)
	  return ;
	if((fd = open("trace",O_WRONLY,0644)) != -1 ) {
		char buf[512] ;
		char timestr[10], *thetime;
		time_t dtime;
		time(&dtime);
		thetime = ctime(&dtime);
		strncpy(timestr, &(thetime[11]), 8);
		timestr[8] = '\0';
		flock(fd,LOCK_EX) ;
		lseek(fd,0,L_XTND) ;
		sprintf(buf,"%s %s %s\n",currentuser.userid, timestr, s) ;
		write(fd,buf,strlen(buf)) ;
		flock(fd,LOCK_UN) ;
		close(fd) ;
		return ;
	}
	disable = YEA ;
	return ;
}

char saveboard[STRLEN] ;

int tuid ;
int tfile, rfile ;

get_messages(fptr)
struct fileheader *fptr ;
{
	if(fptr->accessed[tuid] & FILE_READ)
	  rfile++ ;
	tfile++ ;
	return 0 ;
}


get_boards(fptr)
struct fileheader *fptr ;
{
	char buf[512] ;
	sprintf(buf,"boards/%s/%s",fptr->filename,DIR) ;
	apply_record(buf,get_messages,sizeof(struct fileheader)) ;
	return 0 ;
}

get_users(uptr)
struct userec *uptr ;
{
	struct userec u ;
	char tbuf[STRLEN] ;

	bcopy(uptr,&u,sizeof(u)) ;
	tfile = 0 ;
	rfile = 0 ;
	if(*(uptr->userid) == '\0') {
		tuid++ ;
		return 0 ;
	}

	strcpy(tbuf,ctime(&u.lastlogin)) ;
	strncpy(genbuf,tbuf+4,7) ;
	genbuf[7] = '\0' ;
	strcat(genbuf,tbuf+22) ;
#ifndef FILES
	printf("%-10s %-19s %-9s %-4d  %s",u.userid, u.username,
		   u.termtype, u.userlevel, genbuf) ;
#else
	printf("%-10s %-19s %-9s %-4d %6s  %s",u.userid, u.username,
		   u.termtype, u.userlevel, NameProtocol(u.protocol), genbuf) ;
#endif
	tuid++ ;
	return 0 ;
}



UserStatus()
{
	tuid = 1 ;
#ifndef FILES
        printf("%-10s %-19s %-9s %-4s  %s\n","USER ID", "USERNAME",
                   "TERMTYPE", "LEVL", "LAST LOGIN") ;
#else
	printf("%-10s %-19s %-9s %-4s %6s  %s\n","USER ID", "USERNAME",
		   "TERMTYPE", "LEVL", "PROTO", "LAST LOGIN") ;
#endif
	if(apply_record(PASSFILE, get_users, sizeof(struct userec)) == -1) {
		fprintf(stderr,"Error in apply_record\n") ;
		exit(-1) ;
	}
	return 0 ;
}

int m_count ;
int m_total ;

char atot[MAXUSERS] ;

g_messages(fptr)
struct fileheader *fptr ;
{
	int i ;
	int count = 0 ;

	printf("File: %s\n\n",fptr->title) ; 
	for(i = 1; i < MAXUSERS; i++)
	  if(fptr->accessed[i] & FILE_READ) {
		  struct userec us ;
		  atot[i] = 1 ;
		  get_record(PASSFILE,&us,sizeof us, i) ;
		  count++ ;
		  printf("%s ",us.userid) ;
	  }
	m_count++ ;
	m_total += count ;
	printf("\nCount = %d\n",count) ;
	return 0 ;
}


g_boards(fptr)
struct fileheader *fptr ;
{
	char buf[512] ;
	int i,total ;
	sprintf(buf,"boards/%s/%s",fptr->filename,DIR) ;
	printf("------------------------------------------Board: %s\n\n",fptr->filename) ;
	bzero(atot,sizeof(atot)) ;
	m_count = 0 ;
	m_total = 0 ;
	apply_record(buf,g_messages,sizeof(struct fileheader)) ;
	printf("AVG Read = %f\n",(double)m_total/(double)m_count) ;
	total = 0 ;
	for(i=1;i<MAXUSERS;i++) {
		if(atot[i])
		  total++ ;
	}
	printf("DVRS Read = %d\n",total) ;
	return 0 ;
}


BoardStatus()
{
	apply_boards(g_boards) ;
}

Info()
{
    more("Version.Info",YEA) ;
    clr() ;
    return 0 ;
}

Conditions()
{
    more("COPYING",YEA) ;
    clr() ;
    return 0 ;
}

Welcome()
{
    if (more("Welcome",YEA) == -1) {
	clr();
	prints("Welcome screen is not available at this time.\n");
	pressreturn();
	clr();
	return 0;
    }
    clr() ;
    return 0 ;
}

EditWelcome()
{
	int aborted;
	char ans[7];
	move(3,0);
	clrtoeol();
	clrtobot();
	getdata(3,0,"(E)dit or (D)elete Welcome? [E]: ",ans,7,DOECHO,NULL);
	if (ans[0] == 'D' || ans[0] == 'd') {
		unlink("Welcome");
		move(5,0);
		prints("It's history!\n");
		pressreturn();
		clr();
                sprintf(genbuf, "%s deleted Welcome\n", currentuser.userid) ;
                report(genbuf) ;
		return;
	}
	uinfo.mode = EDITWELC;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	aborted = vedit("Welcome", NA);		
	clr() ;
	if (aborted) prints("Welcome NOT changed.\n");
	else {
            report("edited Welcome screen") ;
            prints("Welcome updated.\n") ;
        }
        pressreturn() ;
	uinfo.mode = XMENU ;
	substitute_record(ULIST,(void *)&uinfo,sizeof(uinfo),utmpent) ;
        return 0 ;
}

cmpbnames(n, brec)
int n;
struct fileheader *brec;
{
	if (!ci_strncmp((char *)n, brec->filename, sizeof(brec->filename)))
	    return 1;
	else
	    return 0;
}

Zap()
{
        char bname[STRLEN] ;
	struct fileheader fh;
	int pos, zapped;
        uinfo.mode = ZAP;
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
        make_blist() ;
	clr();
        move(0,0) ;
        prints("Select Board to Zap/Unzap (upper/lower case does not matter)\n") ;
        prints("Board Name: ") ;
        clrtoeol() ;
        namecomplete((char *)NULL,bname) ;
        uinfo.mode = MMENU;
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	pos = search_record(BOARDS, &fh, sizeof(fh), cmpbnames, (int)bname);
	if (!pos) {
                move(3,0) ;
                prints("Invalid Board Name") ;
                move(0,0) ;
                clrtoeol() ;
		return 0;
        }
	zapped = (fh.accessed[usernum] & ZAPPED);
	zapped ? (fh.accessed[usernum] &= ~ZAPPED) : (fh.accessed[usernum] |= ZAPPED);
	move(3,0);
	if (substitute_record(BOARDS, &fh, sizeof(fh), pos) == -1)
	    prints("Error updating BOARDS file...\n");
	else {
	    numboards = -1;
	    prints("%s is now %s.\n", bname, zapped ? "Un-zapped" : "Zapped");
/*            sprintf(genbuf,"Zap '%s'",bname) ;
            report(genbuf) ;*/
	}
        move(0,0) ;
        clrtoeol() ;
        move(1,0) ;
        clrtoeol() ;
        return 0 ;
}


/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#if defined(IRIX) || defined(SOLARIS)
#define USES_UTMPX
#endif

#if defined(CLIX)
#define USES_UTMPX   /* but not really */
struct utmpx {
    char ut_user[8];
    char ut_line[12];
    char ut_host[66];
};
#define UTMPX_FILE "/etc/utmp2"
#endif

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <utmp.h>
#if defined (USES_UTMPX) && !defined(CLIX)
#include <utmpx.h>
#endif
#include <pwd.h> 

#ifndef UTMP_FILE
#define UTMP_FILE	"/etc/utmp"
#endif

extern char *ttyname(), *index(), *rindex() ;

#ifdef USES_UTMPX
struct utmpx *
invis2()
{
	static struct utmpx data ;
        int fd;
	int flag = 0 ;
	char *name, *tp ;
	struct passwd *pp ;
	
	tp = ttyname(0) ;
	if(!tp)
	return NULL ;
	tp = index(tp,'/') + 1 ;
	tp = index(tp,'/') + 1;
	pp = getpwuid(getuid()) ;
	if(!pp)
	{
		fprintf(stderr,"You Don't exist!\n") ;
		exit(0) ;
	}
	name = pp->pw_name ;
	
	if((fd = open(UTMPX_FILE, O_RDWR)) == -1)
		exit(0) ;
	while(read(fd,&data,sizeof(struct utmpx))>0)
	{
		if(
#if defined(DEAD_PROCESS) && !defined(CLIX)
		   data.ut_type != DEAD_PROCESS && 
#endif
		   !strcmp(tp,data.ut_line))
		{
			struct utmpx nildata ;
			flag = 1 ;
			bcopy(&data, &nildata, sizeof(nildata)) ;
#ifdef INVISIBLE
			bzero(nildata.ut_name,8) ;
			lseek(fd, -sizeof(struct utmpx), SEEK_CUR) ;
			write(fd,&nildata,sizeof(struct utmpx));
#endif
			close(fd) ;
			return &data ;
		}
	}
	close(fd) ;
	return NULL ;
}
#endif

struct utmp *
invis()
{
	static struct utmp data ;
        int fd ;
	int flag = 0 ;
	char *name, *tp ;
	struct passwd *pp ;

	tp = ttyname(0) ;
	if(!tp)
	return NULL ;
	tp = rindex(tp,'/') + 1 ;
	pp = getpwuid(getuid()) ;
	if(!pp)
	{
		fprintf(stderr,"You Don't exist!\n") ;
		exit(0) ;
	}
	name = pp->pw_name ;
	
	if((fd = open(UTMP_FILE, O_RDWR)) == -1)
		exit(0) ;

	while(read(fd,&data,sizeof(struct utmp))>0)
	{
		if(
#ifdef DEAD_PROCESS
                   data.ut_type != DEAD_PROCESS && 
#endif
                   !strcmp(tp,data.ut_line))
		{
			struct utmp nildata ;
			flag = 1 ;
			bcopy(&data, &nildata, sizeof(nildata)) ;
#ifdef INVISIBLE
#ifdef LINUX
			bzero(nildata.ut_user,8) ;
#else
			bzero(nildata.ut_name,8);
#endif
			lseek(fd, -sizeof(struct utmp), SEEK_CUR) ;
			write(fd,&nildata,sizeof(struct utmp));
#endif
			close(fd) ;
			return &data ;
		}
	}
	close(fd) ;
	return NULL ;
}

char *env[] = {
	"TERM=xxxxxxxxxxxxxxxxxxxxxxxxxxx",
	NULL} ;

main() 
{
    int uid ;

    uid = getuid() ;
    if(uid == BBSUID) { /* bbs uid */
#ifdef USES_UTMPX
	struct utmpx *whee;
#else
        struct utmp *whee ;
#endif
        char hid[17] ;

#ifdef USES_UTMPX
        invis();
        whee = invis2();
#else
        whee = invis() ;
#endif
#ifdef NO_CHROOT
	chdir(BBSHOME);
#else
        chroot(BBSHOME) ;
#endif
        setuid(uid) ;
        if(whee) {
	    if (whee->ut_host[0]) strncpy(hid, whee->ut_host, 16) ;
	    else gethostname(hid, 16);
            hid[16] = '\0' ;
            execl("bin/bbs","bbs","h", hid, NULL) ;
        }
        else
            execle("bin/bbs","bbs", NULL, env) ;
        printf("execl failed\n") ;
    }
    setuid(uid) ;
    printf("UID DOES NOT MATCH\n") ;
    exit(-1) ;
}


/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"

int numboards = -1 ;
struct shortfile bcache[MAXBOARD] ;

fillcache(fptr)
struct fileheader *fptr ;
{
#ifdef PERMS
    if (!(fptr->level & PERM_POSTMASK) && !HAS_PERM(fptr->level))
#else	
    if (fptr->level > currentuser.userlevel) 
#endif
	bcache[numboards].filename[0] = ' ';
    else
        strcpy(bcache[numboards].filename,fptr->filename) ;
    strcpy(bcache[numboards].owner,fptr->owner) ;
    strcpy(bcache[numboards].title,fptr->title) ;
    bcache[numboards].level = fptr->level;
    bcache[numboards].accessed = fptr->accessed[usernum];
    if(numboards < MAXBOARD)
      numboards++ ;
    return 0 ;
}

apply_boards(func)
int (*func)() ;
{
    register int i ;

    if(numboards < 0) {
        numboards = 0 ;
        apply_record(BOARDS,fillcache,sizeof(struct fileheader)) ;
    }
    
    for(i=0;i<numboards;i++)
      if(bcache[i].filename[0] != ' ')
        if((*func)(&bcache[i]) == QUIT)
	  return QUIT;
    return 0;
}

getbnum(bname)
char *bname ;
{
    register int i ;

    if(numboards < 0) {
        numboards = 0 ;
        apply_record(BOARDS,fillcache,sizeof(struct fileheader)) ;
    }

    for(i=0;i<numboards;i++)
      if(!ci_strncmp(bname,bcache[i].filename, sizeof(bcache[i].filename)))
        return i+1 ;
    return 0 ;
}

#ifdef PERMS
haspostperm(bname)
char *bname;
{
    register int i;
    if ((i = getbnum(bname)) == 0) return 0;
    if (!HAS_PERM(PERM_POST)) return 0;
    return (HAS_PERM(bcache[i-1].level & ~PERM_POSTMASK));
}
#endif

long ucached = 0 ;
char ucache[MAXUSERS][IDLEN+1] ;
int numuents = 0;

fillucache(uentp)
struct userec *uentp ;
{
    if(numuents < MAXUSERS) {
        strncpy(ucache[numuents],uentp->userid,IDLEN+1) ;
        ucache[numuents++][IDLEN] = '\0' ;
    }
    return 0 ;
}

resolve_ucache()
{
    struct stat st ;
    if(stat(FLUSH,&st) < 0) {
        st.st_mtime++ ;
    }
    if(ucached < st.st_mtime) {
        numuents = 0 ;
        apply_record(PASSFILE,fillucache,sizeof(struct userec)) ;
        ucached = st.st_mtime ;
    }
}

u_namelist()
{
    register int i ;

    resolve_ucache() ;
    CreateNameList() ;
    for(i=0; i < numuents; i++)
      if(ucache[i][0] != '\0')
        AddNameList(ucache[i]) ;
    return 0 ;
}


int
searchuser(userid)
char *userid ;
{
    register int i ;

    resolve_ucache() ;
    for(i=0; i < numuents; i++)
      if(!ci_strncmp(userid,ucache[i],IDLEN+1))
        return i+1 ;
    return 0 ;
}

apply_users(func)
void (*func)() ;
{
    register int i ;
    resolve_ucache() ;
    for(i=0; i < numuents; i++)
      (*func)(ucache[i],i+1) ;
    return 0 ;
}

struct userec lookupuser ;

int
getuser(userid)
char *userid ;
{
    int uid = searchuser(userid) ;
    if(uid == 0)
      return 0 ;
    get_record(PASSFILE,&lookupuser,sizeof(lookupuser),uid) ;
    return uid ;
}


#!/bin/sh

MAILDIR=~bbs/usr/spool/mqueue
SCRATCH=/tmp/bbs.$$

for QFILE in $MAILDIR/qf*
do
    if [ -r $QFILE ]
    then
        while read LINE
        do
            case $LINE in
              D*) DFILE=$MAILDIR/${LINE#D} 
                  ;;
              R*) ADDR=${LINE#R} 
                  ;;
              H*) HEADER=${LINE#H} 
                  echo $HEADER >> $SCRATCH
                  ;;
              id*)  echo "\t$LINE" >> $SCRATCH
            esac
        done < $QFILE
        echo >> $SCRATCH
        echo "--- Forwarded Message ---" >> $SCRATCH
        echo >> $SCRATCH
        cat $DFILE >> $SCRATCH      

        rmail $ADDR < $SCRATCH
        rm -f $QFILE $DFILE $SCRATCH
    fi
done

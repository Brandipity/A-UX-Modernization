/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"
#include <string.h>
#include <malloc.h>

struct word {
	char *word ;
	struct word *next ;
} ;

struct word *toplev = NULL, *current = NULL ;

FreeNameList() 
{
	struct word *p = toplev, *q;

        while (p) {     
		q = p->next;
		free(p->word) ;
		free(p) ;
		p = q;
	}
}

CreateNameList()
{
	if(toplev)
	  FreeNameList() ;
	toplev = NULL ;
	current = NULL ;
}

AddNameList(name)
char *name ;
{
	struct word *node ;

	node = (struct word *) malloc(sizeof(struct word)) ;
	node->next = NULL ;
	node->word = (char *) malloc(strlen(name)+1) ;
	strcpy(node->word,name) ;
	if(toplev) {
		current->next = node ;
		current = node ;
		return ;
	}
	toplev = node ;
	current = node ;
	return ;
}

NumInList(list)
register struct word *list ;
{
	register int i ;
	
	for(i=0;list != NULL;i++,list = list->next)
	  /*Null Statement*/ ;
	return i ;
}

ApplyToNameList(fptr)
int ((*fptr)()) ;
{
	struct word *p ;

	for(p = toplev;p!=NULL;p = p->next)
	  (*fptr)(p->word) ;
}


chkstr(tag,name)
char *tag, *name ;
{
	char *otag = tag;
	char *oname = name;
	while(*tag != '\0') {
		if(toupper(*tag) != toupper(*name)) 
		  return 0 ;
		tag++ ;
		name++ ;
	}

	if (*name == '\0' && *otag)
		strcpy(otag, oname);

	return 1 ;
}

struct word *
GetSubList(tag,list)
register char *tag ;
register struct word *list ;
{
	struct word *wlist,*wcurr ;

	wlist = NULL ;
	wcurr = NULL ;
	while(list != NULL) {
		if(chkstr(tag,list->word)) {
			register struct word *node ;
			
			node = (struct word *)malloc(sizeof(struct word)) ;
			node->word = list->word ;
			node->next = NULL ;
			if(wlist)
			  wcurr->next = node ;
			else
			  wlist = node ;
			wcurr = node ;
		}
		list = list->next ;
	}
	return wlist ;
}

ClearSubList(list)
struct word *list ;
{
	struct word *p;
	while(list) {
		p = list->next;
		free(list) ;
		list = p;
	}
}

MaxLen(list,count)
struct word *list ;
{
	int len = strlen(list->word) ;
	
	while(list!=NULL && count) {
		int t = strlen(list->word) ;
		if(t > len)
		  len = t ;
		list=list->next ;
		count-- ;
	}
	return len ;
}

#define NUMLINES (19)

namecomplete(prompt,data)
char *prompt, *data ;
{
	char *temp;
	int ch ;
	int count = 0 ;
	int clearbot = NA ;
	if(scrint) {
		struct word *cwlist,*morelist ;
		int x,y ;
		int origx, origy;
		if(prompt != NULL) {
			prints("%s",prompt) ;
			clrtoeol() ;
		}
		temp = data ;
		
		if(toplev == NULL)
		  AddNameList("") ;
		cwlist = GetSubList("",toplev) ;
		morelist = NULL ;
		getyx(&y,&x) ;
		getyx(&origy, &origx);
		while((ch = igetch()) != EOF)
		  {
			  if(ch == '\n' || ch == '\r') {
				  *temp = '\0' ;
				  prints("\n") ;
				  if(NumInList(cwlist) == 1)
					strcpy(data,cwlist->word) ;
				  ClearSubList(cwlist) ;
				  break ;
			  }
			  if(ch == ' ') {
				  int col,len ;
				  
				  if(NumInList(cwlist) == 1) {
					  strcpy(data,cwlist->word) ;
					  move(y,x) ;
					  prints("%s",data+count) ;
					  count = strlen(data) ;
					  temp = data + count ;
					  getyx(&y,&x) ;
					  continue ;
				  }
		                  clearbot = YEA ;
				  col = 0 ;
				  if(!morelist)
					morelist = cwlist ;
				  len = MaxLen(morelist,NUMLINES) ;
				  move(3,0) ;
				  clrtobot() ;
				  standout() ;
				  prints(
"------------------------------- Completion List -------------------------------") ;
				  standend() ;
				  while(len+col < 80) {
					  int i ;
					  for(i=NUMLINES;(morelist)&&(i>0);i--,morelist=morelist->next) {
						  move(4+(NUMLINES - i),col) ;
						  prints("%s",morelist->word) ;
					  }
					  col += len+2 ;
					  if(!morelist)
						break ;
					  len = MaxLen(morelist,NUMLINES) ;
				  }
				  if(morelist) {
					  move(23,0) ;
					  standout() ;
					  prints("-- More --") ;
					  standend() ;
				  }
				  move(y,x) ;
				  continue ;
			  }
			  if(ch == '\177' || ch == '\010') {

				  if(temp == data)
					continue ;
				  temp-- ;
				  count-- ;
				  *temp = '\0' ;
				  ClearSubList(cwlist) ;
				  cwlist = GetSubList(data,toplev) ;
				  morelist = NULL ;
				  x-- ;
				  move(y,x) ;
				  addch(' ') ;
				  move(y,x) ;
				  continue ;
			  }
			  if(count < STRLEN) {
				  struct word *node ;

				  *temp++ = ch ;
				  count++ ;
				  *temp = '\0' ;
				  node = GetSubList(data,cwlist) ;
				  if(node == NULL) {
					  bell() ;
					  temp-- ;
					  *temp = '\0' ;
					  count-- ;
					  continue ;
				  }
				  ClearSubList(cwlist) ;
				  cwlist = node ;
				  morelist = NULL ;
				  move(y,x) ;
				  addch(ch) ;
				  x++ ;
			  }
		  }
		if(ch == EOF)
		  longjmp(byebye,-1) ;
        prints("\n") ;
        refresh() ;
        if(clearbot) {
            move(3,0) ;
            clrtobot() ;
        }
	if (*data) { 
	    move(origy,origx); 
	    prints("%s\n", data); 
	}
	return 0 ;
	}
	if(prompt != NULL) {
		printf("%s",prompt) ;
		fflush(stdout) ;
	}
	if(!fgets(data,STRLEN,stdin))
	  longjmp(byebye,-1);
	if(temp = strchr(data,'\n'))
	  *temp = '\0' ;
	return 0 ;
}


/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#ifdef AUX
#include <sys/types.h>
#include "bbs.h"
#include <unistd.h>
#ifdef lint
#include <sys/uio.h>
#endif
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <errno.h>
#include <time.h>
#endif


#ifndef AUX
#include "bbs.h"
#include <sys/types.h>
#include <unistd.h>
#ifdef lint
#include <sys/uio.h>
#endif
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <errno.h>
#include <time.h>
#endif

#define M_INT 8 	/* monitor mode update interval */
#define P_INT 20        /* interval to check for page req. in talk/chat */

#ifdef REALINFO 
int real_user_names = 0;
#endif

#include "modetype.c"

int t_cmpuids();
extern char gb[];

ishidden(user)
char *user;
{
	int tuid;
	struct userec saverec;
	struct user_info uin;
	bcopy(gb, &saverec, sizeof(saverec));
	if (!(tuid = getuser(user))) return 0;
	search_record(ULIST, &uin, sizeof(uin), t_cmpuids, tuid);
        bcopy(&saverec, gb, sizeof(saverec));
	return(uin.invisible);
}	

char *
modestring(mode, towho, complete, chatid)
int mode, towho, complete;
char *chatid;
{
	static char modestr[STRLEN];
	struct userec urec;
	if (chatid) {
	    if (complete)
		sprintf(modestr, "%s as '%s'", ModeType(mode), chatid);
	    else return (ModeType(mode));
	    return (modestr);
	}			
	if (mode != TALK && mode != PAGE && mode != QUERY)
		return (ModeType(mode));
	if (get_record(PASSFILE, &urec, sizeof(urec), towho) == -1)
		return (ModeType(mode));
#ifdef PERMS
	if (mode != QUERY && !HAS_PERM(PERM_SEECLOAK) && 
#else
	if (mode != QUERY && currentuser.userlevel < SEE_CLOAK && 
#endif
	    ishidden(urec.userid)) return (ModeType(TMENU));	
	if (complete)
	    sprintf(modestr, "%s '%s'", ModeType(mode), urec.userid);
	else
	    return (ModeType(mode));
	return (modestr);
}

char
pagerchar(me, them, pager)
char *me, *them;
int pager;
{
	if (pager) return ' ';
	else if (can_override(them, -1, me)) return 'O';
	else return '*';
}

printcuent(uentp)
struct user_info *uentp ;
{
	struct userec utmp ;
	static int i ;
	char *field_2;
#ifdef REALINFO
	if (real_user_names) field_2 = "Real Name";
	else 
#endif
	field_2 = "User Name";
	if(uentp == NULL) {
		move(3,0) ;
		prints("%-12s %-20s %-20s %-1s %-1s %-9s\n","User Id",field_2,
#ifdef PERMS
                       "From","P", (HAS_PERM(PERM_SEECLOAK) ? "C" : " "), "Mode") ;
#else
                       "From","P", currentuser.userlevel >= SEE_CLOAK ? "C" : " ", "Mode") ;
#endif
		i = 3 ;
		return 0;
	}
	if(!uentp->active || !uentp->pid)
	  return 0;
#ifdef PERMS
	if(!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
#else
	if(currentuser.userlevel < SEE_CLOAK && uentp->invisible)
#endif
	  return 0;
	if(kill(uentp->pid,0) == -1)
	  return 0;
	if(i == 22) {
		int ch ;
		standout() ;
		prints("--MORE--") ;
		standend() ;
		clrtoeol();
		while((ch = igetch()) != EOF) {
			if(ch == '\n' || ch == '\r' || ch == ' ')
			  break ;
			bell() ;
		}
		move(3,0) ;
		prints("%-12s %-20s %-20s %-1s %-1s %-9s\n","User Id",field_2,
#ifdef PERMS
		       "From","P", (HAS_PERM(PERM_SEECLOAK) ? "C" : " "), "Mode") ;
#else
		       "From","P", currentuser.userlevel >= SEE_CLOAK ? "C" : " ", "Mode") ;
#endif
		i = 3 ;
		clrtobot() ;
	}
	get_record(PASSFILE,&utmp,sizeof(utmp),uentp->uid) ;
#ifdef REALINFO
	if (real_user_names)
	  prints("%-12s %-20s %-20s %c %1s %-20s\n",utmp.userid,
		utmp.realname,uentp->from,pagerchar(currentuser.userid,utmp.userid, uentp->pager),
		(uentp->invisible?"#":" "), modestring(uentp->mode, uentp->destuid, 1, (uentp->in_chat ? uentp->chatid : NULL)));
	else
#endif
	  prints("%-12s %-20s %-20s %c %1s %-20s\n",utmp.userid,
		utmp.username,uentp->from,pagerchar(currentuser.userid,utmp.userid,uentp->pager),
		(uentp->invisible?"#":" "), modestring(uentp->mode, uentp->destuid, 1, (uentp->in_chat ? uentp->chatid : NULL)));
	i++ ;
    return 0 ;
}

listcuent(uentp)
struct user_info *uentp ;
{
	struct userec utmp ;

	if(uentp == NULL) {
		CreateNameList() ;
		return 0;
	}
	if(uentp->uid == usernum)
	  return 0;
	if(!uentp->active || !uentp->pid)
	  return 0;
	if(uentp->mode == ULDL)
	  return 0;
#ifdef PERMS
	if(!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
#else
	if(currentuser.userlevel < SEE_CLOAK && uentp->invisible)
#endif
	  return 0;
	if(kill(uentp->pid,0) == -1)
	  return 0;
	get_record(PASSFILE,&utmp,sizeof(utmp),uentp->uid) ;
	AddNameList(utmp.userid) ;
    return 0 ;
}

extern int bfinger;

dumb_list(uentp)
struct user_info *uentp ;
{
	struct userec utmp ;

	if(uentp == NULL) {
#ifdef BOARDNAME
		if (bfinger) {
			sprintf(genbuf,"\n[%s]\n\n", BOARDNAME);
			write(1, genbuf, strlen(genbuf));
		      }
#endif
		sprintf(genbuf, "%-14s %-25s %-10s %-10s %-16s\n","User Id","User Name",
			"Term", "Mode", "From");
		write(1, genbuf, strlen(genbuf));
		return 0 ;
	}
	if(!uentp->active || !uentp->pid)
	  return 0 ;
	if(kill(uentp->pid,0) == -1)
	  return 0 ;
	if (bfinger && uentp->invisible) return 0;
	get_record(PASSFILE,&utmp,sizeof(utmp),uentp->uid) ;
	sprintf(genbuf,"%-14s %-25s %-10s %-10s %s\n",utmp.userid,utmp.username
           ,utmp.termtype,modestring(uentp->mode,uentp->destuid,0,NULL),uentp->from);
	write(1, genbuf, strlen(genbuf));
	return 1 ;
}

creat_list()
{
	listcuent(NULL) ;
	apply_record(ULIST,listcuent,sizeof(struct user_info)) ;
}

t_users()
{
	int savemode = uinfo.mode;
        uinfo.mode = LUSERS;  
        substitute_record(ULIST,&uinfo,sizeof(uinfo),utmpent) ;
/*	report("talk user list") ; */
	printcuent(NULL) ;
	if(apply_record(ULIST,printcuent,sizeof(struct user_info)) == -1) {
		prints("No Users Exist\n") ;
		pressreturn() ;
		uinfo.mode = TMENU;
	        substitute_record(ULIST,&uinfo,sizeof(uinfo),utmpent) ;
		return 0;
	}
	clrtobot() ;
	uinfo.mode = savemode;
        substitute_record(ULIST,&uinfo,sizeof(uinfo),utmpent) ;
	return 0;
}

#ifdef REALINFO
t_rusers()
{
	real_user_names = 1;
	t_users();
	real_user_names = 0;
}
#endif

t_pager()   /*     Pager Toggle   --gtv     */
{
    if (uinfo.pager == YEA){
	  if (!uinfo.in_chat){
	    move(3,0);
	    prints("Pager turned off.\n");
	    report("pager off");
            uinfo.pager = NA ;
	    clrtobot();
          }
	  else
	    uinfo.pager = NA ;
    }	  
    else {
          if (!uinfo.in_chat){
	    move(3,0);
	    prints("Pager turned on.\n");
	    report("pager on");
            uinfo.pager = YEA ;
	    clrtobot();
	  }
	  else
   	    uinfo.pager = YEA ;
     }
    substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
}

t_query()
{
	char uident[STRLEN], inbuf[STRLEN*2], *newline ;
	extern char currmaildir[4096] ;
	int tuid, i;
	FILE *planfile;
	
	uinfo.mode = QUERY;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	move(2,0) ;
	prints("<Enter Userid>\n") ;
	move(1,0) ;
	clrtoeol() ;
	prints("Query who: ") ;
	u_namelist();
	namecomplete(NULL,uident) ;
	if(uident[0] == '\0') {
		clr() ;
		uinfo.mode = TMENU;
		substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
		return 0 ;
	}
	if(!(tuid = getuser(uident))) {
		move(2,0) ;
		prints("Bad User ID\n") ;
		pressreturn() ;
		move(2,0) ;
		clrtoeol() ;
		uinfo.mode = TMENU;
 		substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
		return -1 ;
	}
	uinfo.destuid = tuid ;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);

	move(3,0);
	clrtobot();
	sprintf(genbuf, "query %s", lookupuser.userid);
	report(genbuf);
	prints("%s (%s), %d logins, %d posts.\n", lookupuser.userid, 
	  lookupuser.username, lookupuser.numlogins, lookupuser.numposts);
	strcpy(genbuf, ctime(&(lookupuser.lastlogin)));
	if (newline = index(genbuf, '\n')) *newline = '\0';
	prints("Last login %s from %s\n", genbuf, (lookupuser.lasthost[0] == '\0' ?
	  "(unknown)" : lookupuser.lasthost));
#if defined(REALINFO) && defined(QUERY_REALNAMES)
#ifdef PERMS
	if (HAS_PERM(PERM_BASIC))	
#endif
	  prints("Real Name: %s \n",lookupuser.realname);
#endif
/*	  sprintf(currmaildir,"mail/%s/%s",lookupuser.userid,DIR) ;
	  if (chkmail()) prints(" -- Has Unread Mail.\n");
	  else prints(" -- Has No Unread Mail.\n") ;
	  sprintf(currmaildir,"mail/%s/%s",currentuser.userid,DIR);
	  if (chkmail());;     */

	sprintf(genbuf, "plans/%s", lookupuser.userid);
	if ((planfile = fopen(genbuf, "r")) == NULL)
	    prints("No plan.\n");
	else {
	    prints("Plan:\n\n");
	    for (i=1; i<=MAXQUERYLINES; i++) {
		if (fgets(inbuf, sizeof(inbuf), planfile))
		    prints("%s", inbuf);
		else break;
	    }
	    fclose(planfile);
	}
	pressreturn();
        uinfo.destuid = 0;
	uinfo.mode = TMENU;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
}		

dumb_user_list()
{
	dumb_list(NULL) ;
	if(apply_record(ULIST,dumb_list,sizeof(struct user_info)) == -1) {
		write(1, "No Users Exist\n", 15) ;
	}
	if (bfinger) write(1, "\n", 1);
}

do_all_list(uentp)
struct user_info *uentp ;
{
	struct userec utmp ;
	char *ctime() ;

	if(uentp == NULL) {
		printf("%-14s %-25s %-10s\n","User Id","User Name","Termtype") ;
		return 0 ;
	}
/*	if(kill(uentp->pid,0) == -1)
	  return 0 ;*/
	get_record(PASSFILE,&utmp,sizeof(utmp),uentp->uid) ;
	if(utmp.username[0] == '\0')
	  return 0 ;
	printf("%-14s %s",utmp.userid,ctime(&(utmp.lastlogin)));
	printf("%-14s %-25s %-10s %-9s %-16s %-6s\n",utmp.userid,utmp.username
           ,utmp.termtype,ModeType(uentp->mode),uentp->from,
           (uentp->active)?"ACTIVE":"") ;
	return 1 ;
}


list_all_users()
   {  
    uinfo.mode = LAUSERS;  
    do_all_list(NULL) ;
    if(apply_record(ULIST,do_all_list, sizeof(struct user_info)) == -1) {
        printf("No Users Exist") ;
    }
}   
		/*  begin part added from pbbs 1.8 --gtv */
count_active(uentp)
struct user_info *uentp ;
{
    struct userec utmp ;
    static int count ;
    if(uentp == NULL) {
      int c = count ;
      count = 0 ;
      return c ;
    }
    if(!uentp->active || !uentp->pid)
      return 0 ;
    if(kill(uentp->pid,0) == -1)
      return 0 ;
    get_record(PASSFILE, &utmp, sizeof(utmp), uentp->uid);
#ifdef PERMS
    if (utmp.userlevel & PERM_MULTILOG) return 0; /* don't count multiloggers */
#else
    if (utmp.userlevel >= MULTILOGOK) return 0 ; /* don't count multiloggers */
#endif
    count++ ;
    return 1 ;
}

int num_active_users()
{
    count_active(NULL) ;
    apply_record(ULIST,count_active,sizeof(struct user_info)) ;
    return count_active(NULL) ;
}                 /*  end part added from pbbs 1.8 --gtv */


t_cmpuids(uid,up)
int uid ;
struct user_info *up ;
{
    return (uid == up->uid) ;
}

t_talk()
{
	char uident[STRLEN] ;
	int tuid ;
	struct user_info uin ;

	move(2,0) ;
	prints("<Enter Userid>\n") ;
	move(1,0) ;
	clrtoeol() ;
	prints("To: ") ;
	creat_list() ;
	namecomplete(NULL,uident) ;
	if(uident[0] == '\0') {
		clr() ;
		return 0 ;
	}
        if(!(tuid = getuser(uident)) || tuid == usernum) {
		move(2,0) ;
		prints("Bad User ID\n") ;
		pressreturn() ;
		move(2,0) ;
		clrtoeol() ;
		return -1 ;
	}
	search_record(ULIST,&uin,sizeof(uin),t_cmpuids,tuid) ;
	/*  check if pager on/off       --gtv */
#ifdef PERMS
	if (!HAS_PERM(PERM_SYSOP)) {
#else
	if (currentuser.userlevel<255) {
#endif
            if (uin.pager == NA && !can_override(NULL, tuid, currentuser.userid)) {
		move(2,0) ;
		prints("User's pager is turned off.\n") ;
		pressreturn() ;
		move(2,0) ;
		clrtoeol() ;
		return -1 ;
            }
	}
	if(uin.mode == ULDL || uin.mode == IRCCHAT || 
           uin.mode == BBSNET || uin.mode == FOURM) {
		move(2,0) ;
		prints("User is in a non-pageable mode.\n") ;
		pressreturn() ;
		move(2,0) ;
		clrtoeol() ;
		return -1 ;
	}
	if(!uin.active || (kill(uin.pid,0) == -1)) {
		move(2,0) ;
		prints("User not logged in\n") ;
		pressreturn() ;
		move(2,0) ;
		clrtoeol() ;
		return -1 ;
	} else {
		int sock, msgsock, length ;
		struct sockaddr_in server ;
		char c ;
		char buf[512] ;

		sprintf(buf,"Talk to '%s'",uident) ;
		report(buf) ;
		sock = socket(AF_INET, SOCK_STREAM, 0) ;
		if(sock < 0) {
			perror("opening stream socket\n") ;
			return -1 ;
		}

		server.sin_family = AF_INET ;
		server.sin_addr.s_addr = INADDR_ANY ;
		server.sin_port = 0 ;
		if(bind(sock, (struct sockaddr *) & server, sizeof server ) < 0) {
			perror("binding stream socket") ;
			return -1 ;
		}
		length = sizeof server ;
		if(getsockname(sock, (struct sockaddr *) &server, &length) < 0) {
			perror("getting socket name") ;
			return -1 ;
		}
		uinfo.sockactive = YEA ;
		uinfo.sockaddr = server.sin_port ;
		uinfo.destuid = tuid ;
		uinfo.mode = PAGE;
		substitute_record(ULIST,&uinfo, sizeof(uinfo), utmpent) ;
		kill(uin.pid,SIGUSR1) ;
		clr() ;
		prints("Paging %s.....\nTYPE CTRL-D to terminate\n", uident) ;
		listen(sock,1) ;
	        add_io(sock,20) ;
		while(YEA) {
	                int ch ;
                        ch = igetch() ;
			if(ch == I_TIMEOUT) {
#ifdef LINUX
                                add_io(sock,20);
#endif
				move(0,0) ;
				prints("Ringing Party Again.\n") ;
				bell() ;
				if(kill(uin.pid,SIGUSR1) == -1) {
					move(0,0) ;
					prints("Party has logged off\n\n\n") ;
					pressreturn() ;
					uinfo.mode = TMENU;
				        substitute_record(ULIST,&uinfo,sizeof(uinfo),utmpent) ;
					return -1 ;
				}
				continue ;
			}
	                if(ch == I_OTHERDATA)
        	          break ;
            	        if(ch == '\004') {
                	  add_io(0,0) ;
               	          close(sock) ;
                          uinfo.sockactive = NA ;
                          uinfo.destuid = 0 ;
		          uinfo.mode = TMENU;
                          substitute_record(ULIST,&uinfo, sizeof(uinfo), utmpent) ;
                          clr() ;
                          return 0 ;
                        }
		}

		msgsock = accept(sock, (struct sockaddr *)0, (int *) 0) ;
		if(msgsock == -1) {
			perror("accept") ;
			uinfo.mode = TMENU;
			substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
			return -1 ;
		}
	        add_io(0,0) ;
		close(sock) ;
		uinfo.sockactive = NA ;
/*		uinfo.destuid = 0 ;*/
		read(msgsock,&c,sizeof c) ;
		if(c == 'y') 
		  do_talk(msgsock) ;
		else {
			clr() ;
			prints("Talk request not accepted.\n") ;
			pressreturn() ;
		}
		close(msgsock) ;
		clr() ;
		uinfo.destuid = 0;
		uinfo.mode = TMENU;
		substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	}
	return 0 ;
}

extern int talkrequest ;
struct user_info  ui ;
char page_requestor[STRLEN];

int cmpunums(unum,up)
int unum ;
struct user_info *up ;
{
    if(!up->active)
      return 0 ;
	return (unum == up->destuid) ;
}

int
searchuserlist(unum)
{
	return search_record(ULIST,&ui,sizeof(ui),cmpunums,unum) ;
}

setpagerequest()
{
	int tuid;
	struct userec au;
	tuid = searchuserlist(usernum) ;
	if(tuid == 0)
	  return 1;
	if(!ui.sockactive)
	  return 1;
	get_record(PASSFILE,&au,sizeof(au),ui.uid) ;
	uinfo.destuid = ui.uid;
	sprintf(page_requestor, "%s (%s)", au.userid, au.username);
	return 0;
}

servicepage(arg)
int arg;
{
	static time_t last_check;
	time_t now;
	char buf[STRLEN];
        int tuid = searchuserlist(usernum) ;
        if(tuid == 0 || !ui.sockactive) talkrequest = NA;
        if (!talkrequest) {
          if (page_requestor[0]) {
	    switch (uinfo.mode) {
	      case TALK:
		move(arg, 0);
		prints("-----------------------------------------------------------");
		break;
	      default: /* a chat mode */
                sprintf(buf, "** INFO: no longer paged by %s", page_requestor);
                printchatline(buf);
	    }
            bzero(page_requestor, STRLEN);
            last_check = 0;
          }
	  return NA;
        }
        else {
          now = time(0);
          if (now - last_check > P_INT) {
            last_check = now;
            if (!page_requestor[0] && setpagerequest())
	      return NA;
            else
	      switch (uinfo.mode) {
		case TALK:
		  move(arg, 0);
		  prints("--- ** INFO: being paged by %s", page_requestor);
		  break;
		default: /* chat */
                  sprintf(buf, "** INFO: being paged by %s", page_requestor);
                  printchatline(buf);
	      }
          }
        }
	return YEA;
}


talkreply()
{
	int a ;
#ifndef INET_ADDRESS
	struct hostent *h ;
	char hostname[STRLEN] ;
#endif
	char buf[512] ;
	struct sockaddr_in sin ;

	talkrequest = NA ;
	if (setpagerequest()) return 0;	
	clr() ;
	prints("Would you like to talk with %s?\n", page_requestor) ;
	bzero(page_requestor, sizeof(page_requestor));
	getdata(2,0,"(Yes or No) [Y]: ",buf,STRLEN,DOECHO,NULL) ;
        bzero(&sin, sizeof sin);
#ifdef INET_ADDRESS
        sin.sin_family = PF_INET;
        sin.sin_addr.s_addr = inet_addr(INET_ADDRESS);
#else
	gethostname(hostname,STRLEN) ;
	if(!(h = gethostbyname(hostname))) {
		perror("gethostbyname") ;
		return -1 ;
	}
	sin.sin_family = h->h_addrtype ;
	bcopy(h->h_addr, &sin.sin_addr,h->h_length) ;
#endif
	sin.sin_port = ui.sockaddr ;
	a = socket(sin.sin_family,SOCK_STREAM,0) ;
	if((connect(a,(struct sockaddr *)&sin, sizeof sin))) {
		perror("connect failed") ;
		return -1 ;
	}
	if(buf[0] != 'n' && buf[0] != 'N') buf[0] = 'y';
	write(a,buf,1) ;
	if(buf[0] != 'y') {
		close(a) ;
		report("page refused");
#ifdef LINUX
		talkrequest = NA;
#endif
  		clr() ;
		return 0 ;
	}
	report("page accepted");
	do_talk(a) ;
	close(a) ;
	clr() ;
	return 0 ;
}


dotalkent(uentp, buf)
struct user_info *uentp;
char *buf;
{
    struct userec utmp;
    char mch;
    if (!uentp->active || !uentp->pid) return -1;
#ifdef PERMS
    if(!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
#else
    if(currentuser.userlevel < SEE_CLOAK && uentp->invisible)
#endif
        return -1;
    if(kill(uentp->pid,0) == -1) return -1;
    get_record(PASSFILE, &utmp, sizeof(utmp), uentp->uid);
    switch(uentp->mode) {
      case ULDL: mch = 'U'; break;
      case TALK: mch = 'T'; break;
      case CHAT1:
      case CHAT2:
      case CHAT3:
      case CHAT4: mch = 'C'; break;
      case IRCCHAT: mch = 'I'; break;
      case FOURM: mch = '4'; break;
      case BBSNET: mch = 'B'; break;
      case READNEW:
      case READING: mch = 'R'; break;
      case POSTING: mch = 'P'; break;
      case SMAIL:
      case RMAIL:
      case MAIL: mch = 'M'; break;
      default: mch = '-';
    }
    sprintf(buf, "%s%s(%c), ", uentp->invisible?"*":"", utmp.userid, mch);
    return 0;
}
 
extern int t_columns;
 
dotalkuserlist(sline,eline,curln,curcol,wordbuf,wordbuflen)
int sline, eline;
int *curln, *curcol;
char *wordbuf;
int *wordbuflen;
{
    char *s = "\n*** Users logged in ***\n";
    char bigbuf[STRLEN];
    char littlebuf[20];
    int fd, savecolumns, pos = 0;
    struct user_info uent;
    savecolumns = (t_columns > STRLEN ? t_columns : 0);
    bigbuf[0] = '\0';
    if ((fd = open(ULIST,O_RDONLY,0)) == -1) return -1;
    do_talk_string(sline,eline,curln,curcol,wordbuf,wordbuflen,s);
    while(read(fd, &uent, sizeof(uent)) == sizeof(uent)) {
	if (dotalkent(&uent, littlebuf) == -1) continue;        
	if (pos + strlen(littlebuf) >= t_columns) {
	    do_talk_string(sline,eline,curln,curcol,wordbuf,wordbuflen,bigbuf);
	    bigbuf[0] = '\0';
	    pos = 0;
        }
	strcat(bigbuf, littlebuf);
	pos += strlen(littlebuf);
    }
    if (pos > 0) {
	bigbuf[pos-2] = '\n';
        bigbuf[pos-1] = '\0';
	do_talk_string(sline,eline,curln,curcol,wordbuf,wordbuflen,bigbuf);
    }
    close(fd);        
    if (savecolumns) t_columns = savecolumns;        
}

do_talk_string(sline,eline,curln,curcol,wordbuf,wordbuflen,s)
int sline, eline;
int *curln, *curcol;
char *wordbuf;
int *wordbuflen;
char *s;
{
    while (*s) {
	do_talk_char(sline,eline,curln,curcol,wordbuf,wordbuflen,*s);
	s++;
    }
}

 
do_talk_char(sline,eline,curln,curcol,wordbuf,wordbuflen,ch)
int sline, eline ;
int *curln, *curcol ;
char *wordbuf ;
int *wordbuflen ;
int ch ;
{
    extern int dumb_term ;
#ifdef BIT8
    if(isprint2(ch)) {
#else
    if(isprint(ch)) {
#endif
        if(*curcol != 79) {
            wordbuf[(*wordbuflen)++] = ch ;
            if(ch == ' ')
              *wordbuflen = 0 ;
            move(*curln,(*curcol)++) ;
            prints("%c",ch) ;
            return ;
        }
        if(ch == ' ' || *wordbuflen >=78) {
            (*curln)++ ;
            *curcol = 0 ;
            if(*curln > eline)
              *curln = sline ;
            if((*curln) != eline) {
                move((*curln)+1,0) ;
                clrtoeol() ;
            }
            move(*curln,*curcol) ;
            clrtoeol() ;
            *wordbuflen = 0 ;
            return ;
        }
        move(*curln,(*curcol) - *wordbuflen) ;
        clrtoeol() ;
        (*curln)++ ;
        *curcol = 0 ;
        if(*curln > eline)
          *curln = sline ;
        if((*curln) != eline) {
            move((*curln)+1,0) ;
            clrtoeol() ;
        }
        move(*curln,*curcol) ;
        clrtoeol() ;
        wordbuf[*wordbuflen] = '\0' ;
        if(dumb_term)
          prints("\n") ;
        prints("%s%c",wordbuf,ch) ;
        *curcol = (*wordbuflen)+1 ;
        *wordbuflen = 0 ;
        return ;
    }
    switch(ch) {
      case CTRL('H'):
      case '\177':
        if(dumb_term)
          ochar(CTRL('H')) ;
        if(*curcol == 0) {
            if(sline == 0)
              bell() ;
            return;
        }
        (*curcol)-- ;
        move(*curln,*curcol) ;
        if(!dumb_term)
          prints(" ") ;
        move(*curln,*curcol) ;
        if(*wordbuflen)
          (*wordbuflen)-- ;
        return ;
      case CTRL('M'):
      case CTRL('J'):
        if(dumb_term)
          prints("\n") ;
        (*curln)++ ;
        *curcol = 0 ;
        if(*curln > eline)
          *curln = sline ;
        if((*curln) != eline) {
            move((*curln)+1,0) ;
            clrtoeol() ;
        }
        move(*curln,*curcol) ;
        clrtoeol() ;
        *wordbuflen = 0 ;
        return ;
      case CTRL('G'):
        bell() ;
        return ;
      default:
        break ;
    }
    return ;
}

char talkobuf[80] ;
int talkobuflen ;
int talkflushfd ;

talkflush()
{
    if(talkobuflen) 
      write(talkflushfd,talkobuf,talkobuflen) ;
    talkobuflen = 0 ;
}

do_talk(fd)
int fd ;
{
    int i ;
    int myln,mycol,myfirstln,mylastln  ;
    int itsln,itscol,itsfirstln,itslastln ;
    char itswordbuf[80],mywordbuf[80] ;
    int itswordbuflen,mywordbuflen ;
    int page_pending = NA;
    itswordbuflen = 0 ;
    mywordbuflen = 0 ;
    talkobuflen = 0 ;
    talkflushfd = fd ;
    uinfo.mode = TALK ;
    substitute_record(ULIST,&uinfo, sizeof(uinfo), utmpent) ;
    clr() ;
    myfirstln = 0 ;
    mylastln = (t_lines-1)/2 - 1 ;
    move(mylastln+1,0) ;
    prints("--------------------------------------------------------------------------------") ;
    itsfirstln = mylastln+2 ;
    itslastln = (t_lines -1) ;
    myln = myfirstln ;
    mycol = 0 ;
    itsln = itsfirstln ;
    itscol = 0 ;
    move(myln,mycol) ;
    add_io(fd,0) ;
    add_flush(talkflush) ;
    while(YEA) {
        int ch ;
	if (talkrequest) page_pending = YEA;
	if (page_pending)
	  page_pending = servicepage(mylastln+1);
        ch = igetch() ;
	if(ch == I_OTHERDATA) {
            char data[80] ;
            int datac ;
            register int i ;

            datac = read(fd,data,80) ;
            if(datac<=0) 
              break ;
            for(i=0;i<datac;i++)
              do_talk_char(itsfirstln,itslastln,&itsln,&itscol,itswordbuf,
                           &itswordbuflen,data[i]) ;
	} else {
            if(ch == CTRL('D') || ch == CTRL('C'))
              break ;
#ifdef BIT8
	    if(isprint2(ch) || ch == CTRL('H') || ch == '\177' || ch == CTRL('G')
#else
            if(isprint(ch) || ch == CTRL('H') || ch == '\177' || ch == CTRL('G')
#endif
               || ch == CTRL('M') || ch == CTRL('M')) {
                talkobuf[talkobuflen++] = ch ;
                if(talkobuflen == 80)
                  talkflush() ;
                do_talk_char(myfirstln,mylastln,&myln,&mycol,mywordbuf,
                             &mywordbuflen,ch) ;
	    }
	    else if (ch == CTRL('U') || ch == CTRL('W')) dotalkuserlist(myfirstln,mylastln,&myln,
		 &mycol,mywordbuf,&mywordbuflen);
#ifdef PERMS
            else if (ch == CTRL('P') && HAS_PERM(PERM_BASIC)) {
#else
	    else if (ch == CTRL('P')) {
#endif
               if (uinfo.pager == YEA){
		   do_talk_string(myfirstln,mylastln,&myln,&mycol,mywordbuf,&mywordbuflen,"*** Pager turned off ***\n");
                   uinfo.pager = NA ;
               } else {
		   do_talk_string(myfirstln,mylastln,&myln,&mycol,mywordbuf,&mywordbuflen,"*** Pager turned on ***\n");
                   uinfo.pager = YEA ;
               }
               substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
            }
            else bell() ;
	}
    }
    add_io(0,0) ;
    talkflush() ;
    add_flush(NULL) ;
    uinfo.mode = TMENU ;
    substitute_record(ULIST,&uinfo, sizeof(uinfo), utmpent) ;
}

shortulist(uentp)
struct user_info *uentp;
{
	static int fullcount = 0;
	static int lineno;
	static int cnt;
	static char *nullstring = "                        ";
	int finaltally;
	char uentry[30];
	struct userec utmp;
	if (!lineno) {
		lineno = 5;
		move(lineno, 0);
	}
	if (uentp == NULL) {
	    clrtoeol();
	    move(++lineno, 0);
	    clrtobot();
	    lineno = 0;
 	    cnt = 0;
	    finaltally = fullcount;
	    fullcount = 0;
	    return finaltally;
	}
	uentry[0]='\0';
	if (!uentp->active || !uentp->pid)
		strcpy(uentry, nullstring);
#ifdef PERMS
	if (!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
#else
	if (currentuser.userlevel < SEE_CLOAK && uentp->invisible)
#endif
		strcpy(uentry, nullstring);
	if (kill(uentp->pid,0)==-1) strcpy(uentry, nullstring);
	get_record(PASSFILE, &utmp, sizeof(utmp), uentp->uid);
	if (!uentry[0]) {
        	sprintf(uentry, "%-12s %c%-10s", utmp.userid, uentp->invisible?'#':' ', modestring(uentp->mode, uentp->destuid, 0, NULL));
		fullcount++;
	}
	if (++cnt < 3) strcat(uentry, " | ");
	prints(uentry);
	if (cnt == 3) {
		cnt = 0;
		clrtoeol();
		move(++lineno, 0);
		/* assuming no more than 60 logins at once */
	}
	return 0;
}

do_list()
{       
	int count;
        move(3,0);
        prints("%-12s  %-10s | %-12s  %-10s | %-12s  %-10s",
 	        "User ID", "Mode", "User ID", "Mode", "User ID", "Mode");
	move(4,0);
	prints("%-12s  %-10s | %-12s  %-10s | %-12s  %-10s",
		"-------", "----", "-------", "----", "-------", "----");
        if(apply_record(ULIST,shortulist,sizeof(struct user_info)) == -1) {
                prints("No Users Exist\n") ;
                return 0;
        }
	count = shortulist(NULL);
	if (uinfo.mode == MONITOR) {
		time_t thetime = time(0);		
		move(0,30) ;
		if(chkmail())
		    prints("(You have mail.)") ;
		move(t_lines-1, 0);
		prints("%d user(s) online. It is now %s",count, ctime(&thetime));
	}
	if (dumb_term) oflush();
	else refresh();
}

t_list()
{
	uinfo.mode = LUSERS;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
/*	report("talk user list");*/
	do_list();
        uinfo.mode = TMENU;
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	return 0;
}

int idle_monitor_time;

void
sig_catcher()
{
	if (uinfo.mode != MONITOR) {
#ifdef DOTIMEOUT
		init_alarm();
#else
		signal(SIGALRM, SIG_IGN);
#endif
		return;
        }		
#if CLIX
	if (signal(SIGALRM, (void (*)(int))sig_catcher)==SIG_ERR) {
#else
	if (signal(SIGALRM, sig_catcher)==SIG_ERR) {
#endif
		perror("signal");
		exit(1);
	}
#ifdef DOTIMEOUT
	idle_monitor_time += M_INT;
	if (idle_monitor_time > MONITOR_TIMEOUT) {
		clr();
		fprintf(stderr, "Monitor idle timeout exceeded! Booting...\n");
		kill(getpid(), SIGHUP);
	}
#endif
	do_list();
	alarm(M_INT);
}

t_monitor()
{
	char c;
	int i;
	alarm(0);
#if CLIX
	signal(SIGALRM, (void (*)(int))sig_catcher);
#else
	signal(SIGALRM, sig_catcher);
#endif
	uinfo.mode = MONITOR;
	idle_monitor_time = 0;
	/* report("monitor"); */
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);	
	move(1,0);
	prints("Monitor Mode\n");
	move(2,0);
	prints("Updates every %d seconds -- press CTRL-C or CTRL-D to exit.", M_INT);
	do_list();
	alarm(M_INT);
	while (YEA) {
	    i = read(0,&c,1);
	    if (!i || c == CTRL('D') || c == CTRL('C')) break;
	    else if (i == -1) 
		{ if (errno != EINTR) { perror("read"); exit(1); } }
	    else idle_monitor_time = 0;
	}
	move(2,0);
	clrtoeol();
	uinfo.mode = TMENU;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);	
	return 0;
}

#ifdef IRC
t_irc()
{
    char buf[512] ;
    int save_pager = uinfo.pager;
    uinfo.pager = NA;
    uinfo.mode = IRCCHAT ;
    substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent) ;
    sprintf(buf,"irc %s %s", currentuser.userid, IRC_SERVER) ;
    report("IRC Chat");
    reset_tty() ;
    do_exec(buf,NULL) ;
    restore_tty() ;
    uinfo.pager = save_pager;
    uinfo.mode = TMENU ;
    substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent) ;
    clr() ;
}
#endif /* IRC */

#ifdef MMMM

t_4m()   /* Bill Schwartz */
{
    char buf[512] ;
    int save_pager = uinfo.pager;
    uinfo.pager = NA;
    uinfo.mode = FOURM ;
    report("4m started");
    substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent) ;
    sprintf(buf,"fourm_rc/%s", currentuser.userid) ;
    if (access(buf, R_OK) !=0)
       sprintf(buf,"4m -rn %s -l %s", currentuser.userid,currentuser.userid);
    else
       sprintf(buf,"4m -r -l %s -f fourm_rc/%s", currentuser.userid,currentuser.userid);
    reset_tty() ;
    do_exec(buf,NULL) ;
    restore_tty() ;
    uinfo.pager = save_pager;
    uinfo.mode = TMENU ;
    substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent) ;
    clr() ;
}

#endif /* MMMM */

/* rrr -- stuff for providing pager override lists follows */

can_override(userid, uid, whoasks)
char *userid;
int uid;
char *whoasks;
{
    struct userec utmp;
    FILE *fp;
    char buf[STRLEN];
    int blen;
    if (userid == NULL) {
        if (get_record(PASSFILE,&utmp,sizeof(utmp),uid) == -1)
    	    return 0;
	userid = utmp.userid;
    }
    sprintf(buf, "overrides/%s", userid);
    if ((fp = fopen(buf, "r")) == NULL)
	return 0;
    while (fgets(buf, STRLEN, fp) != NULL) {
        blen = strlen(buf);
        if (buf[blen-1] == '\n')
	    buf[--blen] = '\0';
        if (!strncmp(buf, whoasks, blen)) {
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

listfriends()
{
	FILE *fp;
	int x = 0, y = 3, cnt = 0;
	char *nl;
	move(y,x);
	CreateNameList();
	sprintf(genbuf, "overrides/%s", currentuser.userid);
	if ((fp = fopen(genbuf, "r")) == NULL) {
	    prints("(none)\n");
	    return 0;
        }
	while(fgets(genbuf, STRLEN, fp) != NULL) {
	    prints("%s", genbuf);
	    if (nl = rindex(genbuf, '\n')) *nl = '\0';
	    AddNameList(genbuf);
	    cnt++;
            if ((++y) >= t_lines-1) {
		y = 3;
		x += 16;
            }
	    move(y,x);
	}
	fclose(fp);
	if (cnt == 0) prints("(none)\n");
	return cnt;
}

addtooverride(uident)
char *uident;
{
	FILE *fp;
	int rc;
	if (can_override(currentuser.userid, usernum, uident)) return -1;
	sprintf(genbuf, "overrides/%s", currentuser.userid);
	if ((fp = fopen(genbuf, "a")) == NULL)
	    return -1;
	flock(fileno(fp), LOCK_EX);
	rc = fputs(uident, fp);
	fputc('\n', fp);
	flock(fileno(fp), LOCK_UN);
	fclose(fp);
	return(rc == EOF ? -1 : 0);
}		

deleteoverride(uident)
char *uident;
{
	FILE *fp, *nfp;
	int deleted = NA;
	char fn[STRLEN], fnnew[STRLEN];
	sprintf(fn, "overrides/%s", currentuser.userid);
	if ((fp = fopen(fn, "r")) == NULL) return -1;
	sprintf(fnnew, "overrides/%s.%d", currentuser.userid, getuid());
	if ((nfp = fopen(fnnew, "w")) == NULL) return -1;
	while(fgets(genbuf, STRLEN, fp) != NULL) {
	    if (strncmp(genbuf, uident, strlen(uident)))
		fputs(genbuf, nfp);
	    else deleted = YEA;
	}
	fclose(fp);
	fclose(nfp);
	if (!deleted) return -1;
	return(rename(fnnew, fn));
}

t_override()
{
	char uident[STRLEN];
	char ans[8];
	int count;
/*
	uinfo.mode = 
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
*/
	while (1) {
  	  clr();
	  prints("Edit Pager Override List\n");
          count = listfriends();
  	  if (count)
	        getdata(1,0, "(A)dd name, (D)elete name, or (E)xit? [E]: ", ans, 7, DOECHO, NULL);
	  else 
	        getdata(1,0, "(A)dd name or (E)xit? [E]: ", ans, 7, DOECHO, NULL);
	  if (*ans == 'A' || *ans == 'a') {
	    u_namelist();
	    move(2,0);
	    namecomplete("Enter userid: ", uident);
	    move(2,0);
	    clrtoeol();
	    if (uident[0] != '\0' && getuser(uident))
	        addtooverride(uident);
	  }
	  else if ((*ans == 'D' || *ans == 'd') && count) {
	    move(2,0);
	    namecomplete("Enter userid: ", uident);
	    move(2,0);
	    clrtoeol();
	    if (uident[0] != '\0')
	        deleteoverride(uident);
	  }		
	  else break;
	}
	clr();
	return;
}		

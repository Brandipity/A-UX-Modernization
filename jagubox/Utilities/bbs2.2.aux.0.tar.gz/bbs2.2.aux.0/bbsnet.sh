#!/bin/sh
#
#	define the standout() and standend() escape sequences...
#
SO="[7m"
SE="[0m"

#biff n

while true
do

clear

echo "${SO} Internet telnet access: ${SE}

${SO} BBS Style ${SE}    ${SO} Name ${SE}             ${SO} Notes ${SE}
(ebbs)     [1]  Eagle's Nest BBS  (login and password are 'bbs')
(ebbs)     [2]  Freedom           (login as 'bbs')
(pbbs)     [3]  Badboy BBS        (login as 'bbs')
(ebbs)     [4]  NSYSU'S BBS       (login as 'bbs')        (taiwan)
(ebbs)     [5]  Auggie BBS	  (login as 'bbs')
(yabbs)    [6]  YABBS BBS
(ebbs)     [7]  UNINET BBS        (login as 'new')        (mexico)
(cit)      [8]  Quartz  BBS       (login as 'bbs')
(doc/cit)  [9]  ISCA BBS
(cit)      [10] Sunset BBS        (login as 'bbs')

${SO} BBS fingers: $SE  (press <return> to continue)
           [11] Eagle's Nest 
           [12] ISCA BBS
           [13] Auggie BBS
           [0] Exit.

     For a list of other internet services and BBSs send email to: 
                     ${SO} bbslist@aug3.augsburg.edu ${SE}
"
echo -n "Enter choice [0]: " \

        if read CHOICE
          then
	    clear
            case "${CHOICE}"
              in
                '')
                  break
                  ;;
                0)
                  break
                  ;;
		1)
                  echo "Eagles Nest" >> bbslog
		  telnet 131.95.127.2
		  ;;
		2)
                  echo "Freedom" >> bbslog
		  telnet 128.123.1.14
		  ;;
                3)
                  echo "Badboy" >> bbslog
		  telnet 192.136.108.18
                  ;;
                4)
                  echo "NSYSU'S BBS" >> bbslog
		  telnet 140.117.11.1
                  ;;
		5)
                  echo "Auggie BBS" >> bbslog
		  telnet 141.224.128.4
		  ;;
                6)
                  echo "YABBS BBS" >> bbslog
		  telnet 128.2.111.111 8888
                  ;;
		7)
                  echo "uninet" >> bbslog
		  telnet 131.178.6.132
		  ;;
                8)
                  echo "Quartz" >> bbslog
 		  telnet 128.6.60.6
                   ;;
                9)
                  echo "ISCA" >> bbslog
 		  telnet 128.255.40.203
                   ;; 
                10)
                  echo "Sunset" >> bbslog
 		  telnet 128.196.230.7
                   ;; 
		11)
                  echo "finger eagles nest" >> bbslog
		  telnet 131.95.127.2 1992 | more
		  ;;
                12)
                  echo "finger isca" >> bbslog
 		  finger @@128.255.40.203 | more
                   ;;
		13)
		  echo "finger auggie" >> bbslog
		  telnet 141.224.128.4 1992 | more
		   ;;
                *)
          	  echo ""
		  echo "${SO}${CHOICE} is an invalid option. Select again.${SE}"
		  sleep 2
		  ;;
            esac
          else
            exit
        fi
done

clear
#biff y


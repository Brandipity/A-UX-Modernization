/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifdef AUX
#include <sys/file.h>
#endif

#include "config.h"
#include "chat.h"
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/socket.h>
#include <netinet/in.h>

#if defined(AIX) || defined(CLIX)
# define NO_FLOCK		/* dammit! I should just #include bbs.h */
#endif
#ifdef AIX
# include <sys/select.h>
#endif
#ifdef LINUX
# include <sys/time.h>		/* for FD_SET et. al */
#endif
#include <netdb.h>
#include <errno.h>
#include <signal.h>
#ifndef AUX
#include <sys/file.h>
#endif
#include <sys/param.h>

#define MAXPORTS 32
#define YEA       1
#define NA        0

int chatroom;

#ifdef NO_FLOCK
#include <sys/ipc.h>
#include <sys/sem.h>

#define LOCK_EX         2       /* exclusive lock */
#define LOCK_UN         8       /* unlock */

#ifndef L_SET
#define L_SET	SEEK_SET
#define L_INCR	SEEK_CUR
#define L_XTND	SEEK_END
#endif

#define SEM_KEY 9237
int semid;

get_semaphore()
{
        if ((semid = semget(SEM_KEY, 1, 600)) == -1) {
            if ((semid = semget(SEM_KEY, 1, 600 | IPC_CREAT)) == -1)
                return -1;
            semctl(semid, 0, SETVAL, 1);
        }
        return 0;
}

flock(fd, op)
int fd, op;
{
        /* one semaphore for all shared files -> fd is unused */
        struct sembuf sops;
        sops.sem_num = 0;
        sops.sem_flg = SEM_UNDO;
        switch (op) {
          case LOCK_EX: sops.sem_op = -1;
            break;
          case LOCK_UN: sops.sem_op = 1;
            break;
          default: return -1;
        }
        semop(semid, &sops, 1);
        return 0;
}

#endif

report(s)
char *s;
{
	static int disable = NA;
	int fd;
	if (disable) return;
	if ((fd = open("trace.chatd", O_WRONLY, 0644)) != -1) {
	    char buf[160];
	    flock(fd, LOCK_EX);
	    lseek(fd, 0, L_XTND);
	    sprintf(buf, "Room %d: %s\n", chatroom, s);
	    write(fd, buf, strlen(buf));
	    flock(fd, LOCK_UN);
	    close(fd);
	    return;
	}
	disable = YEA;
	return;
}

main(ac,av)
int ac ;
char **av ;
{
	int sock, msgsock, length, chatport;
	struct sockaddr_in server ;
	int numports ;
	int portfds[MAXPORTS] ;
	char buf[80];
        unsigned long inetaddr;
#ifndef INET_ADDRESS
        char hostname[MAXHOSTNAMELEN] ;
        struct hostent *h ;
#endif

	numports = 0 ;

 	if(ac != 2) {
		fprintf(stderr,"Invalid arguments\n") ;
		exit(-1) ;
	}

#ifdef INET_ADDRESS
        inetaddr = inet_addr(INET_ADDRESS);
#else        
        /* Get local host info - lush*/
        if(gethostname(hostname,sizeof(hostname))) {
           perror("gethostname") ;
           exit(-1) ;
        }
        if(!(h = gethostbyname(hostname))) {
           perror("gethostbyname") ;
           exit(-1) ;
        }
        bcopy(&h->h_addr, &inetaddr, sizeof(inetaddr));
#endif
	signal(SIGHUP,SIG_IGN) ;
	signal(SIGINT,SIG_IGN) ;
	signal(SIGQUIT,SIG_IGN) ;
	signal(SIGPIPE,SIG_IGN) ;
	signal(SIGALRM,SIG_IGN) ;
	signal(SIGTERM,SIG_IGN) ;
	signal(SIGURG,SIG_IGN) ;
	signal(SIGTSTP,SIG_IGN) ;
	signal(SIGTTIN,SIG_IGN) ;
	signal(SIGTTOU,SIG_IGN) ;	
	chatroom = atoi(av[1]) ;
	switch (chatroom) {
	    case 4: chatport = CHATPORT4; break;
	    case 1: chatport = CHATPORT1; break;
	    case 2: chatport = CHATPORT2; break;
	    case 3: chatport = CHATPORT3; break;
	}
#ifndef DEBUG
	if (fork())
	  exit(0) ;
	{ int s, ndescriptors = getdtablesize() ;
	  for(s=0; s < ndescriptors; s++) ;
	  (void) close(s) ;
    	}
	(void) open("/", O_RDONLY) ;
	(void) dup2(0, 1) ;
	(void) dup2(0, 2) ;
#ifdef TIOCNOTTY
	{ int tt = open("/dev/tty", O_RDWR) ;
	  if(tt > 0) {
		  ioctl(tt, TIOCNOTTY, (char *) 0) ;
		  (void) close(tt) ;
	  }
	}
#else
	setpgrp();
#endif /* TIOCNOTTY */
#endif /* DEBUG */
	report("starting up");
	sock = socket(AF_INET, SOCK_STREAM, 0) ;
	if(sock < 0) {
		report("socket() failed: exiting");
		return -1 ;
	}

	server.sin_family = AF_INET ;
	server.sin_addr.s_addr = INADDR_ANY ;
	server.sin_port = htons(chatport) ;
	if(bind(sock, (struct sockaddr *) & server, sizeof server) < 0) {
		report("bind() failed: exiting");
		return -1 ;
	}
	length = sizeof server ;
	if(getsockname(sock, (struct sockaddr *) &server, &length) < 0) {
		report("getsockname() failed: exiting");
		return -1 ;
	}
	listen(sock,5) ;
	while(YEA) {
		fd_set readfds, writefds;
		int sr ;
		int i ;

		FD_ZERO(&readfds) ;
		FD_SET(sock,&readfds) ;
		for(i = 0; i < numports; i++)
		  FD_SET(portfds[i],&readfds) ;
		if((sr = select(getdtablesize(), &readfds, NULL, NULL, NULL)) < 0) {
			report("select() failed: exiting");
			exit(-1) ;
		}
		if(sr == 0)
		  continue ;
		if(FD_ISSET(sock,&readfds)) {
			int s ;
			/* NEW DECLARATIONS - lush*/
   			struct sockaddr_in name ;
   			int len = sizeof(name) ;
 		        char *msg = "NON-LOCAL Connections to chatd not allowed\nYour attempt has been logged\n" ;

			s = accept(sock, (struct sockaddr *)0, (int *) 0) ;
			if(s == -1) {
				report("accept() failed: continuing");
				continue ;
			}
			/* code to check if its a local site calling - lush*/
			if(getpeername(s,(struct sockaddr *)&name,&len)==-1) {
			      close(s) ;
			      continue ;
		        }
			if(bcmp(&inetaddr,&name.sin_addr,sizeof(name.sin_addr))) {
			      write(s,msg,strlen(msg)) ;
			      sprintf(buf, "chat_breakin %s", 
				      inet_ntoa(name.sin_addr.s_addr));
		              report(buf);
			      close(s) ;
			      continue ;
			}

			portfds[numports] = s ;
			numports++ ;
			sprintf(buf, "entry: numports is now %d", numports);
			report(buf);
			if(sr == 1)
			  continue ;
		}
		for(i = 0; i < numports; i++)
		  if(FD_ISSET(portfds[i],&readfds)) {
			  char buf[80];
			  int cc ;

			  cc = read(portfds[i],buf,80) ;
			  if(cc <= 0) {
				  int j ;
				  close(portfds[i]) ;
				  for(j=i;j<numports-1;j++)
					bcopy(&portfds[j+1],&portfds[j],sizeof(int)) ;
				  numports-- ;
				  i-- ;
				  sprintf(buf, "exit: numports is now %d", numports);
				  report(buf);
				  if(numports == 0) {
					report("normal termination");
					exit(0) ;  /* last person closed connection */
				  }
				  continue ;
			  }
			  while(YEA) {
				  int j ;
				  FD_ZERO(&writefds);
 		  		  for(j = 0; j < numports; j++)
		  		        FD_SET(portfds[j], &writefds) ;
		  		  if((sr = select(getdtablesize(), NULL, 
                                      &writefds, NULL, NULL)) < 0) {
	  			        report("select() failed: exiting");
			                exit(-1) ;
		                  }
				  for(j=0; j < numports; j++)
					if (FD_ISSET(portfds[j], &writefds))
						write(portfds[j], buf, cc) ;
				  if(buf[cc-1] == '\0')
					break ;  /* all complete messages end in newline */
				  cc = read(portfds[i],buf,80) ;
				  if(cc <= 0)
					break ;
			  }
		  }
	}
}



/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"

d_exit()
{
	clr() ;
	return QUIT ;
}

/*ARGSUSED*/
boardcheck(fptr)
struct fileheader *fptr ;
{
/*	if(!strcmp(fptr->filename,genbuf))
	  return 1 ;
	return 0 ;*/
	return 1 ;
}

d_board()
{
	struct fileheader binfo ;
	int bid ;
	extern int numboards ;

	move(3,0) ;
	clrtobot() ;
	move(0,0) ;
	standout() ;
	prints("DELETE BOARD DELETE BOARD DELETE BOARD") ;
	standend() ;
	clrtoeol() ;
	move(1,0) ;
        make_blist() ;
	namecomplete("Enter Board Name: ",genbuf) ;
	bid = getbnum(genbuf) ;
	if(get_record(BOARDS,&binfo,sizeof(binfo),bid) == -1) {
		move(2,0) ;
		prints("Invalid Board Name\n") ;
		pressreturn() ;
		clr() ;
		return 0 ;
	}
	move(1,0) ;
	prints("Delete board '%s'.",binfo.filename) ;
	clrtoeol();
	getdata(2,0,"(Yes, or No) [N]: ",genbuf,4,DOECHO,NULL) ;
	if(genbuf[0] != 'Y' && genbuf[0] != 'y') { /* if not yes quit */
		move(2,0) ;
		prints("Quitting delete board\n") ;
		pressreturn() ;
		clr() ;
		return 0 ;
	}
	if (!isalpha(binfo.filename[0])) return -1; /* rrr - precaution */
	sprintf(genbuf,"/bin/rm -fr boards/%s",binfo.filename) ;
	system(genbuf) ;
	strcpy(genbuf,binfo.filename) ;
	delete_file(BOARDS,sizeof(binfo),bid,boardcheck) ;
	move(2,0) ;
        numboards = -1 ;
	sprintf(genbuf, "deleted board %s", binfo.filename);
	report(genbuf);	
	prints("Board Deleted\n") ;
	pressreturn() ;
	clr() ;
	return 0 ;
}

int delusernum ;

duentposts(fptr)
struct fileheader *fptr ;
{
	char *bfile() ;
	struct fileheader update ;
	static int id ;

	if(fptr == NULL) {
		id = 0 ;
		return 0;
	}
	id++ ;
	if(get_record(strcat(bfile(currboard),DIR),&update,sizeof(update),id))
	  return -1 ;
	update.accessed[delusernum] = 0 ;
	if(substitute_record(strcat(bfile(currboard),DIR),&update,sizeof(update),id))
	  return -1 ;
	return 0 ;
}


duentbds(fptr)
struct fileheader *fptr ;
{
	char *bfile() ;
	duentposts(NULL) ;
	strcpy(currboard,fptr->filename) ;
	apply_record(strcat(bfile(currboard),DIR),duentposts,sizeof(struct fileheader)) ;
	/* BUG zapped boards need to be cleared */
}

d_user()
{
	int id ;

	u_namelist() ;
	move(0,0) ;
	standout() ;
	prints("DELETE USER DELETE USER DELETE USER") ;
	standend() ;
	clrtoeol() ;
	move(1,0) ;
	namecomplete("Enter userid to be deleted: ",genbuf) ;
	if(*genbuf == '\0') {
		clr() ;
		return 0 ;
	}
	if(!(id = getuser(genbuf))) {
		move(3,0) ;
		prints("Invalid User Id") ;
		clrtoeol() ;
		pressreturn() ;
		clr() ;
		return 0 ;
	}
	if (!isalpha(lookupuser.userid[0])) return 0; /* rrr - don't know how...*/
	delusernum = id ;
	move(1,0) ;
	prints("Delete User '%s'.",genbuf) ;
	clrtoeol();
	getdata(2,0,"(Yes, or No) [N]: ",genbuf,4,DOECHO,NULL) ;
	if(genbuf[0] != 'Y' && genbuf[0] != 'y') { /* if not yes quit */
		move(2,0) ;
		prints("Aborting delete User\n") ;
		pressreturn() ;
		clr() ;
		return 0 ;
	}
	sprintf(genbuf,"/bin/rm -fr mail/%s signatures/%s plans/%s overrides/%s",
	        lookupuser.userid, lookupuser.userid, lookupuser.userid, lookupuser.userid) ;
	system(genbuf) ;
	sprintf(genbuf, "deleted user %s", lookupuser.userid);
	lookupuser.userid[0] = '\0' ;
	substitute_record(PASSFILE,&lookupuser,sizeof(lookupuser),id) ;
	report(genbuf);
	apply_boards(duentbds) ;
	move(2,0) ;
	prints("User Deleted\n") ;
	touchnew();
	pressreturn() ;
	clr() ;
	return 0 ;
}
extern int cmpuids(), t_cmpuids();

kick_user()
{
	int id, ind ;
	struct user_info uin;
	struct userec kuinfo;
	char kickuser[40], buffer [40];
	u_namelist() ;
	clr();
	move(0,0) ;
	standout() ;
	prints("Kick User") ;
	standend() ;
	clrtoeol() ;
	move(1,0) ;
	namecomplete("Enter userid to be kicked: ",kickuser) ;
	if(*kickuser == '\0') {
		clr() ;
		return 0 ;
	}
	if(!(id = getuser(kickuser))) {
		move(3,0) ;
		prints("Invalid User Id") ;
		clrtoeol() ;
		pressreturn() ;
		clr() ;
		return 0 ;
	}
	move(1,0) ;
	prints("Kick User '%s'.",kickuser) ;
	clrtoeol();
	getdata(2,0,"(Yes, or No) [N]: ",genbuf,4,DOECHO,NULL) ;
	if(genbuf[0] != 'Y' && genbuf[0] != 'y') { /* if not yes quit */
		move(2,0) ;
		prints("Aborting Kick User\n") ;
		pressreturn() ;
		clr() ;
		return 0 ;
	}
	search_record(PASSFILE, &kuinfo, sizeof(kuinfo), cmpuids, kickuser);
	ind = search_record(ULIST, &uin, sizeof(uin), t_cmpuids, id);
	if (!ind || !uin.active || (kill(uin.pid,0) == -1)) {
		move(3,0) ;
		prints("User Has Logged Out") ;
		clrtoeol() ;
		pressreturn() ;
		clr() ;
		return 0 ;
	}
#ifndef PERMS
	if (currentuser.userlevel < kuinfo.userlevel) {
		move(3,0);
		prints("Can only kick users of lower or equal level. Sorry...");
		clrtoeol();
		pressreturn();
		clr();
		return 0;
	}
#endif
	kill(uin.pid,9);
	sprintf(buffer, "kicked %s", kickuser);
	report(buffer);
	if ((ufp = fopen("usies", "a")) != NULL) {
		ti = time(0);
		fprintf(ufp, "KICK  %-10s %-20s %s", kuinfo.userid, 
			kuinfo.username, ctime(&ti));
		fflush(ufp);
		fclose(ufp);
	}
	uin.active = NA;
	uin.pid = 0;
	uin.invisible = YEA;
	uin.sockactive = 0;
	uin.sockaddr = 0;
	uin.destuid = 0;
	substitute_record(ULIST, &uin, sizeof(uin), ind);
	move(2,0) ;
	prints("User has been Kicked\n") ;
	pressreturn() ;
	clr() ;
	return 0 ;
}


#! /bin/sh
#
# installation script for Pirate BBS.
# with enhancements for Eagles BBS.
#
# just in case something goes wrong, make a backup of the passwd file
#

system=$1
if [ "$system" = "" ]
then
    system=SUNOS
fi

if [ "$2" = "" ]
then
    loginshell=/bin/csh
else
    loginshell=/bin/$2
fi

if [ "$system" = "LINUX" ]
then
   cplink=-d
else
   cplink=
fi

if [ "$system" = "SUNOS" ]
then
   lsargs=-lg
else
   if [ "$system" = "SOLARIS" ]
   then
      lsargs=-lL      # Solaris has symlinks in /dev    
   else
      lsargs=-l
   fi
fi

if [ "$system" = "SOLARIS" ]
then
   echo=/usr/ucb/echo
else
   echo=echo
fi

sh=/bin/sh
mv=/bin/mv
rm=/bin/rm
mkdir=/bin/mkdir
cp=/bin/cp
touch=/bin/touch
if [ "$system" = "LINUX" ]
then 
   ls=/usr/bin/ls
   stty=/usr/bin/stty
else
   ls=/bin/ls
   stty=/bin/stty
fi
if [ "$system" = "SUNOS" ]
then
   vi=/usr/ucb/vi
   reset=/usr/ucb/reset
   more=/usr/ucb/more
else
   vi=/usr/bin/vi
   reset=/usr/bin/reset
   if [ "$system" = "CLIX" ]
   then
       more=/usr/bin/pg
   else
       more=/usr/bin/more
   fi
fi

echo Installing for $system operating system

cp /etc/passwd passwd.backup

bbshome=`./passwdent bbs homedir`

if [ "$bbshome" = "" ] 
then
    echo ERROR: CHECK PASSWD ENTRY, is it bbs\?
    exit 1
fi

if [ -d $bbshome/bin ]
then
    echo bbs has already been installed!
    echo If you want to reinstall from scratch, rm -rf ~bbs first.
    exit 1
fi

# Make all the directories required
echo making directories
mkdir $bbshome
mkdir $bbshome/bin
mkdir $bbshome/dev
mkdir $bbshome/etc
mkdir $bbshome/ftp
mkdir $bbshome/ftp/files
mkdir $bbshome/ftp/files/source
mkdir $bbshome/boards
mkdir $bbshome/mail
mkdir $bbshome/tmp
mkdir $bbshome/usr
mkdir $bbshome/usr/lib
ln -s /usr/lib $bbshome/lib
mkdir $bbshome/usr/spool
mkdir $bbshome/usr/spool/mqueue
mkdir $bbshome/plans
mkdir $bbshome/signatures
mkdir $bbshome/overrides
mkdir $bbshome/vote

# Copy Welcome and copyright notices to home directory
echo Copying Welcome message and copyright notices

cp COPYING Welcome Version.Info $bbshome

# Make zero device in dev
if [ -c /dev/zero ] 
then
	echo Making zero device
        lsline=`$ls $lsargs /dev/zero`
        set $lsline
        maj=`echo $5 | cut -d',' -f1`
	mknod $bbshome/dev/zero c $maj $6
fi
# Make null device for IRC
if [ -c /dev/null ]
then
	echo Making null device
        lsline=`$ls $lsargs /dev/null`
        set $lsline
        maj=`echo $5 | cut -d',' -f1`
	mknod $bbshome/dev/null c $maj $6
fi
if [ "$system" = "CLIX" ]
then
    if [ -c /dev/tty ] 
    then
	echo Making tty device
        lsline=`$ls $lsargs /dev/tty`
        set $lsline
        maj=`echo $5 | cut -d',' -f1`
	mknod $bbshome/dev/tty c $maj $6
    fi
fi
    
# Set Up etc directory
echo setting up etc directory
if [ -f /etc/termcap ]
then
    if [ "$system" = "CLIX" ]     # CLIX has termcap but wants terminfo
    then
        doterminfo=yes
    else
        doterminfo=no
        cp /etc/termcap $bbshome/etc
    fi
else
    doterminfo=yes
fi
cp /etc/group $bbshome/etc
cp /etc/hosts $bbshome/etc
if [ -f /etc/resolv.conf ]
then 
    cp /etc/resolv.conf $bbshome/etc
fi
$echo "root:*:0:1:Operator:/:$loginshell" > $bbshome/etc/passwd
if [ "$system" = "CLIX" ]
then
    $echo "bbs:*:\\c" >> $bbshome/etc/passwd
    $echo `./passwdent bbs uid`:\\c >> $bbshome/etc/passwd
    $echo `./passwdent bbs gid`:\\c >> $bbshome/etc/passwd
else
    $echo -n "bbs:*:" >> $bbshome/etc/passwd
    $echo -n `./passwdent bbs uid`: >> $bbshome/etc/passwd
    $echo -n `./passwdent bbs gid`: >> $bbshome/etc/passwd
fi
$echo "Bulletin Board Software:/:/bin/bbs" >> $bbshome/etc/passwd
chmod a-w $bbshome/etc/passwd
chmod a-w $bbshome/etc/group
if [ -f $bbshome/etc/termcap ]
then
   chmod a-w $bbshome/etc/termcap
fi

# set up usr directory
# this includes timezone stuff and shared library stuff
echo setting up usr directory
if [ -d /usr/share/lib/zoneinfo ]     # SunOS
then
   mkdir $bbshome/usr/share
   mkdir $bbshome/usr/share/lib
   echo Copying zoneinfo stuff
   (cd /usr/share/lib;tar cf - zoneinfo) | (cd $bbshome/usr/share/lib;tar xf -)
else 
   if [ -d /usr/lib/zoneinfo ]   # Linux
   then
      echo Copying zoneinfo stuff
      (cd /usr/lib;tar cf - zoneinfo) | (cd $bbshome/usr/lib;tar xf -)
   else 
      if [ -d /etc/zoneinfo ]	 # OSF
      then
         echo Copying zoneinfo stuff
         (cd /etc;tar cf - zoneinfo) | (cd $bbshome/etc;tar xf -)
      fi     
   fi
fi

# Copy terminfo stuff for systems with no termcap library
if [ "$doterminfo" = "yes" ]
then
   if [ -d /usr/share/lib/terminfo ]	# System V release 4
   then
      echo Copying terminfo stuff
      if [ ! -d $bbshome/usr/share ]
      then
         mkdir $bbshome/usr/share
      fi
      mkdir $bbshome/usr/share/lib
      (cd /usr/share/lib;tar cf - terminfo)|(cd $bbshome/usr/share/lib;tar xf -)
      ln -s /usr/share/lib/terminfo $bbshome/usr/lib/terminfo
   else 
      if [ -d /usr/lib/terminfo ]     # System V release 3
      then
          echo Copying terminfo stuff
          (cd /usr/lib;tar cf - terminfo)|(cd $bbshome/usr/lib;tar xf -)
      fi
   fi     
fi

# The following lines are supposed to copy the necessary files for shared
# libraries. Some of this might not be right. I wish there was a STANDARD.

if [ "$system" = "OSF" ]            # OSF/1
then
   mkdir $bbshome/usr/shlib
   cp $cplink /usr/shlib/libc.so.* $bbshome/usr/shlib
else
   if [ -f /usr/lib/libc_s.a ]         # CLIX
   then
       cp /usr/lib/libc_s.a $bbshome/usr/lib
       chmod +x $bbshome/usr/lib/libc_s.a
   else
       cp $cplink /lib/libc.so.* $bbshome/usr/lib
   fi
fi
if [ -f /usr/lib/ld.so ]            # SunOS
then
   cp /usr/lib/ld.so* $bbshome/usr/lib
fi
if [ -f /lib/ld.so ]		# Linux
then
   cp /lib/ld.so* $bbshome/usr/lib
fi
if [ -f /usr/lib/libdl.so.1.0 ]     # SunOS
then
   cp /usr/lib/libdl.so.1.0 $bbshome/usr/lib
fi
if [ -f /usr/lib/libdl.so.1 ]       # Solaris
then
   cp /usr/lib/libdl.so.1 $bbshome/usr/lib
fi
if [ "$system" = "SOLARIS" ]
then
   cp /usr/ucblib/libucb.so* $bbshome/usr/lib
   cp /usr/lib/libsocket.so* $bbshome/usr/lib
   cp /usr/lib/libnsl.so* $bbshome/usr/lib
   cp /usr/lib/libelf.so* $bbshome/usr/lib
   cp /usr/lib/libaio.so* $bbshome/usr/lib
   cp /usr/lib/libintl.so* $bbshome/usr/lib
   cp /usr/lib/libw.so* $bbshome/usr/lib
fi

# set up the bin directory
echo setting up binaries
echo "NOTE: These are the bare minimum utilities to run the bbs. You may want"
echo "to copy more into the restricted bbs directory tree. "

cp bbs $bbshome/bin
cp bbsrf $bbshome/bin
cp bbs.chatd $bbshome/bin
# The chroot app runs setuid.
chown root $bbshome/bin/bbsrf
chmod 4755 $bbshome/bin/bbsrf
cp mail.sh $bbshome/bin
cp $sh $bbshome/bin
if [ "$loginshell" != "$sh" ]
then
    cp $loginshell $bbshome/bin
fi
cp $mv $bbshome/bin
cp $rm $bbshome/bin
cp $mkdir $bbshome/bin
cp $cp $bbshome/bin
cp $touch $bbshome/bin
cp $ls $bbshome/bin
cp $stty $bbshome/bin
cp $vi $bbshome/bin
if [ -f "$reset" ]
then
   cp $reset $bbshome/bin
fi
cp $more $bbshome/bin/more

# make account for SYSOP
echo Creating SYSOP account
./genlogin $bbshome/.PASSWDS

# set up home directory and ownerships
echo Setting ownerships and permissions
echo  > $bbshome/.hushlogin
if [ "$loginshell" = "/bin/csh" ]
then
    cp dotcshrc $bbshome/.cshrc
    cp dotlogin $bbshome/.login
    chown bbs $bbshome/.cshrc
fi
chown bbs $bbshome
chown bbs $bbshome/.hushlogin
chown bbs $bbshome/.PASSWDS
chown bbs $bbshome/boards
chown bbs $bbshome/mail
chown bbs $bbshome/usr/spool
chown bbs $bbshome/usr/spool/mqueue
chown bbs $bbshome/Welcome
chown bbs $bbshome/ftp
chown bbs $bbshome/ftp/files
chown bbs $bbshome/ftp/files/source
chown bbs $bbshome/tmp
chown bbs $bbshome/plans
chown bbs $bbshome/signatures
chown bbs $bbshome/vote
chown bbs $bbshome/overrides
chmod 770 $bbshome

echo "Done."
echo "If mail forwarding is enabled:"
echo "-- set up cron job for mail forwarding"
echo "If file upload/download is enabled:"
echo "-- compile or copy protocols (rz, sz, etc.) into ~bbs/bin"


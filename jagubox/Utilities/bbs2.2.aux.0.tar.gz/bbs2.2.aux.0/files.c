/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"

#ifdef FILES 

#undef DIR

#if defined(OSF) || defined(CLIX)
#include <dirent.h>
#define direct dirent
#endif

#ifdef SEABASS
#define FILES_ROOT "ftp"
#else
#define FILES_ROOT "ftp/files"
#endif

struct protocols {
	char *pname ;
	char *sendbin ;
	char *recvbin ;
} ;

/* 
   NOTE: if NO_CHROOT is defined these are probably WRONG! Be sure to set
   these paths to the correct locations, e.g. /usr/bin/kermit, etc.
*/

struct protocols protos[] =
{
{ "Kermit", "/bin/kermit -si", "/bin/kermit -ri"},
{ "Xmodem", "/bin/sx -be",       "/bin/rx -bpe"},
{ "Ymodem", "/bin/sb -be",       "/bin/rb -bpe"},
#ifdef ULTRIX
{ "Zmodem", "/bin/sz -bew 8192",       "/bin/rz -bpe"}
#else
{ "Zmodem", "/bin/sz -be",       "/bin/rz -bpe"}
#endif
} ;


#define MAXDIRSIZE 80

#define NUMPROTOS (sizeof(protos)/sizeof(struct protocols))

char *
NameProtocol(id)
{
	if(id < 0 || id >= NUMPROTOS)
	  return "invalid" ;
	return protos[id].pname ;
}

char *
CurrentProtocol()
{
	return NameProtocol(currentuser.protocol);
}

char dirs[MAXDIRSIZE][STRLEN] ;
int numdirs = 0 ;
static char currfile[STRLEN] ;
int fileselect = 0 ;

char *
filemargin()
{
	static char buf[STRLEN] ;
	
	if(fileselect)
	  sprintf(buf,"File Sub-board is '%s'",currfile) ;
	else
	  sprintf(buf,"No File Sub-board Selected") ;
	return buf ;
}

get_dir(root)
char *root;
{
	DIR *dp ;
	struct direct *ent ;
	struct stat status ;
	char dirname[1024];
	int path_offset = strlen(FILES_ROOT)+1;

	if((dp = opendir(root)) == NULL)
	  return -1 ;
	for(ent=readdir(dp);ent!=NULL;ent=readdir(dp)) {
		if(!strcmp(ent->d_name,".") ||
		   !strcmp(ent->d_name,".."))
		  continue ;
#ifdef SEABASS
		if (!strcmp(ent->d_name, "bin") ||
		    !strcmp(ent->d_name, "etc") ||
		    !strcmp(ent->d_name, "lib")) continue;
#endif
		sprintf(dirname,"%s/%s", root, ent->d_name) ;
		if(stat(dirname,&status))
		  continue ;
		if(!(status.st_mode & S_IFDIR))
		  continue ;
		if(numdirs >= MAXDIRSIZE)
		  break;
/*		strcpy(dirs[numdirs],ent->d_name) ; */
		strncpy(dirs[numdirs], dirname+path_offset, STRLEN-1);
		numdirs++ ;
		get_dir(dirname);
	}
	closedir(dp) ;
	return 0 ;
}


f_list()
{
	DIR *dp ;
	struct direct *ent ;
	struct stat status ;
	int i ;
	int col ;
	char buf[512] ;

	if(!fileselect) {
		move(3,0) ;
		clrtobot() ;
		prints("Use (S)elect to select a sub board first!\n") ;
		pressreturn() ;
		return -1 ;
	}
	move(3,0) ;
	clrtobot() ;
	prints("List of Files on bbs for download\n") ;
	prints("%-19s  Size","FILENAME") ;
	sprintf(buf,"%s/%s", FILES_ROOT, currfile) ;
	if((dp = opendir(buf)) == NULL)
	  return -1 ;
	i = 5 ;
	col = 0 ;
	for(ent=readdir(dp);ent!=NULL;ent=readdir(dp)) {
		if(!strcmp(ent->d_name,"."))
		  continue ;
		if(!strcmp(ent->d_name,".."))
		  continue ;
		sprintf(genbuf,"%s/%s/%s",FILES_ROOT,currfile,ent->d_name) ;
		if(stat(genbuf,&status))
		  continue ;
		if((status.st_mode & S_IFDIR))
		  continue ;
		if(i == 23) {
			col++ ;
			if(col == 3) {
				int ch ;
				move(23,0) ;
				standout() ;
				prints("-- More --") ;
				standend() ;
				while((ch = igetch()) != EOF) {
					if(ch == 'q') {
						closedir(dp) ;
						move(23,0) ;
						clrtoeol() ;
						return 0 ;
					}
					if(ch == '\n' || ch == '\r' || ch == ' ')
					  break ;
					bell() ;
				}
				col = 0 ;
				move(4,0) ;
				clrtobot() ;
			}
			move(4,col*26) ;
			prints("%-19s  Size","FILENAME") ;
			i = 5 ;
		}
		move(i,col*26) ;
		prints("%-19s %4dk",ent->d_name,(status.st_size+512)>>10) ;
		i++ ;
	}
	closedir(dp) ;
	return 0 ;
}

f_create_namelist()
{
	DIR *dp ;
	struct direct *ent ;
	struct stat status ;

	if(!fileselect) {
		return -1 ;
	}
	CreateNameList() ;
	sprintf(genbuf,"%s/%s", FILES_ROOT, currfile) ;
	if((dp = opendir(genbuf)) == NULL)
	  return -1 ;
	for(ent=readdir(dp);ent!=NULL;ent=readdir(dp)) {
		if(!strcmp(ent->d_name,"."))
		  continue ;
		if(!strcmp(ent->d_name,".."))
		  continue ;
		sprintf(genbuf,"%s/%s/%s",FILES_ROOT,currfile,ent->d_name) ;
		if(stat(genbuf,&status))
		  continue ;
		if((status.st_mode & S_IFDIR))
		  continue ;
		AddNameList(ent->d_name) ;
	}
	closedir(dp) ;
	return 0 ;
}

f_download()
{
	char fname[STRLEN] ;
	char path[512] ;
	struct stat st ;

	if(!fileselect) {
		move(3,0) ;
		clrtobot() ;
		prints("Use (S)elect to select a sub board first!\n") ;
		pressreturn() ;
		return -1 ;
	}
	if (currentuser.protocol < 0 || currentuser.protocol >= NUMPROTOS)
	  return 0;
	f_create_namelist() ;
	move(0,0) ;
	prints("%s DOWNLOAD FACILITY\n",CurrentProtocol()) ;
	prints("Enter Filename: ") ;
	clrtoeol() ;
	namecomplete(NULL,fname) ;
	sprintf(path,"/%s/%s/%s",FILES_ROOT,currfile,fname) ;
	if((*fname == '\0') || (stat(path,&st) == -1)) {
		move(2,0) ;
		prints("Invalid File Name\n") ;
		pressreturn() ;
		move(0,0) ;
		clrtoeol() ;
		move(1,0) ;
		clrtoeol() ;
		move(2,0) ;
		clrtoeol() ;
		return 1 ;
	}
	if((st.st_mode & S_IFDIR)) {
		move(1,0) ;
		prints("Invalid File Name\n") ;
		pressreturn() ;
		move(0,0) ;
		clrtoeol() ;
		move(1,0) ;
		clrtoeol() ;
		move(2,0) ;
		clrtoeol() ;
		return 1 ;
	}
	sprintf(genbuf,"downloading file '%s'",path) ;
	report(genbuf) ;
	move(3,0) ;
	clrtobot() ;
	reset_tty() ;
	printf("Using %s protocol\n",CurrentProtocol()) ;
	sprintf(genbuf,"%s %s",protos[currentuser.protocol].sendbin,path) ;
	do_exec(genbuf, NULL);
	restore_tty() ;
	clr() ;
	pressreturn() ;
	return 0 ;
}

f_upload()
{
	char buf[512] ;
	
	if(!fileselect) {
		move(3,0) ;
		clrtobot() ;
		prints("Use (S)elect to select a sub board first!\n") ;
		pressreturn() ;
		return -1 ;
	}
	if(currentuser.protocol < 0 || currentuser.protocol >= NUMPROTOS)
	  return 0;
	move(3,0) ;
	clrtobot() ;
	reset_tty() ;
	printf("Using %s protocol\n",CurrentProtocol()) ;
	sprintf(buf,"%s/%s",FILES_ROOT,currfile) ;
	do_exec(protos[currentuser.protocol].recvbin, buf);
	restore_tty() ;
	clr() ;
	pressreturn() ;
	return 0 ;
}

f_protocol()
{
	int i ;
	char proto[STRLEN] ;

	move(3,0) ;
	clrtobot() ;
	prints("PROTOCOL MENU\n") ;
	for(i = 0 ; i < NUMPROTOS; i++)
	  prints("%d)  %s\n",i,protos[i].pname) ;
	move(2,0) ;
	prints("Enter Protocol id (0-%d): ", NUMPROTOS - 1) ;
	clrtoeol() ;
	getdata(0,0,NULL,proto,3,DOECHO,NULL) ;
	if(proto[0] == '\0')
	  return 0 ;
	i = atoi(proto) ;
	if(i < 0 || i >= NUMPROTOS)
	  return 0 ;
	clr() ;
	currentuser.protocol = i ;
	substitute_record(PASSFILE,&currentuser,sizeof(currentuser),usernum) ;
	return 0 ;
}

f_select()
{
	int i ;
	extern int numdirs ;
	extern char dirs[MAXDIRSIZE][STRLEN] ;
	char buf[STRLEN] ;

	if (numdirs == 0) get_dir(FILES_ROOT) ;
	move(3,0) ;
	clrtobot() ;
	prints("FILE BOARDS MENU\n") ;
	clrtoeol();
	for(i=0; i < numdirs; i++) {
	  move(i%20+4,(i/20)*20) ;
	  prints("%2d) %s",i,dirs[i]) ;
	}
	move(2,0) ;
	prints("Enter file board id (0-%d): ", numdirs - 1) ;
	clrtoeol() ;
	getdata(0,0,NULL,buf,3,DOECHO,NULL) ;
	if(buf[0] == '\0')
	  return 0 ;
	i = atoi(buf) ;
	if(i < 0 || i >= numdirs)
	  return 0 ;
	clr() ;
	strcpy(currfile,dirs[i]) ;
	fileselect = 1 ;
	return 0 ;
}

f_text()
{
	char fname[STRLEN] ;
	char path[512] ;
	struct stat st ;

	if(!fileselect) {
		move(3,0) ;
		clrtobot() ;
		prints("Use (S)elect to select a sub board first!\n") ;
		pressreturn() ;
		return -1 ;
	}
	f_create_namelist() ;
	move(0,0) ;
	prints("Text Viewing Facility\n") ;
	prints("Enter Filename: ") ;
	clrtoeol() ;
	namecomplete(NULL,fname) ;
	sprintf(path,"/%s/%s/%s",FILES_ROOT,currfile,fname) ;
	if((*fname == '\0') || (stat(path,&st) == -1)) {
		move(2,0) ;
		prints("Invalid File Name\n") ;
		pressreturn() ;
		move(0,0) ;
		clrtoeol() ;
		move(1,0) ;
		clrtoeol() ;
		move(2,0) ;
		clrtoeol() ;
		return 1 ;
	}
	if((st.st_mode & S_IFDIR)) {
		move(1,0) ;
		prints("Invalid File Name\n") ;
		pressreturn() ;
		move(0,0) ;
		clrtoeol() ;
		move(1,0) ;
		clrtoeol() ;
		move(2,0) ;
		clrtoeol() ;
		return 1 ;
	}
	sprintf(genbuf,"Examining file '%s'",path) ;
	report(genbuf) ;
	more(path,YEA) ;
	clr() ;
	return 0 ;
}

#endif /* FILES */

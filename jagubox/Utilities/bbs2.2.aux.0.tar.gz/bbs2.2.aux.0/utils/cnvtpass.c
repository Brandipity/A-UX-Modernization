#include "bbs.h"
#include <unistd.h>

#undef PASSFILE

/* IMPORTANT: Set these pathnames to lead to your BBS home directory. */

#define PASSFILE "/home/bbs/.PASSWDS"
#define NEWFILE  "/home/bbs/.NEWPASSWDS"

main()
{
	struct userec urec;
	int fd, fd2;
        char haveemail;
	int readsize;
	if ((fd = open(PASSFILE, O_RDONLY)) == -1) {
		printf("Cannot open passfile.\n");
		exit(1);
	}
	if ((fd2 = open(NEWFILE, O_WRONLY | O_CREAT, 0444)) == -1) {
		printf("Cannot open new passfile.\n");
		exit(1);
	}
	printf("Are users' e-mail addresses already in the passfile (Y/N)? ");
	haveemail = getchar();
        while (getchar() != '\n') ;
	while (toupper(haveemail) != 'Y' && toupper(haveemail) != 'N') {
	   printf("Please answer Y or N: ");
	   haveemail = getchar();
	   while (getchar() != '\n') ;
        }
        readsize = (toupper(haveemail) == 'Y' ? sizeof(urec) :
                    sizeof(urec) - sizeof(urec.email));
	while (read(fd, &urec, readsize) == readsize) {
		urec.userlevel = PERM_DEFAULT;
		if (toupper(haveemail) != 'Y') urec.email[0] = '\0';
		write(fd2, &urec, sizeof(urec));		
	}
	close(fd);
	close(fd2);
	printf("Successful completion.\n");
	printf("You may now copy %s onto %s.\n", NEWFILE, PASSFILE);
	exit(0);
}

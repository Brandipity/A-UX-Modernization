/***************************************************************************
 dumppass.c
 This utility dumps useful information from the bbs password file into a
 report. This program must be run in the directory where the .PASSWDS file
 or a copy exists. Six lines (or eight if REALINFO is defined in config.h)
 are written to the report for each user. They are:

 1. userid
 2. username
 3. terminal type
 4. last login host
 5. permission bits in binary format
 6. (if REALINFO defined) real name
 7. (if REALINFO defined) address
 8. or 6. email address

 A blank line is printed after each user's information.
****************************************************************************/

#include "bbs.h"
#define DUMPFILE "dumppass.out"
writeln(fd, str)
int fd;
char *str;
{
    static char nl = '\n';
    int wrote = write(fd, str, strlen(str));
    write(fd, &nl, 1);
    return wrote;
}

writebits(fd, perms)
int fd;
unsigned perms;
{
    unsigned i, one = 1;
    char buf[17];
    for (i=0; i<16; i++) {
	if (perms & (one << i)) buf[15-i] = '1';
	else buf[15-i] = '0';
    }
    buf[16] = '\0';
    writeln(fd, buf);
}

main()
{
    int ifd, ofd;
    struct userec urec;
    if ((ifd = open(PASSFILE, O_RDONLY)) == -1) {
	perror("Cannot open password file");
	return 1;
    }
    if ((ofd = open(DUMPFILE, O_WRONLY | O_CREAT, 0600)) == -1) {
	perror("Cannot open output file");
	return 1;
    }
    while (read(ifd, &urec, sizeof(urec)) == sizeof(urec)) {
	if (urec.userid[0] == '\0' || !strcmp(urec.userid, "new")) continue;
	writeln(ofd, urec.userid);
	writeln(ofd, urec.username);
	writeln(ofd, urec.termtype);
	writeln(ofd, urec.lasthost);
	writebits(ofd, urec.userlevel);	
#ifdef REALINFO
	writeln(ofd, urec.realname);
	writeln(ofd, urec.address);
#endif
	writeln(ofd, urec.email);
        writeln(ofd, "");
    }
    close(ifd);
    close(ofd);
    return 0;
}


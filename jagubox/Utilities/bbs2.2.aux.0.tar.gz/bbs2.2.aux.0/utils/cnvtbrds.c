#include "bbs.h"
#define SCRATCH	".SCRATCH"

main(argc, argv)
int argc;
char *argv[];
{
    int oldnum, newnum;
    int ofp, nfp;
    int shortsize, oldrecsize;
    char *obuf, *nbuf;
    int errflg = 0;
    if (argc != 4) {
	fprintf(stderr, "Usage: %s <file> <old#users> <new#users>\n", 
		argv[0]);
	return 1;
    }
    if ((oldnum = atoi(argv[2])) <= 0) {
	fprintf("Second argument (old#users) is zero or negative.\n");
        return 1;
    }
    if ((newnum = atoi(argv[3])) <= 0) {
	fprintf("Third argument (new#users) is zero or negative.\n");
        return 1;
    }
    shortsize = sizeof(struct fileheader) - MAXUSERS;
    oldrecsize = shortsize + oldnum;
    if (oldnum == newnum) {
	fprintf(stderr, "%s: no conversion needed.\n", argv[1]);
	return 0;
    }
    if ((obuf = (char *)malloc(oldrecsize)) == NULL) {
	fprintf(stderr, "malloc of %d bytes failed.\n", oldrecsize);
	return 1;
    }
    if ((nbuf = (char *)malloc(newnum)) == NULL) {
	fprintf(stderr, "malloc of %d bytes failed.\n", newnum);
	return 1;
    }
    memset(nbuf, 0, newnum);
    if ((ofp = open(argv[1], O_RDONLY)) == -1) {
	fprintf(stderr, "Error opening %s for reading.\n", argv[1]);
	return 1;
    }
    if ((nfp = open(SCRATCH, O_WRONLY|O_CREAT, 0644)) == -1) {
	fprintf(stderr, "Error opening %s for writing.\n", SCRATCH);
	close(ofp);
	return 1;
    }
    while (read(ofp, obuf, oldrecsize) == oldrecsize) {
        if (write(nfp, obuf, shortsize) != shortsize) errflg++;
        memcpy(nbuf, obuf+shortsize, oldnum);
        if (write(nfp, nbuf, newnum) != newnum) errflg++;
    }
    close(ofp);
    close(nfp);
    free(nbuf);
    free(obuf);
    unlink(argv[1]);
    if (rename(SCRATCH, argv[1])) {
	fprintf(stderr, "%s: rename failed!\n", argv[1]);
	return 1;
    }
    if (errflg) {
	fprintf(stderr, "%s: Error during write!\n", SCRATCH);
	return 1;
    }
    fprintf(stderr, "Converted %s.\n", argv[1]);
    return 0;
}

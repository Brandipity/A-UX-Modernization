/***************************************************************************
 movebrd.c
 This is a little program for moving a board to either the beginning of end 
 of the board list (the .BOARDS file). This program needs two arguments:
 the name of the board, and either "start" or "end". It will read the .BOARDS
 file in the current directory and write to BOARDS.NEW with the specified
 board moved to the start of end of the list. Note that it only does one 
 board at a time, if you want to do lots of rearranging you might want to copy
 .BOARDS to /tmp or something and write a script like

 movebrd %1 %2
 mv BOARDS.NEW .BOARDS

 then move the final BOARDS.NEW to it real place in the bbs.
****************************************************************************/

#include "bbs.h"
#define NEWBOARDS "BOARDS.NEW"
#include <unistd.h>
#ifndef SEEK_SET
#  define SEEK_SET L_SET
#endif

main(argc, argv)
int argc;
char *argv[];
{
	struct fileheader fh, fh2;
	struct stat stb1, stb2;
	int ifd, ofd, indx = 0, found = 0;
	if (argc != 3 || (strcmp(argv[2], "start") && strcmp(argv[2], "end"))) {
		printf("Usage: %s <board> (start | end)\n", argv[0]);
		exit(1);
	}
	if ((ifd = open(BOARDS, O_RDONLY)) == -1) {
		printf("%s: cannot open BOARDS file!\n", argv[0]);
		exit(1);
	}
	if ((ofd = open(NEWBOARDS, O_WRONLY | O_CREAT, 0644)) == -1) {
		printf("%s: cannot open output file!\n", argv[0]);
		exit(1);
	}
	while (read(ifd, &fh, sizeof(fh)) == sizeof(fh)) {
		if (!strcmp(fh.filename, argv[1])) {
			found++;
			break;
		}			
		else indx++;
	}
	lseek(ifd, 0, SEEK_SET);
	if (!found) {
		printf("%s: board %s not found!\n", argv[0], argv[1]);
		exit(1);
	}
	
	if (!strcmp(argv[2], "start"))
		write(ofd, &fh, sizeof(fh));
	found = 0;
	while (read(ifd, &fh2, sizeof(fh2)) == sizeof(fh2)) {
		if (found != indx)
			write(ofd, &fh2, sizeof(fh2));
		found++;
	}
	if (!strcmp(argv[2], "end"))
		write(ofd, &fh, sizeof(fh));
	close(ifd);
	close(ofd);
	if (stat(BOARDS, &stb1) || stat(NEWBOARDS, &stb2) ||
		stb1.st_size != stb2.st_size) {
		printf("Warning! File sizes aren't the same! \
			Something may be wrong.\n");
		exit(0);
	}
	printf("Success! You can copy %s to %s now.\n", BOARDS, NEWBOARDS);
	exit(0);
}
		

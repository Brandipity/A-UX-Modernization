#!/bin/csh
# IMPORTANT!!!!!!
# Set the values of OLDMAXUSERS and NEWMAXUSERS appropriately or you'll
# destroy your boards and mail. BACK UP EVERYTHING first!!!

set OLDMAXUSERS=780
set NEWMAXUSERS=780

foreach DIR (~bbs/mail/*)
    set FILE="$DIR/.DIR"
    if ( -f "$FILE" && ! -z "$FILE" ) then
        cnvtbrds $FILE $OLDMAXUSERS $NEWMAXUSERS
        /etc/chown bbs $FILE
    endif
end

if ( -f ~bbs/.BOARDS && ! -z ~bbs/.BOARDS ) then
    cnvtbrds ~bbs/.BOARDS $OLDMAXUSERS $NEWMAXUSERS
    /etc/chown bbs ~bbs/.BOARDS
endif

foreach DIR (~bbs/boards/*)
    set FILE="$DIR/.DIR"
    if ( -f "$FILE" && ! -z "$FILE" ) then
        cnvtbrds $FILE $OLDMAXUSERS $NEWMAXUSERS
        /etc/chown bbs $FILE
    endif
end

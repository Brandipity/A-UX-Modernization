/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifdef AUX
#include <sys/file.h>
#endif

#define EXTERN
#include "bbs.h"
#include <unistd.h>

x_passwd()
{
    char *pass, passbuf[PASSLEN],*getpass() ;
    char *genpasswd() ;

    move(3,0) ;
    clrtobot() ;
    getdata(3,0,"Old password: ",passbuf,PASSLEN,NOECHO,NULL) ;
    if (passbuf[0] == '\0' || !checkpasswd(currentuser.passwd, passbuf)) {
	prints("\nSorry.\n");
	pressreturn();
	return 0;
    } 
    getdata(3,0,"New password: ",passbuf,PASSLEN,NOECHO,NULL) ;
    if(passbuf[0] == '\0') {
        prints("\nBad Password\n") ;
        pressreturn() ;
        return 0;
    }
/*    strncpy(genbuf,pass,PASSLEN) ; */
    getdata(4,0,"ReEnter new password: ",genbuf,PASSLEN,NOECHO,NULL) ;
    if(strncmp(passbuf,genbuf,PASSLEN)) {
		prints("Error entering passwd\n") ;
		return -1 ;
    }
    genbuf[8] = '\0' ;
    pass = genpasswd(genbuf) ;
    strncpy(currentuser.passwd,pass,PASSLEN) ;
    substitute_record(PASSFILE,&currentuser,sizeof(currentuser),usernum) ;
    report("changed password");
    clr() ;
    return 0 ;
}

x_name()
{
	getdata(1,0,"Enter your name: ",genbuf,21,DOECHO,NULL) ;
	strncpy(currentuser.username,genbuf,STRLEN) ;
	substitute_record(PASSFILE,&currentuser,sizeof(currentuser),usernum) ;
	clr() ;
	return 0 ;
}

#ifdef INTERNET_EMAIL
x_setemail()
{
	getdata(1,0,"Enter your Internet e-mail address: ",genbuf,
		sizeof(currentuser.email), DOECHO, NULL);
	strncpy(currentuser.email,genbuf,sizeof(currentuser.email));
	substitute_record(PASSFILE,&currentuser,sizeof(currentuser),usernum) ;
	clr();
	return 0;
}
#endif

x_csh()
{
    int save_pager;
    clr() ;
    refresh() ;
    reset_tty() ;
    save_pager = uinfo.pager;
    uinfo.pager = NA ;
    substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
    report("shell out");
    do_exec(ESCAPE_SHELL, NULL) ;
    restore_tty() ;
    uinfo.pager = save_pager;
    substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
    clr() ;
    return 0 ;
}

x_terminal()
{
    getdata(1,0,"Enter new terminal type: ",genbuf,STRLEN,DOECHO,NULL) ;
    if(genbuf[0] == '\0')
	  return 0 ;
    if(!term_init(genbuf)) {
        move(2,0) ;
        prints("Invalid terminal type.\n") ;
        return -1 ;
    }
    strncpy(currentuser.termtype,genbuf,STRLEN) ;
    substitute_record(PASSFILE,&currentuser,sizeof(currentuser),usernum) ;
    initscr() ;
    clr() ;
    pressreturn() ;
    return 0 ;
}

unsigned
setperms(pbits)
unsigned pbits;
{
	int lastperm = NUMPERMS - 1;
	int i, done = NA;
	char buf[STRLEN], choice[2];
	move(4,0);
	prints("Enter the permission letter to toggle, RETURN when done.\n");
	move(6,0);
	for (i=0; i<=lastperm; i++) {
	    sprintf(buf, "%c. %-20s %3s\n", 'A' + i, permstrings[i],
		((pbits >> i) & 1 ? "ON" : "OFF"));
	    prints(buf);
	}
	clrtobot(); 
	while (!done) {
	    getdata(t_lines-1, 0, "Choice (ENTER to quit): ",choice,2,DOECHO,NULL);
	    *choice = toupper(*choice);
	    if (*choice == '\n' || *choice == '\0') done = YEA;
	    else if (*choice < 'A' || *choice > 'A' + lastperm) bell();
	    else {
		i = *choice - 'A';
		if ((pbits >> i) & 1)
		     pbits &= (~(1 << i));
		else pbits |= (1 << i);
		sprintf(buf, "%c. %-20s %3s\n", 'A' + i, permstrings[i],
		    ((pbits >> i) & 1 ? "ON" : "OFF"));
		move(i+6,0);
		prints(buf);
	    }
	}				
	return (pbits);
}

x_level()
{
   	int id ;
#ifdef PERMS
	int newlevel;
#endif

	u_namelist() ;
	move(0,0) ;
	prints("Change User Priority\n") ;
	clrtoeol() ;
	move(1,0) ;
	namecomplete("Enter userid to be changed: ",genbuf) ;
	if(genbuf[0] == '\0') {
		clr() ;
		return 0 ;
	}
	if(!(id = getuser(genbuf))) {
		move(3,0) ;
		prints("Invalid User Id") ;
		clrtoeol() ;
		pressreturn() ;
		clr() ;
		return 0 ;
	}
#ifdef PERMS
	move(1,0);
	clrtobot();
	move(2,0);
	prints("Set the desired permissions for user '%s'\n", genbuf);
	newlevel = setperms(lookupuser.userlevel);	
#else
	getdata(1,0,"Enter priority: ",genbuf,7,DOECHO,NULL) ;
	lookupuser.userlevel = atoi(genbuf) ;
#endif
	move(2,0);
	if (newlevel == lookupuser.userlevel)
	    prints("User '%s' level NOT changed\n", lookupuser.userid);
	else {
            lookupuser.userlevel = newlevel;
            substitute_record(PASSFILE,&lookupuser,sizeof(struct userec),id) ;
            prints("User '%s' level changed\n",lookupuser.userid) ;
	    sprintf(genbuf, "changed permissions for %s", lookupuser.userid);
	    report(genbuf);
	}
	pressreturn() ;
	clr() ;
	return 0 ;
}

x_cloak()
{
	uinfo.invisible = (uinfo.invisible)?NA:YEA ;
	substitute_record(ULIST,&uinfo,sizeof(uinfo), utmpent) ;
	move(3,0) ;
	if (!uinfo.in_chat)
	    prints("Cloak has been %s.\n",(uinfo.invisible)?"activated":"deactivated") ;
	report("toggle cloak");
	return 0 ;
}

x_date()
{
	time_t t;
	move(3,0);
	time(&t);
	prints("Current local date and time: %s", ctime(&t));
	clrtobot();
	return 0;
}	

#ifdef REALINFO
x_info()
{
	user_display(&currentuser);
	prints("\n");
	prints("Please report any discrepancies to SYSOP.\n");
	clrtobot();
	pressreturn();
	clr();
}
#endif

x_editsig()
{
	int aborted;
	char ans[7];
	sprintf(genbuf, "signatures/%s", currentuser.userid);
	move(3,0);
	clrtoeol();
	clrtobot();
	if (currentuser.flags[0] & SIG_FLAG)
	    getdata(3,0,"(E)dit, (D)elete, or (T)urn on signature file? [E]: ",ans,7,DOECHO,NULL);
	else
	    getdata(3,0,"(E)dit, (D)elete, or (T)urn off signature file? [E]: ",ans,7,DOECHO,NULL);
	if (ans[0] == 'D' || ans[0] == 'd') {
		unlink(genbuf);
		move(5,0);
		prints("It's history!\n");
		pressreturn();
		clr();
		return;
	}
	if (ans[0] == 'T' || ans[0] == 't') {
		move(5,0);
		if (currentuser.flags[0] & SIG_FLAG) {
		    currentuser.flags[0] &= ~SIG_FLAG;
		    prints("Signature turned on (enabled).\n");
		}
		else {
		    currentuser.flags[0] |= SIG_FLAG;
		    prints("Signature turned off (disabled).\n");
		}
		substitute_record(PASSFILE, &currentuser, sizeof(currentuser), usernum);
		pressreturn();
		clr();
		return;
	}
	uinfo.mode = EDITSIG;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	aborted = vedit(genbuf, NA);		
	clr();
	if (!aborted) prints("Signature updated.");
	pressreturn();
	uinfo.mode = XMENU;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
}

#ifdef MMMM

x_edit4mrc()   /* Bill Schwartz */
{
        int aborted;
        char ans[8];
        char buf[128] ;
        sprintf(genbuf, "fourm_rc/%s", currentuser.userid);
        move(3,0);
        clrtoeol();
        clrtobot();
        getdata(3,0,"(E)dit or (D)elete 4mrc? [E]: ",ans,7,DOECHO,NULL);
        if (ans[0] == 'D' || ans[0] == 'd') {
                unlink(genbuf);
                move(5,0);
                prints("It's history!\n");
                pressreturn();
                clr();
                return;
        }
        uinfo.mode = EDITPLAN;
	report("edit .4mrc");
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
        sprintf(buf,"fourm_rc/%s", currentuser.userid) ;
        if (access(buf, R_OK) !=0)  /* see if a copy of default is needed*/
	{
		sprintf(buf, "cp .4mrc fourm_rc/%s", currentuser.userid);
		system(buf);
	}
       	aborted = vedit(genbuf, NA);
        clr();
        if (!aborted) prints("4mrc updated.");
        pressreturn();
        uinfo.mode = XMENU;
        substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
}
#endif

x_editplan()
{
	int aborted;
	char ans[7];
	sprintf(genbuf, "plans/%s", currentuser.userid);
	move(3,0);
	clrtoeol();
	clrtobot();
	getdata(3,0,"(E)dit or (D)elete plan? [E]: ",ans,7,DOECHO,NULL);
	if (ans[0] == 'D' || ans[0] == 'd') {
		unlink(genbuf);
		move(5,0);
		prints("It's history!\n");
		report("delete plan");
		pressreturn();
		clr();
		return;
	}
	uinfo.mode = EDITPLAN;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	aborted = vedit(genbuf, NA);		
	clr();
	if (!aborted) {
	    prints("Plan updated.");
	    report("edited plan");
	}
	pressreturn();
	uinfo.mode = XMENU;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
}

#ifdef VOTE

#ifndef AUX
#include <sys/file.h>
#endif

long atol();
#if !defined(AIX) && !defined(NEXT)
extern char *index();
#endif

x_vote()
{
	FILE *cfp;
	char inbuf[80], choices[10], vote[2];
	int fd, count = 0;
	time_t closetime;
	move(3,0);
	if ((cfp = fopen("vote/control", "r")) == NULL) {
	    prints("Sorry, the polls are not open at this time.\n");
	    clrtobot();
	    pressreturn();
	    clr();
	    return;
	}
	if (currentuser.flags[0] & VOTE_FLAG) {
	    prints("The polls are open but you've already voted!\n");
	    prints("Only one vote per userid is allowed.\n");
	    clrtobot();
	    pressreturn();
	    clr();
	    return;
	}
	uinfo.mode = VOTING;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	more("vote/desc", YEA);
	clr();
	move(0,0);
	standout();
	prints("THE BALLOT");
	standend();
	move(2,0);
	prints("To cast your vote, enter the digit next to your selection.\n");
	prints("Any other key aborts voting.\n");
	fgets(inbuf, sizeof(inbuf), cfp);
	closetime = (time_t)atol(inbuf);
	prints("This poll will close at: %s\n", ctime(&closetime));		
	move(6,0);
	bzero(choices, sizeof(choices));
	while (fgets(inbuf, sizeof(inbuf), cfp) != NULL) {
	    choices[count++] = inbuf[0];
	    prints("%s", inbuf);
	}
	fclose(cfp);
	vote[0] = vote[1] = '\0';
	getdata(count+8, 0, "Enter your choice: ", vote, 2, DOECHO, NULL);
	move(count+10, 0);
	if (vote[0] == '\0' || index(choices, vote[0]) == NULL)
	    prints("Invalid choice...voting aborted.\n");
	else {
	    if ((fd = open("vote/ballots", O_WRONLY|O_CREAT|O_APPEND, 0600)) == 0)
		prints("Can't open the ballot box! Aborting...\n");
	    else {
		struct stat statb;
		flock(fd, LOCK_EX);
		write(fd, vote, 1);
		flock(fd, LOCK_UN);
		fstat(fd, &statb);
		close(fd);
		currentuser.flags[0] |= VOTE_FLAG;
		substitute_record(PASSFILE, &currentuser, sizeof(currentuser), usernum);
	    	prints("Ballot recorded! (%d cast so far)\n", statb.st_size);
	    }
	}
	pressreturn();
	uinfo.mode = XMENU;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	clr();
}

x_results()
{
	if(more("vote/results", YEA) == -1) {
	    move(3,0);
	    prints("No election results are available at this time.\n");
	    clrtobot();
	    pressreturn();
	}
	else clr();
}

#endif

#ifdef BBSDOORS

ent_bnet()  /* Bill Schwartz */
{
    int save_pager = uinfo.pager;
    uinfo.pager = NA;
    uinfo.mode = BBSNET ;
    report("BBSNet Enter") ;
    substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent) ;
    /* bbsnet.sh is a shell script that can be customized without */
    /* having to recompile anything.  If you edit it while someone */
    /* is in bbsnet they will be sent back to the xyz menu when they */
    /* leave the system they are currently in. */
    reset_tty() ;
#ifdef AUX
    do_exec("/users/bbs/bin/bbsnet.sh",NULL) ;
#endif
#ifndef AUX
    do_exec("bbsnet.sh",NULL) ;
#endif
    restore_tty() ;
    uinfo.pager = save_pager;
    uinfo.mode = XMENU ;
    report("BBSNet Exit") ;
    substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent) ;
    clr() ;
}

#endif

/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#ifdef AUX
#include <sys/types.h>
#include "bbs.h"
#include "chat.h"
#ifdef lint
#include <sys/uio.h>
#endif
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <errno.h>
#endif

#ifndef AUX
#include "bbs.h"
#include "chat.h"
#include <sys/types.h>
#ifdef lint
#include <sys/uio.h>
#endif
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <errno.h>
#endif

int chatroom;
int chatline;
int echatwin;
extern char page_requestor[];
extern char BoardName[];
extern int talkrequest;
extern char *modestring();
extern char pagerchar();
extern char *Ctime();

fixchatid(chatid)
char *chatid;
{
	while (*chatid != '\0' && *chatid != '\n') {
		if (index(BADCIDCHARS, *chatid)) *chatid = '_';
		chatid++;
	}
}

t_chat()
{
	char chatid[STRLEN] ;
#ifndef INET_ADDRESS
	struct hostent *h ;
	char hostname[STRLEN] ;
#endif
	struct sockaddr_in sin ;
	char *colon;
	int a, n;
	int currchar ;
	int chatport;
	int newmail = 0;
	char chatstr[80];
	char inbuf[80] ;
	int pline;
	extern int dumb_term ;
	int page_pending = NA;
	time_t last_check = 0, now;

	inbuf[0]='\0'; 
	switch (chatroom) {
	  case 1: report("Chat-1"); break;
	  case 2: report("Chat-2"); break;
	  case 3: report("Chat-3"); break;
	  case 4: report("Chat-4"); break;
	}
	chatline = 0 ;
	currchar = 0 ;
	move(2,0) ;
	prints("<Enter Chat alias (8 char max)>\n") ;
	getdata(1,0,"Enter Chat id: ", chatid,9,DOECHO,NULL) ;
	if(chatid[0] == '\0')
        strcpy(chatid,currentuser.userid) ;
	chatid[8] = '\0' ;
	fixchatid(chatid);
	strcat(chatid, ":           ") ; /* shortened by !DK! */
	chatid[10] = '\0' ;
	strcpy(inbuf,chatid) ;
        bzero(&sin, sizeof sin);
#ifdef INET_ADDRESS
	sin.sin_family = PF_INET;
	sin.sin_addr.s_addr = inet_addr(INET_ADDRESS);
#else
	gethostname(hostname,STRLEN) ;
	if (!(h = gethostbyname(hostname))) {
		perror("gethostbyname");
		return -1;
	}
	sin.sin_family = h->h_addrtype ;
	bcopy(h->h_addr, &sin.sin_addr, h->h_length) ;
#endif
	switch (chatroom) {
	  case 4: chatport = CHATPORT4; break;
	  case 1: chatport = CHATPORT1; break;
	  case 2: chatport = CHATPORT2; break;
	  case 3: chatport = CHATPORT3; break;
	}
	sin.sin_port = htons(chatport);
	a = socket(sin.sin_family, SOCK_STREAM, 0); 
	if((connect(a, (struct sockaddr *)&sin, sizeof sin))) {
		move(2,0) ;
		prints("Creating Chat Daemon\n") ;
		refresh() ;
		close(a) ;
#ifdef AUX
		sprintf(chatstr, "bbs.chatd %d", chatroom);
#endif
#ifndef AUX
		sprintf(chatstr, "bin/bbs.chatd %d", chatroom);
#endif
		system(chatstr);
		sleep(2) ;
		a = socket(sin.sin_family, SOCK_STREAM, 0); 
		if((connect(a, (struct sockaddr *)&sin, sizeof sin))) {
			perror("connect failed") ;
			return -1 ;
		}
	}
	switch(chatroom) {
	  case 4: uinfo.mode = CHAT4; break;
	  case 1: uinfo.mode = CHAT1; break;
	  case 2: uinfo.mode = CHAT2; break;
	  case 3: uinfo.mode = CHAT3; break;
	}
	uinfo.in_chat = YEA;
	strncpy(uinfo.chatid, chatid, 10);
        if (colon = rindex(uinfo.chatid, ':')) *colon = '\0';
      	substitute_record(ULIST,&uinfo, sizeof(uinfo), utmpent) ;
	if (uinfo.invisible) {
#ifdef PERMS
	    if (HAS_PERM(PERM_SYSOP))
#else
	    if (currentuser.userlevel == 255)
#endif
	        sprintf(inbuf, "/sysopin %s", uinfo.chatid);
	    else sprintf(inbuf, "/cloakin %s", uinfo.chatid);
	}
 	else sprintf(inbuf, "%sWelcome!", chatid);
	write(a,inbuf,strlen(inbuf)+1) ;
	clr() ;
	sprintf(inbuf, "%s Chat Room -- type /help for help", BoardName);
	printchatline(inbuf);
	printchatline("  ");
	strcpy(inbuf,chatid) ;
	pline = t_lines - 1 ;
	echatwin = t_lines - 2 ;
	move(echatwin,0) ;
	prints("--------------------------------------------------------------------------------") ;
	move(pline,0) ;
	if(!dumb_term)
	prints("%s",inbuf) ;
	currchar = strlen(inbuf) ;
	add_io(a,0) ;
	while(YEA) {
	    int ch = igetch();
	    if (talkrequest) page_pending = YEA;
	    if (page_pending)
		      page_pending = servicepage(0);	
	    if (!newmail && chkmail()) {
		newmail = 1;
		move(echatwin,0);
		prints("--- You have new mail ------------------------------------------------------");
	    }
	    if(ch == I_OTHERDATA) {
		static int cnt  = 0;
            	int cc ;
		static char buf[512] ;
			
		if((cc = read(a,buf+cnt,sizeof buf)) > 0) {
                    int processed = 0 ;

                    while(cc > 0) {
                        register int i ;
                        for(i=processed;buf[i] != '\0' && i != sizeof buf;i++)
                          /* NULL STATEMENT */ ;
                        if(i==sizeof buf && buf[i] != '\0') {
                            bcopy(buf+processed,buf,processed-sizeof(buf)) ;
                            cnt = processed - sizeof(buf) ;
                            break ;
                        }
                        cnt = 0 ;
		        if (*(buf+processed) == '/')
			    printinfoline(buf+processed+1);
		        else 
		            printchatline(buf+processed);
                        i++ ;
                        cc -= (i - processed) ;
                        processed = i ;
                        if(i == sizeof buf)
                        break ;
                    }
                }
	        /* trap for chat daemon death */
	        else {
	           sprintf(buf, "CHAT FAILURE: read returned %d, errno = %d\n", cc, errno);
	           report(buf);
	           break;
	        }
                move(pline,currchar) ;
                continue ;
	    }
#ifdef BIT8
	    if(isprint2(ch)) {
#else
            if(isprint(ch)) {
#endif
                if(currchar == 78) {
                    bell() ;
                    continue ;
                }
                inbuf[currchar] = ch ;
                currchar++ ;
                inbuf[currchar] = '\0' ;
                move(pline,currchar-1) ;
                prints("%c",ch) ;
                continue ;
            }
            if(ch == '\n' || ch == '\r') {
                char buf[STRLEN] ;
	        int i,j ;
            
                if(dumb_term)
                    prints("\n") ;
                for(i=10,j=0;i<STRLEN;i++) {
                    if(inbuf[i] == '\0') {
                        buf[j] = '\0' ;
                        break ;
                    }
                    if(inbuf[i] != ' ')
                      buf[j++] = inbuf[i] ;
                }
                if(buf[0] == '\0')
                    continue ;
                if(!strcmp(buf,"Goodbye!")) {
/*                  report("Chat user typed Goodbye!") ;*/
                    if (uinfo.invisible) {
#ifdef PERMS
			if (HAS_PERM(PERM_SYSOP))
#else
                        if (currentuser.userlevel == 255)
#endif
                            sprintf(inbuf, "/sysopout %s", uinfo.chatid);
                        else sprintf(inbuf, "/cloakout %s", uinfo.chatid);
                    }
                    else sprintf(inbuf,"%sGoodbye!",chatid) ;
                    write(a,inbuf,strlen(inbuf)+1) ;
                    break ;
                }
	        if (inbuf[10] == '/') {
		    int action = dochatcommand(&inbuf[11], a);
		    if (action == 1) {
		        strcpy(chatid, uinfo.chatid);
	                chatid[8] = '\0' ;
                        strcat(chatid,":                      ") ;
                        chatid[10] = '\0' ;
		    }
		    else if (action == -1) {
		        sprintf(buf, "CHAT FAILURE: write returned -1, errno = %d\n", errno);
		        report(buf);
		        break;
		    }
	        }
	        else if (write(a,inbuf,strlen(inbuf)+1) == -1) {
		    sprintf(buf, "CHAT FAILURE: write returned -1, errno = %d\n", errno);
		    report(buf);
		    break;
	        }
                move(pline,0) ;
                strcpy(inbuf,chatid) ;
                currchar = strlen(inbuf) ;
                if(!dumb_term)
                    prints("%s",inbuf) ;
                clrtoeol() ;
                move(pline,currchar) ;
                continue ;
            }
            if(ch == CTRL('H') || ch == '\177') {
                if(currchar == 10) {
                    bell() ;
                    continue ;
                }
                currchar-- ;
                move(pline,currchar) ;
                if(dumb_term)
                    ochar(CTRL('H')) ;
                else
                    prints(" ") ;
                move(pline,currchar) ;
                inbuf[currchar] = '\0' ;
                continue ;
            }
            if(ch == CTRL('C') || ch == CTRL('D')) {
	        if (uinfo.invisible) {
#ifdef PERMS
		    if (HAS_PERM(PERM_SYSOP))
#else
		    if (currentuser.userlevel == 255)
#endif
		        sprintf(inbuf, "/sysopout %s", uinfo.chatid);
		    else sprintf(inbuf, "/cloakout %s", uinfo.chatid);
	        }
	        else sprintf(inbuf,"%sGoodbye!",chatid) ;
                write(a,inbuf,strlen(inbuf)+1) ;
                break ;
            }
        }
        add_io(0,0) ;
	close(a) ;
	uinfo.in_chat = NA;
	uinfo.mode = TMENU ;
	uinfo.chatid[0] = '\0';
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent) ;
	clr() ;
	return  0;
}

char *advance(ptr)
char *ptr;
{
	while (*ptr != ' ' && *ptr != '\n' && *ptr != '\t') {
	    if (*ptr == '\0') return ptr;
	    else ptr++;
	}
	while (*ptr == ' ' || *ptr == '\n' || *ptr == '\t')
	    ptr++;
	*(ptr-1) = '\0';
	return ptr;
}

printchatline(str)
char *str;
{
        move(chatline++,0) ;
        clrtoeol() ;
        prints("%s\n",str) ;
        if(chatline == echatwin)
            chatline = 0 ;
        move(chatline,0) ;
        clrtoeol() ;
        if(!dumb_term)
            prints("-->") ;
	return 0;
}

printprivmsg(to_ptr)
char *to_ptr;
{
	char *fromptr = advance(to_ptr);
	char *msgptr = advance(fromptr);
	if (!ci_strncmp(to_ptr, currentuser.userid, sizeof(currentuser.userid))) {
	   char buf[STRLEN];
	   sprintf(buf, "*%s* %s", fromptr, msgptr);
	   standout();
	   printchatline(buf);
	   standend();
	}
}

printinfoline(cmd)  /* re-written slightly by !DK! */
char *cmd;
{
	char *nextarg;
	char buf[STRLEN];
	nextarg = advance(cmd);
#ifdef PERMS
        if ((!strcmp(cmd, "sysopin") && HAS_PERM(PERM_SYSOP)) ||
            (!strcmp(cmd, "cloakin") && HAS_PERM(PERM_SEECLOAK)) )
#else
        if ((!strcmp(cmd, "sysopin") && currentuser.userlevel == 255) ||
            (!strcmp(cmd, "cloakin") && currentuser.userlevel >= SEE_CLOAK) )
#endif
	{
	    sprintf(buf, "** INFO: %s is entering cloaked", nextarg);
	    printchatline(buf);
	}
#ifdef PERMS
        else if ((!strcmp(cmd, "sysopout") && HAS_PERM(PERM_SYSOP)) ||
            (!strcmp(cmd, "cloakout") && HAS_PERM(PERM_SEECLOAK)) )
#else
        else if ((!strcmp(cmd, "sysopout") && currentuser.userlevel == 255) ||  
            (!strcmp(cmd, "cloakout") && currentuser.userlevel >= SEE_CLOAK) )
#endif
	{
            sprintf(buf, "** INFO: %s has exited cloaked", nextarg);
            printchatline(buf);
        }
	else if (!strcmp(cmd, "to"))
            printprivmsg(nextarg);
#ifdef PERMS
	else if (!strcmp(cmd, "nick") || (!strcmp(cmd, "inick") && HAS_PERM(PERM_SEECLOAK)) ||
	         (!strcmp(cmd, "snick") && HAS_PERM(PERM_SYSOP))) {
#else
	else if (!strcmp(cmd, "nick") || (!strcmp(cmd, "inick") && currentuser.userlevel >= SEE_CLOAK) ||
	         (!strcmp(cmd, "snick") && currentuser.userlevel == 255)) {
#endif
	    sprintf(buf, "** INFO: %s is now known as %s", nextarg,
                    advance(nextarg));
	    printchatline(buf);
	}
}

printchatent(uentp)
struct user_info *uentp;
{
	struct userec utmp;
	static char uline[80];
	char pline[30];
	static int cnt;
	int mymode;
	switch (chatroom) {
	    case 4: mymode = CHAT4; break;
	    case 1: mymode = CHAT1; break;
	    case 2: mymode = CHAT2; break; 
	    case 3: mymode = CHAT3; break;
	}
	if (!uentp) {
	    if (cnt) printchatline(uline);
	    bzero(uline, 80);
	    cnt = 0;
	    return 0;
	}
	if (!uentp->active || !uentp->pid) return 0;
	if (uentp->mode != mymode) return 0;
#ifdef PERMS
	if (!HAS_PERM(PERM_SEECLOAK) && uentp->invisible) return 0;
#else
	if (currentuser.userlevel < SEE_CLOAK && uentp->invisible) return 0;
#endif
	if (kill(uentp->pid, 0) == -1) return 0;
	get_record(PASSFILE, &utmp, sizeof(utmp), uentp->uid);
	sprintf(pline, "%-10s %c%-12s", uentp->chatid, uentp->invisible?'#':' ',
		utmp.userid);
	if (cnt < 2) strcat(pline, "   ");
	strcat(uline, pline);
	if (++cnt == 3) {
	    cnt = 0;
	    printchatline(uline);
	    bzero(uline, 80);
	}
	return 0;
}


dowho()
{
	int mymode;
	char buf[80];
	printchatline(" ");
	printchatline("*** List users in current room ***") ;
	sprintf(buf, "%-10s  %-12s   %-10s  %-12s   %-10s  %-12s",
	        "Chatid", "Userid", "Chatid", "Userid", "Chatid", "Userid");
	printchatline(buf);
	sprintf(buf, "%-10s  %-12s   %-10s  %-12s   %-10s  %-12s",
		"------", "------", "------", "------", "------", "------");
	printchatline(buf);
	if (apply_record(ULIST, printchatent, sizeof(struct user_info)) == -1) {
	    printchatline("(nobody)");
	    return 0;
	}
	printchatent(NULL);
	return 0;
}

printuserent(uentp)
struct user_info *uentp;
{
	struct userec utmp;
	static char uline[80];
	char pline[30];
	static int cnt;
	if (!uentp) {
	    if (cnt) printchatline(uline);
	    bzero(uline, 80);
	    cnt = 0;
	    return 0;
	}
	if (!uentp->active || !uentp->pid) return 0;
#ifdef PERMS
	if (!HAS_PERM(PERM_SEECLOAK) && uentp->invisible) return 0;
#else
	if (currentuser.userlevel < SEE_CLOAK && uentp->invisible) return 0;
#endif
	if (kill(uentp->pid, 0) == -1) return 0;
	get_record(PASSFILE, &utmp, sizeof(utmp), uentp->uid);
	sprintf(pline, "%-12s %c%-10s", utmp.userid, uentp->invisible?'#':' ',
		modestring(uentp->mode, uentp->destuid, 0, NULL));
	if (cnt < 2) strcat(pline, "   ");
	strcat(uline, pline);
	if (++cnt == 3) {
	    cnt = 0;
	    printchatline(uline);
	    bzero(uline, 80);
	}
	return 0;
}

dousers()
{
	int mymode;
	char buf[80];
	printchatline(" ");
	printchatline("*** List users currently online ***") ;
	sprintf(buf, "%-12s  %-10s   %-12s  %-10s   %-12s  %-10s",
	        "Userid", "Mode", "Userid", "Mode", "Userid", "Mode");
	printchatline(buf);
	sprintf(buf, "%-12s  %-10s   %-12s  %-10s   %-12s  %-10s",
		"------", "----", "------", "----", "------", "----");
	printchatline(buf);
	if (apply_record(ULIST, printuserent, sizeof(struct user_info)) == -1) {
	    printchatline("(nobody)");
	    return 0;
	}
	printuserent(NULL);
	return 0;
}

#ifdef REALINFO
int chat_real_names = 0;
#endif

printlongent(uentp)
struct user_info *uentp;
{
	struct userec utmp;
	char buf[80];
	char *field2;
#ifdef REALINFO
	if (chat_real_names) field2 = "Real Name";
	else
#endif
	field2 = "User Name";
	if (uentp == NULL) {
	    printchatline(" ");
	    printchatline("*** List users currently online ***");
	    sprintf(buf, "User Id      %s              From             P %s Mode", field2,
#ifdef PERMS
		HAS_PERM(PERM_SEECLOAK) ? "C" : " ");
#else
		currentuser.userlevel >= SEE_CLOAK ? "C" : " ");
#endif
	    printchatline(buf);
	    sprintf(buf, "-------      ---------              ----             - %s ----",
#ifdef PERMS
		HAS_PERM(PERM_SEECLOAK) ? "-" : " ");
#else
		currentuser.userlevel >= SEE_CLOAK ? "-" : " ");
#endif
	    printchatline(buf);
	    return(0);
	}
	if (!uentp->active || !uentp->pid)
	    return 0;
#ifdef PERMS
	if (!HAS_PERM(PERM_SEECLOAK) && uentp->invisible)
#else
	if (currentuser.userlevel < SEE_CLOAK && uentp->invisible)
#endif
	    return 0;
	if (kill(uentp->pid, 0) == -1)
	    return 0;
	get_record(PASSFILE, &utmp, sizeof(utmp), uentp->uid);
	utmp.username[21] = '\0';
#ifdef REALINFO
	utmp.realname[21] = '\0';
#endif
	sprintf(buf, "%-12s %-22s %-16s %c %1s %-9s", utmp.userid, 
#ifdef REALINFO
		(chat_real_names ? utmp.realname : utmp.username),
#else
		utmp.username,
#endif
	        uentp->from, pagerchar(currentuser.userid, utmp.userid, uentp->pager),uentp->invisible?"#":"",
		modestring(uentp->mode, uentp->destuid, 1, uentp->in_chat ? uentp->chatid : NULL));
	printchatline(buf);
	return 0;
}	

dolong()
{
	printlongent(NULL);
	if (apply_record(ULIST, printlongent, sizeof(struct user_info)) == -1)
	    printchatline("(nobody)");
	return 0;
}
	
#ifdef REALINFO
doreal()
{
	chat_real_names = 1;
	dolong();
	chat_real_names = 0;
}
#endif

char *msgto;
char *umsgto;

chatlookup(uin)
struct user_info *uin;
{
	static int matchcnt, exact;
	static char fullid [10], userid [15];
	struct userec utmp;
	int umatch, cmatch;
	if (!uin) {
	   int final = (matchcnt > 1 ? -1 : matchcnt);
	   msgto = fullid;
	   umsgto = userid;
	   matchcnt = exact = 0;
	   return final;
	}
	if (uin->mode != uinfo.mode) return 0;
	if (!uin->active || kill(uin->pid, 0)==-1) return 0;
#ifdef PERMS
	if (uin->invisible && !HAS_PERM(PERM_SEECLOAK)) return 0;
#else
	if (uin->invisible && currentuser.userlevel < SEE_CLOAK) return 0;
#endif
	get_record(PASSFILE, &utmp, sizeof(utmp), uin->uid);
	cmatch = !ci_strncmp(msgto, uin->chatid, strlen(msgto));
	umatch = !ci_strncmp(msgto, utmp.userid, strlen(msgto));
	if (umatch || cmatch) {
	    int isexact = (cmatch ? (strlen(msgto) == strlen(uin->chatid)) :
			            (strlen(msgto) == strlen(utmp.userid)));
	    if (matchcnt > 0) {
		if (exact && isexact) {
		    matchcnt = exact = 0;
		    return QUIT;
		}
		else if (exact && !isexact) return 0;
		else if (!exact && isexact) matchcnt = 0;
	    }
	    matchcnt++;
	    if (isexact) exact++;
	    strcpy(fullid, uin->chatid);
	    strcpy(userid, utmp.userid);
	    return 0;
	}
}

domsg(id, fd)
char *id;
int fd;
{
	char *text;
	char buf2[STRLEN], buf[STRLEN];
	int verdict, retval;
	while (*id == ' ' || *id == '\t' || *id == '\n') id++;
	if (*id == '\0') {
	    printchatline("** ERROR: you must specify a recipient");
	    return;
	}
	text = advance(id);
	msgto = id;
	if (*text == '\0') {
	    printchatline("** ERROR: blank messages aren't allowed");
	    return;
	}
	if (apply_record(ULIST, chatlookup, sizeof(struct user_info)) == QUIT)
	    verdict = -1;
	else verdict = chatlookup(NULL);
	switch (verdict) {
	    case 0: printchatline("** ERROR: user is not in the chat room");
	      break;
	    case -1: printchatline("** ERROR: that name is ambiguous; try using more letters");
	      break;
	    default: sprintf(buf, "/to %s %s %s", umsgto, uinfo.chatid, text);
		     buf[STRLEN-1] = '\0';
     		     retval = write(fd, buf, strlen(buf)+1);
		     sprintf(buf2, "%s> %s", msgto, text);
		     printchatline(buf2);
	}
	msgto = NULL;
	if (retval > -1) retval = 0;
	return retval;
}

donick(newname, fd)
char *newname;
int fd;
{
	char *p;
	char buf[40];
	int retval;
	while (*newname == ' ' || *newname == '\t' || *newname == '\n')
	    newname++;
	if (*newname == '\0') {
	    printchatline("** ERROR: you must give a name");
	    return;
	}
	for (p = newname; *p && *p!=' ' && *p!='\t' && *p!='\n'; p++);
	*p = '\0';
	if (strlen(newname) > 8)
	    newname[8] = '\0';
	fixchatid(newname);
	if (!uinfo.invisible)
	    sprintf(buf, "/nick %s %s", uinfo.chatid, newname);
	else {
#ifdef PERMS
	    if (HAS_PERM(PERM_SYSOP))
#else
	    if (currentuser.userlevel == 255)
#endif
		sprintf(buf, "/snick %s %s", uinfo.chatid, newname);
	    else sprintf(buf, "/inick %s %s", uinfo.chatid, newname);
	}
	retval = write(fd, buf, strlen(buf)+1);
	strcpy(uinfo.chatid, newname);
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	if (retval > -1) retval = 1;  /* cause t_chat to update chatid */
	return retval;
}
	
dochatcommand(cmd, fd)
char *cmd;
int fd;
{
	char *endcmd;
	int retval = 0, cmdlen;
	while (*cmd == ' ') cmd++;
	endcmd = cmd;
	while (*endcmd != ' ' && *endcmd != '\n' && *endcmd) endcmd++;
	if (*endcmd == '\0') *(endcmd+1) = '\0';
	else *endcmd = '\0';
	cmdlen = strlen(cmd);
        if (!ci_strncmp(cmd, "help",cmdlen)) {
	    printchatline("Special Chat Commands:");
	    printchatline("  /help            - get this help screen [also /h]");
	    printchatline("  /who             - see who is in this chat room [also /w]");
	    printchatline("  /users           - see who is on the bbs [also /u]");
	    printchatline("  /long            - long version of /users [also /l]");
#ifdef REALINFO
	    printchatline("  /real            - real name version of /long [also /r]");
#endif
	    printchatline("  /msg <id> <text> - sends <text> to <id> only [also /m]");
#ifdef PERMS
	    if (HAS_PERM(PERM_BASIC))
#endif
	    printchatline("  /pager           - toggle pager on/off [also /p]");
	    printchatline("  /nick <name>     - change chatid to <name> [also /n]");
	    printchatline("  /me <action>     - like /me in IRC or emote on a MUD");
	    printchatline("  /clear           - clears screen [also /c]");
	    printchatline("  /date            - get local date/time [also /d]");
#ifdef PERMS
	    if(HAS_PERM(PERM_CHATCLOAK) && HAS_PERM(PERM_CLOAK))
#else
	    if(currentuser.userlevel>=CLOAK)
#endif
	    printchatline("  /cloak           - toggle cloak [also /clo]");
	    printchatline("  ctrl-d           - exit chat");
	}
        else if (!ci_strncmp(cmd, "who", cmdlen))
	    dowho();
        else if (!ci_strncmp(cmd, "users", cmdlen))
	    dousers();
        else if (!ci_strncmp(cmd, "long", cmdlen))
	    dolong();
#ifdef REALINFO
        else if (!ci_strncmp(cmd, "real", cmdlen))
            doreal();
#endif
        else if (!ci_strncmp(cmd, "msg", cmdlen))
	    retval = domsg(endcmd+1, fd);
        else if (!ci_strncmp(cmd, "nick", cmdlen)) {
	    retval = donick(endcmd+1, fd);
	}
        else if (!ci_strncmp(cmd, "pager",cmdlen)) {
#ifdef PERMS
	    if (HAS_PERM(PERM_BASIC)) {
#endif
   	        t_pager() ;
	        printchatline(" ") ;
	        if (!uinfo.pager) 
	            printchatline("*** Pager turned off") ; 
	        else
	            printchatline("*** Pager turned on") ;
#ifdef PERMS
	    }
            else printchatline("** ERROR: unknown special chat command") ;
#endif
        }
        else if (!ci_strncmp(cmd, "me", cmdlen)) {
	   char actionbuf[80], *firstlet = endcmd + 1;
	   while (*firstlet == ' ' || *firstlet == '\n' || *firstlet == '\t')
	      firstlet++;
	   if (*firstlet != '\0') {
	     sprintf(actionbuf, "%s %s", uinfo.chatid, endcmd+1);
	     write(fd, actionbuf, strlen(actionbuf)+1);
	   }
	   else printchatline("** ERROR: You must specify an action");
	}	   
        else if (!ci_strncmp(cmd, "clear", cmdlen)) {
	   char bufr[80];
	   clr();
           move(echatwin,0) ;
           prints("--------------------------------------------------------------------------------") ;
	   chatline = 0;
	   sprintf(bufr, "%s Chat Room -- type /help for help", BoardName);
	   printchatline(bufr);
           printchatline("  ");
        }
	else if (!ci_strncmp(cmd,"date", cmdlen)) {
	   char bufr[80];
	   time_t thetime;
	   time(&thetime);
	   sprintf(bufr, "*** Date/time on this host: %s", Ctime(&thetime));
	   printchatline(bufr);
	}	   
        else if (!ci_strncmp(cmd,"cloak", cmdlen)) {
#ifdef PERMS
           if (HAS_PERM(PERM_CHATCLOAK) && HAS_PERM(PERM_CLOAK)) {
#else
           if (currentuser.userlevel>=CLOAK) {
#endif
             x_cloak() ;
             if (!uinfo.invisible)
               printchatline("*** Cloak has been deactivated") ;
             else
               printchatline("*** Cloak has been activated");
           }
           else
             printchatline("** ERROR: unknown special chat command") ;
	}
	else printchatline("** ERROR: unknown special chat command");
	return retval;
}

ent_chat1()
{
	int savecloak = uinfo.invisible;
#ifdef PERMS
	if (!HAS_PERM(PERM_CHATCLOAK))
#else
	if (currentuser.userlevel < 255)
#endif
		uinfo.invisible = NA;
	chatroom = 1;
	t_chat();
#ifdef PERMS
	if (!HAS_PERM(PERM_CHATCLOAK))
#else
	if (currentuser.userlevel < 255)
#endif
 		uinfo.invisible = savecloak;
}

ent_chat2()
{
	int savecloak = uinfo.invisible;
#ifdef PERMS
	if (!HAS_PERM(PERM_CHATCLOAK))
#else
	if (currentuser.userlevel < 255)
#endif
		uinfo.invisible = NA;
	chatroom = 2;
	t_chat();
#ifdef PERMS
	if (!HAS_PERM(PERM_CHATCLOAK))
#else
	if (currentuser.userlevel < 255)
#endif
 		uinfo.invisible = savecloak;
}

#ifdef CHAT3_CLOAKED
ent_chat3()
{
	int savecloak = uinfo.invisible;
        uinfo.invisible = YEA;
	chatroom = 3;
	t_chat();
	uinfo.invisible = savecloak;
}
#else
ent_chat3()
{
	int savecloak = uinfo.invisible;
#ifdef PERMS
	if (!HAS_PERM(PERM_CHATCLOAK))
#else
	if (currentuser.userlevel < 255)
#endif
		uinfo.invisible = NA;
	chatroom = 3;
	t_chat();
#ifdef PERMS
	if (!HAS_PERM(PERM_CHATCLOAK))
#else
	if (currentuser.userlevel < 255)
#endif
 		uinfo.invisible = savecloak;
}
#endif /* CHAT3_CLOAKED */

#ifdef CHAT4_CLOAKED
ent_chat4()
{
	int savecloak = uinfo.invisible;
	uinfo.invisible = YEA;
	chatroom = 4;
	t_chat();
	uinfo.invisible = savecloak;
}
#else
ent_chat4()
{
	int savecloak = uinfo.invisible;
#ifdef PERMS
	if (!HAS_PERM(PERM_CHATCLOAK))
#else
	if (currentuser.userlevel < 255)
#endif
		uinfo.invisible = NA;
	chatroom = 4;
	t_chat();
#ifdef PERMS
	if (!HAS_PERM(PERM_CHATCLOAK))
#else
	if (currentuser.userlevel < 255)
#endif
 		uinfo.invisible = savecloak;
}
#endif /* CHAT4_CLOAKED */

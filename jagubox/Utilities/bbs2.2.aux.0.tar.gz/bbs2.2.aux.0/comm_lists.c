/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"

int Select(),Boards(),Post(),Users(),Goodbye(),Read() ;
int Help(), New(), Mail(), Talk(), Xyz(), ztest()  ;
int Zap(), Maintenance(), Visit(), Info(), CountBoards(), Welcome();
#ifdef FILES
int Files();
#endif

struct commands cmdlist[] = {
	"Select",	    Select,        0,  "Read",       "Select",
	"Boards",     	Boards,        0,  "Select",     "Boards",
	"Count",	CountBoards,   0,  "Select",     "Count",
	"Post",         Post,          PERM_POST,  "Read",       "Post",
	"Users",        Users,         PERM_BASIC,  "Talk",       "Users",
	"Goodbye",      Goodbye,       0,  "Goodbye",    "Goodbye",
	"Read",         Read,          0,  "Read",       "Select",
	"Help",         Help,          0,  "Select",     "Help",
	"New",          New,           PERM_BASIC,  "Select",     "Select",
	"Mail",         Mail,          0,  "Talk",        "Mail",
#ifdef FILES
	"Files",        Files,         PERM_BASIC,  "Files",      "Files",   
#endif
	"Talk",         Talk,          0,  "Talk",       "Talk",
	"Xyz",          Xyz,           0,  "Xyz",        "Xyz",
	"Admin",        Maintenance,  PERM_ADMINMENU,  "Admin",      "Admin",
	"Visit",        Visit,        PERM_BASIC,  "Visit",      "Visit",
	"Info",         Info,          0,  "Info",       "Info",
	"Zap",          Zap,           PERM_BASIC,  "Zap",        "Zap", 
	"Welcome",      Welcome,       0,  "Welcome",    "Welcome",
	NULL,           NULL,          0,  NULL,         NULL   } ;

int d_board(),d_user(),d_exit() ;

int m_send(), m_new(), m_read(), m_help() ;

struct commands maillist[] = {
	"Send",    m_send,      PERM_SENDMAIL,    "Send",        "Exit",
	"New",     m_new,       PERM_READMAIL,    "Exit",        "Exit",
	"Read",    m_read,      PERM_READMAIL,    "Exit",        "Exit",
	"Exit",    d_exit,      0,    "Exit",        "Exit",
	"Help",    m_help,      0,    "Help",        "Help",
	NULL,      NULL,        0,    NULL,          NULL   } ;

#ifdef FILES
int f_list(), f_download(), f_upload(), f_help(), f_protocol(), f_select() ;
int f_text() ;

struct commands filelist[] = {
	"Select",  f_select,    0,    "List",        "Exit",
	"List",    f_list,      0,    "Download",    "Select",
	"Protocol",f_protocol,  0,    "Download",    "Select",
	"Download",f_download,  0,    "Download",    "Select",
	"Upload",  f_upload,    PERM_UPLOAD,    "Exit",        "Select",
	"Text",    f_text,      0,    "List",        "Select",
	"Help",    f_help,      0,    "List",        "Exit",
	"Exit",    d_exit,      0,    "Exit",        "Exit",
	NULL,       NULL,       0,    NULL,          NULL   } ;
#endif

int x_passwd(), x_terminal(), x_level(), x_help(), x_name(),x_csh(), x_cloak()  ;
#ifdef REALINFO
int x_info();
#endif
#ifdef VOTE
int x_vote(), x_results();
#endif
int Conditions(), x_editsig(), x_editplan(), EditWelcome(), x_date(), t_users();
#ifdef INTERNET_EMAIL
int x_setemail();
#endif
#ifdef BBSDOORS
int ent_bnet();
#endif
#ifdef MMMM
int x_edit4mrc();
#endif

struct commands xyzlist[] = {
	"Cloak",   x_cloak,    PERM_CLOAK,    "Exit",       "Exit",
	"Passwd",  x_passwd,    PERM_BASIC,    "Passwd",      "Exit",
	"Name",    x_name,      PERM_BASIC,    "Users",      "Exit",
#ifdef INTERNET_EMAIL
	"Address", x_setemail,  PERM_SETADDR,    "Exit",       "Exit",
#endif
	"Users",   t_users,     PERM_BASIC,    "Users",        "Exit",
	"Terminal",x_terminal,  0,    "Terminal",    "Exit",
#ifdef REALINFO
	"Info", x_info,		PERM_BASIC,    "Exit",	     "Exit",
#endif
#ifdef VOTE
	"Vote", x_vote,        PERM_VOTE,    "Exit",      "Exit",
	"Results", x_results,  PERM_VOTE,    "Exit",      "Exit",
#endif
#ifdef BBSDOORS
	"BBSNet",  ent_bnet,    PERM_BASIC,     "BBSNet",       "Exit",
#endif
        "Welcome", EditWelcome, PERM_WELCOME,  "Exit",      "Exit",
	"Signature", x_editsig, PERM_BASIC,     "Exit",       "Exit",
	"QueryEdit", x_editplan, PERM_BASIC,    "Exit",       "Exit",
#ifdef MMMM
	"4m RC", x_edit4mrc,     PERM_CHAT,  "Exit",  "Exit",
#endif
	"Date", x_date, 	0,     "Exit", 	     "Exit",
	"Help",    x_help,      0,    "Help",        "Exit",
	"Gnu General Public License", Conditions, 0, "G", "G",
	"Exit",    d_exit,      0,    "Help",        "Exit",
	NULL,       NULL,       0,    NULL,          NULL   } ;


int t_help(), t_list(), t_monitor(), t_talk(), t_query(), t_override();
#ifdef IRC
int t_irc();
#endif
int ent_chat4(), ent_chat1(), ent_chat2(), ent_chat3(), kick_user(), t_pager();
#ifdef REALINFO
int t_rusers();
#endif
#ifdef MMMM
int t_4m();
#endif

struct commands talklist[] = {
	"Users",   t_users,     0,    "Users",       "Exit",
#ifdef REALINFO
	"Realname",t_rusers,   PERM_BASIC,   "Users",       "Exit",
#endif
 	"List",	   t_list,      0,    "List",        "Exit",
	"Monitor", t_monitor, PERM_BASIC,    "Monitor",     "Exit", 
	"Query",   t_query,     0,    "Query",       "Exit",
	"Talk",    t_talk,      PERM_PAGE,    "Talk",        "Exit",       
	"Pager",   t_pager,     PERM_BASIC,     "Users",       "Exit",
	"Override",t_override,  PERM_BASIC,    "Users",       "Exit",
	"Cloak",   x_cloak,     PERM_CLOAK,    "Users",        "Exit",
	"1Chat",   ent_chat1,      PERM_CHAT,    "1Chat",       "Exit",
	"2Chat",   ent_chat2,     PERM_CHAT,    "2Chat",       "Exit", 
	"3Chat",   ent_chat3,     PERM_CHAT,   "3Chat",       "Exit", 
	"4Chat",   ent_chat4,   PERM_SEECLOAK,    "4Chat",       "Exit", 
#ifdef IRC
	"IRC",	   t_irc,	PERM_CHAT,	"IRC",		"Exit",
#endif
#ifdef MMMM
	"Four M",  t_4m,        PERM_CHAT,      "Four M",      "Exit",
#endif
	"Date",    x_date,      0,    "Query",       "Exit",
	"Help",    t_help,      0,    "Help",        "Exit",
	"Kick",	   kick_user,   PERM_SYSOP,  "Users",       "Exit",
	"Exit",    d_exit,      0,    "Help",        "Exit",
	NULL,      NULL,        0,    NULL,           NULL,   } ;

int m_uclean(), m_fclean(), m_adduser(), m_tclean(), a_help(), m_info() ;
int m_editbrd(), m_trace(), Create(), m_mclean(), m_xempt();
#ifdef VOTE
int m_vote();
#endif

struct commands maintlist[] = {
	"User Clean",  m_uclean, PERM_UCLEAN, "User Clean",   "Exit",
	"Xempt",       m_xempt,  PERM_UCLEAN, "Xempt",    "Exit",
	"Level",       x_level,  PERM_SYSOP, "Level" ,       "Exit",
	"Shell",       x_csh,    PERM_SYSOP, "Exit" ,        "Exit",
	"Info",        m_info,   PERM_ACCOUNTS, "Info",         "Info",
	"Add User",     m_adduser, PERM_ACCOUNTS, "Add User",	"Exit",
	"Delete User", d_user,   PERM_ACCOUNTS, "Delete",       "Exit",
	"Mail Clean",  m_mclean, PERM_SYSOP, "Exit",         "Exit",
	"New Board", 	Create,   PERM_BOARDS,  "Exit",       "Exit",
	"Board Delete",d_board,   PERM_BOARDS, "Board",        "Exit",
	"Change Board",m_editbrd,  PERM_BOARDS, "Change Board", "Exit", 
	"Trace",       m_trace,   PERM_SYSOP, "Trace",       "Exit",
#ifdef VOTE
	"Vote",	       m_vote,    PERM_OVOTE, "Exit",        "Exit",
#endif
	"Help",        a_help,     0, "Help",         "Exit",
	"Exit",        d_exit,     0, "Exit",         "Exit",
	NULL,          NULL,       0,  NULL,          NULL,    } ;


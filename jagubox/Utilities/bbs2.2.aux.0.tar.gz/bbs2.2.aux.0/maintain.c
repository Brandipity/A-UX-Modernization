/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifdef AUX
#include <sys/file.h>
#endif

#include "bbs.h"

extern char *genpasswd();

time_t cut_time ;

do_user_check(uptr)
struct userec *uptr ;
{
	if(*(uptr->userid) == '\0')
	  return ;
	if((cut_time > uptr->lastlogin) && !(uptr->flags[0] & NOCLEAN_FLAG))
	  AddNameList(uptr->userid) ;
}

d_u_list(s)
char *s ;
{
	int id ;
	extern int delusernum ;
	extern int duentbds() ;

	if(*s == '*')
	  return ;
	if(!(id = getuser(s)))
	  return ;
	delusernum = id ;
	if (!isalpha(lookupuser.userid[0])) return -1; /* rrr - precaution! */
	sprintf(genbuf,"/bin/rm -fr mail/%s",lookupuser.userid) ;
	system(genbuf) ;
	lookupuser.userid[0] = '\0' ;
	substitute_record(PASSFILE, &lookupuser,sizeof(lookupuser),id) ;
	apply_boards(duentbds) ;
	prints(".") ;
	refresh() ;
}

m_uclean()
{
    int daysold ;
    char buf[STRLEN], *killsp() ;
    
    getdata(1,0,"Enter Inactive Age (30 days default):",buf,5,DOECHO,NULL) ;
    if(isdigit(*killsp(buf)))
      daysold = atoi(killsp(buf)) ;
    else
      daysold = 30 ;
        cut_time = time(NULL) ;
	cut_time -= (daysold * 24 * 60 * 60) ;
	CreateNameList() ;
	AddNameList("*") ;
	if(apply_record(PASSFILE, do_user_check, sizeof(struct userec))==-1)
	  return 0 ;
	move(2,0) ;
	namecomplete("Delete Inactive User (* is All): ",genbuf) ;
	if(*genbuf == '*') {
		move(2,0) ;
		prints("Delete ALL inactive Users?  ") ;
	        getdata(3,0,"(Yes, or No) [N]: ",genbuf,4,DOECHO,NULL) ;
		if(*genbuf != 'y' && *genbuf != 'Y') {
			move(2,0) ;
			prints("Delete Inactive Users Aborted\n") ;
			pressreturn() ;
			clr() ;
			return 0 ;
		}
		move(3,0) ;
/*		ApplyToNameList(d_u_list) ;*/
		report("deleted ALL inactive users");
	        fastdelete() ;
	} else if(*genbuf != '\0') {
		char tbuf[10], buf[64];
		move(2,0) ;
		prints("Delete inactive user '%s'?  ",genbuf) ;
		Getyn(tbuf) ;
		if(tbuf[0] != 'y' && tbuf[0] != 'Y') {
			move(2,0) ;
			prints("Delete Inactive Users Aborted\n") ;
			pressreturn() ;
			clr() ;
			return 0 ;
		}
		d_u_list(genbuf) ;
		sprintf(buf, "deleted user %s", genbuf);
		report(buf);
	}
	clr() ;
	return 0 ;
}
		

m_xempt()
{
    int id;
    u_namelist();
    clr();
    standout();
    prints("Exempt/Unexempt User from User Cleans");
    standend();
    move(1,0);
    namecomplete("Enter userid to be exempted/unexempted: ", genbuf);
    if (*genbuf == '\0') {
	clr();
	return 0;
    }
    move(3,0);
    if (!(id = getuser(genbuf))) {
       prints("Invalid User ID");
       clrtoeol();
       pressreturn();
       return 0;
    }
    if (lookupuser.flags[0] & NOCLEAN_FLAG) {
	lookupuser.flags[0] &= ~NOCLEAN_FLAG;
	prints("User '%s' is no longer exempt from User Clean.",
 	    lookupuser.userid);
	sprintf(genbuf, "exempt %s", lookupuser.userid);
    }
    else {
	lookupuser.flags[0] |= NOCLEAN_FLAG;
	prints("User '%s' is now exempt from User Clean", lookupuser.userid);
	sprintf(genbuf, "unexempt %s", lookupuser.userid);
    }
    report(genbuf);
    substitute_record(PASSFILE, &lookupuser, sizeof(lookupuser), id);
    clrtoeol();
    pressreturn();
    clr();
    return 0;
}

m_info()
{
    int id ;
    struct userec changes ;
    struct userec initial ;

    u_namelist() ;
    clr() ;
    standout() ;
    prints("Get and Change User Info") ;
    standend() ;
    move(1,0) ;
    namecomplete("Enter userid to be accessed: ", genbuf) ;
    if(*genbuf == '\0') {
        clr() ;
        return 0 ;
    }
    if(!(id = getuser(genbuf))) {
        move(3,0) ;
        prints("Invalid User Id") ;
        clrtoeol() ;
        pressreturn() ;
        clr() ;
        return 0 ;
    }
    bcopy(&lookupuser,&changes, sizeof(changes)) ;
    bcopy(&lookupuser,&initial, sizeof(initial)) ;
    user_display(&initial) ;
    getdata(11,0,"Change User Info?  (Yes or No) [N]: ",genbuf,4,DOECHO,NULL) ;
    if(*genbuf == 'y' || *genbuf == 'Y') {
        move(12,0) ;
        prints("Press <Return> to ignore field\n") ;
/*        user_display(&initial) ;*/
      enteruid:
        getdata(13,0,"User ID:    ",genbuf,IDLEN,DOECHO,NULL) ;
        if(*genbuf != '\0') {
            if(getuser(genbuf)) {
                move(3,0) ;
                prints("Error!  User id already exists\n") ;
                bell() ;
                move(13,0) ;
                clrtobot() ;
                goto enteruid ;
            }
            strncpy(changes.userid, genbuf,IDLEN+2) ;
        }
      dopasswd:
        getdata(14,0,"Passwd:     ",genbuf,20,NOECHO,NULL) ;
        if(genbuf[0] != '\0') {
            char temp[20] ;
            getdata(15,0,"ReEnter Passwd: ",temp,20,NOECHO,NULL) ;
            if(strcmp(temp,genbuf)) {
                move(3,0) ;
                prints("Error!  Passwds don't match\n") ;
                move(14,0) ;
                clrtobot() ;
                goto dopasswd ;
            }
            strncpy(changes.passwd,genpasswd(genbuf),PASSLEN) ;
        }
        getdata(15,0,"User Name:  ",genbuf,STRLEN,DOECHO,NULL) ;
        if(*genbuf != '\0')
          strncpy(changes.username, genbuf, STRLEN) ;
        getdata(16,0,"Term Type:  ",genbuf,STRLEN,DOECHO,NULL) ;
        if(*genbuf != '\0')
          strncpy(changes.termtype, genbuf, STRLEN) ;
#ifndef PERMS
       if (currentuser.userlevel==255) {
       getdata(17,0,"User Level: ",genbuf,5,DOECHO,NULL) ;
        if(*genbuf != '\0')
          changes.userlevel = atoi(genbuf) ;}
#endif
#ifdef REALINFO
        getdata(17,0,"Real Name:  ",genbuf,STRLEN-40,DOECHO,NULL) ;
        if(*genbuf != '\0')
          strncpy(changes.realname, genbuf, STRLEN-40) ;
        getdata(18,0,"Address:    ",genbuf,STRLEN,DOECHO,NULL) ;
        if(*genbuf != '\0')
          strncpy(changes.address, genbuf, STRLEN) ;
        getdata(19,0,"E-mail:     ",genbuf,STRLEN,DOECHO,NULL) ;
        if(*genbuf != '\0')
          strncpy(changes.email, genbuf, STRLEN) ;
        getdata(20,0,"Apply these changes?  (Yes or No) [N]: ",
#else
        getdata(17,0,"E-mail:     ",genbuf,STRLEN,DOECHO,NULL) ;
        if(*genbuf != '\0')
          strncpy(changes.email, genbuf, STRLEN) ;
        getdata(20,0,"Apply these changes?  (Yes or No) [N]: ",  
#endif
                genbuf,4,DOECHO,NULL) ;
        if(*genbuf == 'y' || *genbuf == 'Y') {
            if(strcmp(changes.userid, initial.userid)) {
                char from[512], to[512] ;
                
                sprintf(from,"mail/%s",initial.userid) ;
                sprintf(to,"mail/%s",changes.userid) ;
                rename(from,to) ;
                sprintf(from,"plans/%s",initial.userid) ;
                sprintf(to,"plans/%s",changes.userid) ;
                rename(from,to) ;
                sprintf(from,"signatures/%s",initial.userid) ;
                sprintf(to,"signatures/%s",changes.userid) ;
                rename(from,to) ;
                sprintf(from,"overrides/%s",initial.userid) ;
                sprintf(to,"overrides/%s",changes.userid) ;
                rename(from,to) ;
            }
            substitute_record(PASSFILE, &changes, sizeof(changes), id) ;
	    sprintf(genbuf, "modified %s user info --> %s", 
			initial.userid, changes.userid);
	    report(genbuf);
        }
    }
    clr();
    return 0 ;
}

extern int cmpbnames();
extern int numboards;

m_editbrd()
{
	char bname[STRLEN];
	char bpath[STRLEN*2];
	struct stat statb;
	int pos;
	struct fileheader fh, newfh;
	make_blist();
	clr();
	standout();
	prints("Change Board Info");
	standend();
	move(1,0);
	namecomplete("Enter board name: ", bname);
	if (*bname == '\0') {
	    move(2,0);
	    prints("Invalid Board Name");
	    pressreturn();
	    clr();
	    return;
	}
	pos = search_record(BOARDS, &fh, sizeof(fh), cmpbnames, (int)bname);
	if (!pos) {
	    move(2,0);
	    prints("Invalid Board Name");
	    pressreturn();
	    clr();
	    return;
	}
	move(3,0);
	bcopy(&fh, &newfh, sizeof(newfh));
	prints("Board Name:        %s\n", fh.filename);
	prints("Board Description: %s\n", fh.title);
#ifdef PERMS
	if (fh.level & PERM_POSTMASK)
	  prints("POST Access Level: %s\n", (fh.level & ~PERM_POSTMASK) == 0 ? "Unrestricted" : "Restricted");
	else prints("READ Access Level: %s\n", fh.level == 0 ? "Unrestricted" : "Restricted");
#else
	prints("Level to access:   %d\n", fh.level);
#endif
	getdata(7,0, "Change Board Info? (Yes or No) [N]: ", genbuf, 4, DOECHO, NULL);
	if (*genbuf == 'y' || *genbuf == 'Y') {
	    move(9,0);
	    prints("Press <Return> to ignore field\n");
	  enterbname:
	    getdata(10,0, "New Board Name:         ", genbuf, 18, DOECHO, NULL);
	    if (*genbuf != 0) {
		struct fileheader dh;
		sprintf(bpath, "boards/%s", genbuf);
		if (search_record(BOARDS,&dh,sizeof(dh),cmpbnames,(int)genbuf)){
		    move(3,0);
		    prints("Error! Board already exists\n");
		    bell();
		    move(10,0);
		    clrtobot();
		    goto enterbname;
		}
		strncpy(newfh.filename, genbuf, sizeof(newfh.filename));
	    }
	    getdata(11,0, "New Board Description:  ", genbuf, 60, DOECHO, NULL);
	    if (*genbuf != 0)
		strncpy(newfh.title, genbuf, sizeof(newfh.title));
#ifdef PERMS
	    getdata(12,0, "Change Access Level (Y/N)? [N]: ", genbuf, 4, DOECHO, NULL);
	    if (*genbuf == 'Y' || *genbuf == 'y') {
		char ans[4];
		sprintf(genbuf, "Restrict (R)eading or (P)osting [%c]: ",
			(newfh.level & PERM_POSTMASK ? 'P' : 'R'));
		getdata(13,0, genbuf, ans, 4, DOECHO, NULL);
		if ((newfh.level & PERM_POSTMASK) && (*ans=='R' || *ans=='r'))
		    newfh.level &= ~PERM_POSTMASK;
		else if (!(newfh.level & PERM_POSTMASK) && (*ans=='P'||*ans=='p'))
		    newfh.level |= PERM_POSTMASK;
		move(1,0);
		clrtobot();
		move(2,0);
		prints("Set the desired %s permissions for board '%s'\n", newfh.level & PERM_POSTMASK ? "POST" : "READ", newfh.filename);
		newfh.level = setperms(newfh.level);
		clr();
	        getdata(0,0, "Apply these changes? (Yes or No) [N]: ", genbuf, 4, DOECHO, NULL);
	    }
	    else getdata(13,0, "Apply these changes? (Yes or No) [N]: ", genbuf, 4, DOECHO, NULL);
#else
	    getdata(12,0, "New Access Level:       ", genbuf, 4, DOECHO, NULL);
	    if (*genbuf != 0)
		newfh.level = atoi(genbuf);
	    getdata(13,0, "Apply these changes? (Yes or No) [N]: ", genbuf, 4, DOECHO, NULL);
#endif
	    if (*genbuf == 'Y' || *genbuf == 'y') {
		if (strcmp(fh.filename, newfh.filename)) {
		    char from[256], to[256];
		    sprintf(from, "boards/%s", fh.filename);
		    sprintf(to, "boards/%s", newfh.filename);
		    rename(from, to);
		}
		substitute_record(BOARDS, &newfh, sizeof(newfh), pos);
		sprintf(genbuf, "changed %s board info --> %s",
			fh.filename, newfh.filename);
		report(genbuf);
		numboards = -1;    /* force re-caching */
	    }
	}
	clr();
	return 0;
}

user_display(u)
struct userec *u ;
{
    move(4,0) ;
    prints("User Id:      %s\n", u->userid) ;
    prints("User Name:    %s\n", u->username) ;
    prints("Term Type:    %s\n", u->termtype) ;
#ifndef PERMS
    if (currentuser.userlevel > 0) prints("Level:        %d\n", u->userlevel) ;
#endif
#ifdef REALINFO
    prints("Real Name:    %s\n", u->realname);
    prints("Address:      %s\n", u->address);
    prints("E-mail:       %s\n", u->email);
#endif
}

FILE *cleanlog;
char curruser[IDLEN+2];
extern int delmsgs[];
extern int delcnt;

domailclean(fhdrp)
struct fileheader *fhdrp;
{
	static int newcnt, savecnt, deleted, idc;
	char buf[STRLEN];
	if (fhdrp == NULL) {
	    fprintf(cleanlog, "new = %d, saved = %d, deleted = %d\n",
		    newcnt, savecnt, deleted);	
	    newcnt = savecnt = deleted = idc = 0;
	    if (delcnt) {
	       sprintf(buf, "mail/%s%s", curruser, DIR);
	       while (delcnt--)
	           delete_record(buf, sizeof(struct fileheader), delmsgs[delcnt]);
	    }
	    delcnt = 0;	    
	    return;
	}
	idc++;
	if (!(fhdrp->accessed[0] & FILE_READ))
	    newcnt++;
	else if (fhdrp->accessed[0] & FILE_MARKED)
	    savecnt++;
	else {
	    deleted++;
	    sprintf(buf, "mail/%s/%s", curruser, fhdrp->filename);
	    unlink(buf);
	    delmsgs[delcnt++] = idc;
	}
	return;
}

cleanmail(urec)
struct userec *urec;
{
	struct stat statb;
	if (urec->userid[0] == '\0' || !strcmp(urec->userid, "new"))
	    return;
	sprintf(genbuf, "mail/%s%s", urec->userid, DIR);
	fprintf(cleanlog, "%s: ", urec->userid);
	if (stat(genbuf, &statb) == -1)
	    fprintf(cleanlog, "no mail\n");
	else if (statb.st_size == 0)
	    fprintf(cleanlog, "no mail\n");
	else {
	    strcpy(curruser, urec->userid);
	    delcnt = 0;
	    apply_record(genbuf, domailclean, sizeof(struct fileheader));
	    domailclean(NULL);
	}
	return;
}

m_mclean()
{
	char ans[4];
	clr();
	move(0,0);
	standout();
	prints("Clean Mail Folders");
	standend();
	move(1,0);
	prints("This will delete all old and unmarked mail. Also, it's slow.\n");
	getdata(2,0, "Are You Sure (Y/N)? [N]: ", ans, 3, DOECHO, NULL);
	if (ans[0] != 'Y' && ans[0] != 'y') {
	   clr();
	   return;
	}
	cleanlog = fopen("mailclean.log", "w");
        move(3,0);
        prints("Working -- please be patient.\n");
        refresh();
	if (apply_record(PASSFILE, cleanmail, sizeof(struct userec)) == -1) {
	   move(4,0);
	   prints("Error opening PASSFILE, aborting...\n");
	   pressreturn();
	   clr();
	   return;
	}
	move(4,0);
	fclose(cleanlog);
	prints("Done! Log is in mailclean.log.\n");
	report("Mail Clean");
	pressreturn();
	clr();
	return;
}
		
m_trace()
{
	struct stat ostatb, cstatb;
	int otraceoff, ctraceoff, done = 0;
	int fd;
	char ans[2];
	char *msg;
	clr();
	move(0,0);
	standout();
	prints("Set Trace Options");
	standend();
	clrtobot();
	while (!done) {
	    move(2,0);
	    otraceoff = stat("trace", &ostatb);
	    ctraceoff = stat("trace.chatd", &cstatb);
	    prints("Current Trace Settings:\n");
	    if (otraceoff) prints("General tracing is OFF\n");
	    else prints("BBS tracing is ON (file size = %d)\n", ostatb.st_size);
	    if (ctraceoff) prints("Chat daemon tracing is OFF\n");
	    else prints("Chat daemon tracing is ON (file size = %d)\n", cstatb.st_size);
	    move(6,0);
	    prints("Enter:\n");
	    prints("<1> to %s BBS tracing\n", otraceoff ? "enable" : "disable");
	    prints("<2> to %s chat daemon tracing\n", ctraceoff ? "enable" : "disable");
	    getdata(9,0,"Anything else to exit: ",ans,2,DOECHO,NULL);
	    switch (ans[0]) {
	      case '1': if (otraceoff) {
		if (fd = open("trace", O_WRONLY | O_CREAT | O_APPEND, 0600))
                  close(fd);
	        msg = "BBS tracing enabled.";
		report("opened report log");
	      }
	      else {
		report("closed report log");
		rename("trace", "trace.old");
		msg = "BBS tracing disabled; log is in trace.old.";
	      }
	      break;
	      case '2': if (ctraceoff) {
		if (fd = open("trace.chatd",O_WRONLY|O_CREAT|O_APPEND, 0600))
                  close(fd);
	        msg = "Chat daemon tracing enabled.";
		report("chatd trace log opened");
	      }
	      else {
		rename("trace.chatd", "trace.chatd.old");
		msg = "Chat daemon tracing disabled; log is in trace.chatd.old.";
		report("chatd trace log closed");
	      }
	      break;
	      default: msg = NULL;
	        done = 1;
	    }
	    move(t_lines-1, 0);
	    if (msg) prints("%s\n", msg);
	}
	clr();
}

#ifdef VOTE

#ifndef AUX
#include <sys/file.h>
#endif

double atof();
long atol();

clearflags()
{
	int fd;
	struct userec uent;
	if ((fd = open(PASSFILE, O_RDWR)) == -1) {
		prints("WHOA! Can't open the passfile!\n");
		return -1;
	}
	flock(fd, LOCK_EX);
	while (read(fd, &uent, sizeof(uent)) == sizeof(uent)) {
		uent.flags[0] &= ~VOTE_FLAG;   /* clear that sucker */
		lseek(fd, -sizeof(uent), L_INCR);   /* back up */
		if (write(fd, &uent, sizeof(uent)) != sizeof(uent)) break;
	}
	flock(fd, LOCK_UN);
	close(fd);
	return 0;
}

suckinfile(fp, fname)
FILE *fp;
char *fname;
{
	char inbuf[256];
	FILE *sfp;
	if ((sfp = fopen(fname, "r")) == NULL) return -1;
	while (fgets(inbuf, sizeof(inbuf), sfp) != NULL)
	    fputs(inbuf, fp);
	fclose(sfp);
	return 0;
}

closepolls()
{
	FILE *cfp, *tfp;
	char inchar, inbuf[80];
	int bfd, counts[10];
	time_t endtime;
	if ((cfp = fopen("vote/control", "r")) == NULL) {
	    if (currentuser.flags[0] & VOTE_FLAG) {
		currentuser.flags[0] &= ~VOTE_FLAG;
		substitute_record(PASSFILE, &currentuser, sizeof(currentuser), usernum);
	    }
	    return 0;
	}
	if (fgets(inbuf, sizeof(inbuf), cfp) == NULL) {
	    fclose(cfp);
	    return;
	}
	fclose(cfp);
	endtime = (time_t)atol(inbuf);
	if (endtime > time(0) || endtime <= 0) return 0;
	if (rename("vote/control", "vote/temp") == -1) return 0;
	report("closed the polls");
	for (bfd = 0; bfd < 10; bfd++) counts[bfd] = 0;
	if ((bfd = open("vote/ballots", O_RDONLY)) != -1) {
	    while (read(bfd, &inchar, 1) == 1) 
		counts[(int)(inchar - '0')]++;
	    close(bfd);
	}
	if (tfp = fopen("vote/newresults", "w")) {
	    int totvotes = 0;
	    fprintf(tfp, "-------------------------------------------------------------------------\n\n");
	    fprintf(tfp, "** Polls closed: %s\n", ctime(&endtime));
	    fprintf(tfp, "** Synopsis of ballot issue:\n\n");
	    suckinfile(tfp, "vote/desc");
	    fprintf(tfp, "** Results:\n\n");
	    if (cfp = fopen("vote/temp", "r")) {
		int cindex;
		fgets(inbuf, sizeof(inbuf), cfp);
		while (fgets(inbuf, sizeof(inbuf), cfp)) {
		    inbuf[(strlen(inbuf)-1)] = '\0';
		    inbuf[23] = '\0'; /* truncate */
		    cindex = inbuf[0] - '0';		    
		    fprintf(tfp, "    %-20s  %3d\n", inbuf+3, counts[cindex]);
		    totvotes += counts[cindex];
		}
		fclose(cfp);
	    }
	    fprintf(tfp, "\nTotal votes cast = %d\n\n", totvotes);
	    suckinfile(tfp, "vote/results");
	    fclose(tfp);
	}
	else return -1; /* couldn't write out the results! */
	unlink("vote/results");
	rename("vote/newresults", "vote/results");
	unlink("vote/desc");
	unlink("vote/temp");
	unlink("vote/ballots");
	clearflags();
	currentuser.flags[0] &= ~VOTE_FLAG;
	return 0;
}


m_vote()
{
	struct stat statb;
	FILE *fp;
	char inbuf[80];
	char *newline;
	int numselections = 0, aborted;
	time_t closetime, numseconds;
	clr();
	move(0,0);
	standout();
	prints("Open The Polls");
	standend();
	move(2,0);
	if ((fp = fopen("vote/control", "r")) != NULL) {
	   fgets(inbuf, sizeof(inbuf), fp);
	   fclose(fp);
	   if (newline = index(inbuf, '\n')) *newline = '\0';
	   closetime = atof(inbuf);
	   prints("Sorry, the polls are already open.\n");
	   prints("They are scheduled to close at: %s", ctime(&closetime));
	   prints("Force earlier close by editing 'vote/control'.");
	   pressreturn();
	   clr();
	   return;
	}
	prints("Press any key to edit the ballot description: \n");
	igetch();
	aborted = vedit("vote/desc", NA);
	if (aborted) {
	   clr();
	   prints("Open polls ABORTED.\n");
	   pressreturn();
	   clr();
	   return;
	}
	fp = fopen("vote/control", "w");
	clr();
	getdata(0,0,"Number of days to keep polls open: ",inbuf,4,DOECHO, NULL);
	numseconds = atof(inbuf) * 86400.0;
	time(&closetime);
	closetime += numseconds;
	fprintf(fp, "%lu\n", closetime);
	fflush(fp);
	while (!aborted) {
	   getdata(numselections+1,0,"Enter selection (RETURN if done): ",
		inbuf, 40, DOECHO, NULL);
	   if (*inbuf) {	   
	      if (numselections == 9) numselections = 0;
	      else numselections++;
	      fprintf(fp, "%1d) %s\n", numselections, inbuf);
	   }
	   if (*inbuf == '\0' || numselections == 0)
	      aborted = 1;
	}
	fclose(fp);
	clearflags();
	report("opened the polls");
	prints("The polls are open!\n");
	pressreturn();
	clr();
	return;
}
		   
#endif /* VOTE */

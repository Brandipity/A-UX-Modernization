/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"
#ifdef AUX
#include <time.h>
#endif

#ifndef AUX
#include <sys/time.h>
#endif

char currmaildir[4096] ;

m_init()
{
	sprintf(currmaildir,"mail/%s/%s",currentuser.userid,DIR) ;
}

do_send(userid,title)
char *userid, *title ;
{
	struct fileheader newmessage ;
	char fname[4096] ;
	char *ip ;
	struct stat st ;
	int fp ;

	if(!getuser(userid))
	  return -1 ;
#ifdef PERMS
	if (!(lookupuser.userlevel & PERM_READMAIL))
	  return -3;
#endif
	sprintf(genbuf,"mail/%s",userid) ;
	if(stat(genbuf,&st) == -1) {
		if(mkdir(genbuf,0755) == -1) 
		  return -1 ;
	} else {	
		if(!(st.st_mode & S_IFDIR))
		  return -1 ;
	}
	bzero(&newmessage,sizeof(newmessage)) ;
	sprintf(fname,"M.%d.A",time(0)) ;
	sprintf(genbuf,"mail/%s/%s",userid,fname) ;
	ip = rindex(fname,'A') ;
	while((fp = open(genbuf,O_CREAT|O_EXCL|O_WRONLY,0644)) == -1) {
		if(*ip == 'Z')
		  ip++,*ip = 'A', *(ip + 1) = '\0' ;
		else
		  (*ip)++ ;
		sprintf(genbuf,"mail/%s/%s",userid,fname) ;
	}
	close(fp) ;
	strcpy(newmessage.filename,fname) ;
	if(!title)
	  getdata(2,0,"Title: ",newmessage.title,STRLEN,DOECHO,NULL) ;
	else 
	  strncpy(newmessage.title,title,STRLEN) ;
	strncpy(save_title,newmessage.title,STRLEN) ;
	strncpy(save_filename,fname,4096) ;
	in_mail = YEA ;
#if defined(REALINFO) && defined(MAIL_REALNAMES)
	sprintf(genbuf,"%s (%s)",currentuser.userid,currentuser.realname) ;
#else
	sprintf(genbuf,"%s (%s)",currentuser.userid,currentuser.username) ;
#endif
	strncpy(newmessage.owner,genbuf,STRLEN) ;
	sprintf(genbuf,"mail/%s/%s",userid,fname) ;
	if (vedit(genbuf,YEA) == -1) { clr(); return -2; }
	clr() ;
	sprintf(genbuf,"mail/%s/%s",userid,DIR) ;
	if(append_record(genbuf,&newmessage,sizeof(newmessage)) == -1)
	  return -1 ;
	sprintf(genbuf, "mailed %s", userid);
	report(genbuf);
	return 0 ;
}

m_send()
{
	char uident[STRLEN] ;

#ifdef SEABASS
	if (!HAS_PERM(PERM_BASIC)) {
	    CreateNameList();
	    if (!strcmp(currentuser.userid, "advice"))
	      AddNameList("Gabby");
	    else {
              AddNameList("ACCOUNT");
	      AddNameList("SYSOP");
	    }
	}
	else
#endif /* SEABASS */

	u_namelist() ;

	move(2,0) ;
	prints("<Enter Userid>\n") ;
	move(1,0) ;
	clrtoeol() ;
	namecomplete("To: ",uident) ;
	if(uident[0] == '\0') {
		clr() ;
		return 0 ;
	}
	uinfo.mode = SMAIL;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	switch (do_send(uident,NULL)) {
	  case -1: prints("Bad UserId\n") ; break;
	  case -2: prints("Mail Aborted\n"); break;
#ifdef PERMS
	  case -3: prints("User '%s' cannot receive mail\n", uident); break;
#endif
	  default: prints("File Sent\n") ;
	}
	pressreturn() ;
	uinfo.mode = MAIL;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	return 0 ;
}


read_mail(fptr)
struct fileheader *fptr ;
{
	sprintf(genbuf,"mail/%s/%s",currentuser.userid,fptr->filename) ;
	more(genbuf,NA) ;
	fptr->accessed[0] |= FILE_READ;
	return 0 ;
}

int mrd ;

int delmsgs[1024] ;
int delcnt ;

read_new_mail(fptr)
struct fileheader *fptr ;
{
	static int idc ;
	char ans[7], done = NA, delete_it;
	char fname[256];

	if(fptr == NULL) {
		delcnt = 0 ;
		idc = 0 ;
		return 0;
	}
	idc++ ;
	if(fptr->accessed[0])
	  return 0 ;
	prints("Read message titled '%s' from: %s?\n",fptr->title,fptr->owner) ;
	prints("(Yes, or No): ") ;
	getdata(1,0,"(Yes, or No) [Y]: ",genbuf,4,DOECHO,NULL) ;
	if(genbuf[0] != 'y' && genbuf[0] != 'Y' && genbuf[0] != '\0') {
		clr() ;
		return 0 ;
	}
	read_mail(fptr) ;
	strcpy(fname, genbuf);
	mrd = 1 ;
	if(substitute_record(currmaildir,fptr,sizeof(*fptr),idc))
	  return -1 ;
	delete_it = NA;
    while (!done) {
	getdata(t_lines-1,0,"(R)eply, (D)elete, or (G)o on? [G]: ",ans,7,DOECHO,NULL);
	switch (ans[0]) {
	    case 'R': case 'r': 
	      mail_reply(idc, fptr, currmaildir);
	      break;
	    case 'D': case 'd': delete_it = YEA;
	    default: done = YEA;
	}
        if (!done) more(fname, NA);  /* re-read */
    }
    if (delete_it) {
        clr() ;
        prints("Delete Message '%s' ",fptr->title) ;
        Getyn(genbuf) ;
        if(genbuf[0] == 'Y' || genbuf[0] == 'y') { /* if not yes quit */
	  sprintf(genbuf,"mail/%s/%s",currentuser.userid,fptr->filename) ;
	  unlink(genbuf) ;
	  delmsgs[delcnt++] = idc ;
	}
    }
    clr() ;
    return 0 ;
}

m_new()
{
	clr() ;
	mrd = 0 ;
	uinfo.mode = RMAIL; 
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	read_new_mail(NULL) ;
	if(apply_record(currmaildir,read_new_mail,sizeof(struct fileheader)) == -1) {
		clr() ;
		move(0,0) ;
		prints("No new messages\n\n\n") ;
		uinfo.mode = MAIL;
		substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
		return -1 ;
	}
	if(delcnt) {
		while(delcnt--)
 		  delete_record(currmaildir,sizeof(struct fileheader),delmsgs[delcnt]) ;
	}
	clr() ;
	move(0,0) ;
	if(mrd)
	  prints("No more messages.\n\n\n") ;
	else
	  prints("No new messages.\n\n\n") ;
	uinfo.mode = MAIL;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	return -1 ;
}

mailtitle()
{
	prints("Interactive Read Menu                (FOR Mail)\n") ;
	prints("(n)ext Message     (p)revious Message     (r)ead Message     (e)xit Read Menu\n");
	prints("(## <cr>) go to message ##     ($) go to last message     (h) Get Help Screen\n");
	prints(" ENT   %-20s %s\n","From","Header") ;
	clrtobot() ;
}

char *
maildoent(num,ent)
struct fileheader *ent ;
{
	static char buf[512] ;
	char b2[512] ;
	char status;
	char *t ;

	strncpy(b2,ent->owner,STRLEN) ;
	if (t = index(b2,' '))
	  *t = '\0' ;
	if (ent->accessed[0] & FILE_READ) {
	  if (ent->accessed[0] & FILE_MARKED) status = 'm';
	  else status = ' ';
	}
	else {
	  if (ent->accessed[0] & FILE_MARKED) status = 'M';
	  else status = 'N';
	}
	sprintf(buf," %3d %c %-20s %s",num,status,b2,ent->title) ;
	return buf ;
}

#ifdef POSTBUG
extern int bug_possible;
#endif

mail_read(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	char buf[512], notgenbuf[128];
	char *t ;
	char done = NA, ans[7], delete_it, replied;

	clr() ;
	strcpy(buf,direct) ;
	if(t = rindex(buf,'/'))
	  *t = '\0' ;
	sprintf(notgenbuf, "%s/%s",buf,fileinfo->filename) ;
	delete_it = replied = NA;
	while (!done) {
	    more(notgenbuf, NA) ;
	    getdata(t_lines-1,0,"(R)eply, (D)elete, or (G)o on? [G]: ",ans,7,DOECHO,NULL);
	    switch (ans[0]) {
		case 'R': case 'r': 
		  replied = YEA;
		  mail_reply(ent,fileinfo, direct);
		  break;
		case 'D': case 'd': delete_it = YEA;
	        default: done = YEA;
	    }
	} 
	if (delete_it) mail_del(ent, fileinfo, direct);
	else {
	  fileinfo->accessed[0] |= FILE_READ;
#ifdef POSTBUG
	  if (replied) bug_possible = YEA;
#endif
	  substitute_record(currmaildir, fileinfo, sizeof(*fileinfo),ent) ;
#ifdef POSTBUG
	  bug_possible = NA;
#endif
	}
	return FULLUPDATE ;
}

/*ARGSUSED*/
mail_reply(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	char uid[STRLEN] ;
	char title[STRLEN] ;
	char *t ;

	uinfo.mode = SMAIL;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	strncpy(uid,fileinfo->owner,STRLEN) ;
	if(t = index(uid,' '))
	  *t = '\0' ;
	if (toupper(fileinfo->title[0]) != 'R' || fileinfo->title[1] != 'e' ||
	    fileinfo->title[2] != ':') strcpy(title,"Re: ") ;
	else title[0] = '\0';
	strncat(title,fileinfo->title,STRLEN-5) ;
	switch (do_send(uid,title)) {
	  case -1:  prints("Could not send\n") ; break;
	  case -2:  prints("Reply Aborted\n"); break;
#ifdef PERMS
	  case -3:  prints("User '%s' cannot receive mail\n", uid); break;
#endif
	  default: prints("File Sent\n") ;
	}
	pressreturn() ;
	uinfo.mode = RMAIL;
	substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
	return FULLUPDATE ;
}

mail_del(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	char buf[512] ;
	char *t ;
	extern int cmpfilename() ;
	extern char currfile[] ;

	clr() ;
	prints("Delete Message '%s' ",fileinfo->title) ;
	Getyn(genbuf) ;
	if(genbuf[0] != 'Y' && genbuf[0] != 'y') { /* if not yes quit */
		move(2,0) ;
		prints("Quitting Delete Mail\n") ;
		pressreturn() ;
		clr() ;
		return FULLUPDATE ;
	}		
	strcpy(buf,direct) ;
	if (t = rindex(buf,'/'))
	  *t = '\0' ;
	strncpy(currfile,fileinfo->filename,STRLEN) ;
	if(!delete_file(direct,sizeof(*fileinfo),ent,cmpfilename)) {
		sprintf(genbuf,"%s/%s",buf,fileinfo->filename) ;
		unlink(genbuf) ;
		return FULLUPDATE ;
	}
	move(2,0) ;
	prints("Delete failed\n") ;
	pressreturn() ;
	clr() ;
	return FULLUPDATE ;
}

#ifdef INTERNET_EMAIL

mail_forward(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	char buf[STRLEN];
	char *p;
#ifdef PERMS
	if (!HAS_PERM(PERM_FORWARD)) {
	    bell();
	    return DONOTHING;
	}
#endif
	strncpy(buf, direct, sizeof(buf));
	if ((p = rindex(buf, '/')) != NULL)
	    *p = '\0';
	clr();
	switch (doforward(buf, fileinfo)) {
	  case 0: prints("File forwarded to %s.\n", currentuser.email);
		  sprintf(genbuf, "forwarded file to %s", currentuser.email);
		  report(genbuf);
		  break;
	  case -1: prints("Forward failed: system error.\n");
		   break;
	  case -2: prints("Forward failed: missing or invalid address.\n");
	}
	pressreturn();
	clr();
	return FULLUPDATE;
}

#endif

mail_del_range(ent, fileinfo, direct)
int ent;
struct fileheader *fileinfo;
char *direct;
{
    return(del_range(ent, fileinfo, direct));
}

mail_mark(ent,fileinfo,direct)
int ent ;
struct fileheader *fileinfo ;
char *direct ;
{
	if (fileinfo->accessed[0] & FILE_MARKED)
	   fileinfo->accessed[0] &= ~FILE_MARKED;
	else fileinfo->accessed[0] |= FILE_MARKED;
	substitute_record(currmaildir, fileinfo, sizeof(*fileinfo),ent) ;
	return(PARTUPDATE);	
}


extern int mailreadhelp();

struct one_key  mail_comms[] = {
	'd',        mail_del,
	'D',	    mail_del_range,
	'r',        mail_read,
	'R',        mail_reply,
	'm',	    mail_mark,
#ifdef INTERNET_EMAIL
	'F',	    mail_forward,
#endif
	'h',        mailreadhelp,
	CTRL('J'),    mailreadhelp,
	'\0',       NULL
} ;

m_read()
{
    uinfo.mode = RMAIL;   
    substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
    in_mail = YEA;
    i_read(currmaildir,mailtitle,maildoent,&mail_comms[0]) ;
    in_mail = NA;
    uinfo.mode = MAIL;
    substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
    return 0 ;
}

#ifdef INTERNET_EMAIL

#include <netdb.h>
#include <pwd.h>
#define BBSMAILDIR "/users/bbs/usr/spool/mqueue"
extern char BoardName[];

invalidaddr(addr)
char *addr;
{
	if (*addr == '\0') return 1;   /* blank */
	while (*addr) {
	    if (!isalnum(*addr) && index(".%!@:;-_", *addr) == NULL)
		return 1;
	    addr++;
	}
	return 0;
}

spacestozeros(s)
char *s;
{
	while (*s) {
	    if (*s == ' ') *s = '0';
	    s++;
	}
}

getqsuffix(s)
char *s;
{
	struct stat stbuf;
	char qbuf[STRLEN], dbuf[STRLEN];
	char c1 = 'A', c2 = 'A';
	int pos = strlen(BBSMAILDIR) + 3;
	sprintf(dbuf, "%s/dfAA%5d", BBSMAILDIR, getpid());
	sprintf(qbuf, "%s/qfAA%5d", BBSMAILDIR, getpid());
	spacestozeros(dbuf);
	spacestozeros(qbuf);
	while (1) {
	    if (stat(dbuf, &stbuf) && stat(qbuf, &stbuf)) break;
	    if (c2 == 'Z') {
		c2 = 'A';
		if (c1 == 'Z') return -1;
		else c1++;
		dbuf[pos] = c1;
		qbuf[pos] = c1;
	    }
	    else c2++;
	    dbuf[pos+1] = c2;
	    qbuf[pos+1] = c2;	    	    
	}
	strcpy(s, &(qbuf[pos]));
	return 0;
}

convert_tz(local, gmt, buf)
int gmt, local;
char *buf;
{
	local -= gmt;
	if (local < -11) local += 24;
	else if (local > 12) local -= 24;
	sprintf(buf, " %4d", abs(local * 100));
	spacestozeros(buf);
	if (local < 0) buf[0] = '-';
	else if (local > 0) buf[0] = '+';
	else buf[0] = '\0';	
}

createqf(title, qsuffix)
char *title, *qsuffix;
{
	static int configured = 0;
        static char myhostname[STRLEN];
        static char myusername[20];
        char mytime[STRLEN];
        char idtime[STRLEN];
	char qfname[STRLEN];
	char t_offset[6];
	FILE *qfp;
        time_t timenow;
	int savehour;
	struct tm *gtime, *ltime;
        struct hostent *hbuf;
        struct passwd *pbuf;

	if (!configured) {
            /* get host name */
            gethostname(myhostname, STRLEN);
#ifndef LINUX
            hbuf = gethostbyname(myhostname);
            if (hbuf) strncpy(myhostname, hbuf->h_name, STRLEN);
#endif

            /* get bbs uident */
            pbuf = getpwuid(getuid());
            if (pbuf) strncpy(myusername, pbuf->pw_name, 20);
	    if (hbuf && pbuf) configured = 1;
	    else return -1;
	}

	/* get file name */
	sprintf(qfname, "%s/qf%s", BBSMAILDIR, qsuffix);
	if ((qfp = fopen(qfname, "w")) == NULL) return -1;
	
        /* get time */
        time(&timenow);
	ltime = localtime(&timenow);
#if 0
	ascftime(mytime, "%a, %d %b %Y %T ", ltime);
#else
        strftime(mytime, sizeof(mytime), "%a, %d %b %Y %T ", ltime);
#endif
	savehour = ltime->tm_hour;
	gtime = gmtime(&timenow);
        strftime(idtime, sizeof(idtime), "%Y%m%d%y%H%M", gtime); 
	convert_tz(savehour, gtime->tm_hour, t_offset);
	strcat(mytime, t_offset);
        fprintf(qfp, "P1000\nT%lu\nDdf%s\nS%s\nR%s\n", timenow, qsuffix,
                myusername, currentuser.email);
#ifdef ERRORS_TO
	fprintf(qfp, "E%s\n", ERRORS_TO);
#endif
	/* do those headers! */
        fprintf(qfp, "HReceived: by %s (%s)\n\tid %s; %s\n",
                myhostname, VERSION_ID, qsuffix, mytime);
	fprintf(qfp, "HReturn-Path: <%s@%s>\n", myusername, myhostname);
        fprintf(qfp, "HDate: %s\n", mytime);
        fprintf(qfp, "HMessage-Id: <%s.%s@%s>\n", idtime, qsuffix,
                myhostname);
        fprintf(qfp, "HFrom: %s@%s (%s)\n", myusername, myhostname, BoardName);
        fprintf(qfp, "HSubject: %s (fwd)\n", title);
        fprintf(qfp, "HTo: %s\n", currentuser.email);
	fprintf(qfp, "HX-Forwarded-By: %s (%s)\n", currentuser.userid,
#ifdef REALNAME
		currentuser.realname);
#else
		currentuser.username);
#endif
	fprintf(qfp, "HX-Disclaimer: %s is not responsible for the contents of this message.\n", BoardName);
	fclose(qfp);
	return 0;
}

doforward(direct, fh)
char *direct;
struct shortfile *fh;
{
	char dfname[STRLEN];
	char fname[STRLEN];
	char qsuffix[STRLEN];
	if (invalidaddr(currentuser.email)) return -2;
	/* create data file */
	if (getqsuffix(qsuffix) == -1) return -1;
	sprintf(fname, "%s/%s", direct, fh->filename);
	sprintf(dfname, "%s/df%s", BBSMAILDIR, qsuffix);
	if (link(fname, dfname) != 0) return -1;
	return(createqf(fh->title, qsuffix));
}				

#endif

/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/* rrr - This is separated so I can suck it into the IRC source for use
   there too */

char *
ModeType(mode)
{
	switch(mode)
	  {
		case IDLE:
		  return "" ;
		case ULDL:
		  return "UL/DL" ;
		case TALK:
		  return "Talk" ;
		case NEW:
		  return "New User" ;
		case CHAT4:
		  return "Chat-4"; 
		case CHAT1:
		  return "Chat-1" ;
		case CHAT2:
		  return "Chat-2";
		case CHAT3:
		  return "Chat-3"; 
		case LAUSERS:
		  return "Show Acts"; 
                case LUSERS:
		  return "Users";  
		case SMAIL:
		  return "Send Mail"; 
		case RMAIL:
		  return "Read Mail"; 
        case POSTING:
          return "Posting" ;
        case MAIL:
          return "Mail Menu" ;
        case READNEW:
          return "Read New" ;
	case MMENU:
	  return "Main Menu";
	case TMENU:
	  return "Talk Menu";
	case XMENU:
	  return "XYZ Menu";
	case ADMIN:
	  return "Admin";
	case READING:
	  return "Reading";
	case PAGE:
	  return "Page";
	case LOGIN:
	  return "Login";
	case SHOW:
	  return "Boards";
	case SELECT:
 	  return "Select";
	case MONITOR:
	  return "Monitor";
	case EDITWELC:
	  return "Edit Welc";
	case ZAP:
	  return "Zap";
	case EDITSIG:
	  return "Edit Sig";
	case EDITPLAN:
	  return "Edit Plan";
	case QUERY:
	  return "Query";
	case CNTBRDS:
	  return "Count";
	case VOTING:
	  return "Voting";
	case VISIT:
	  return "Visit";
	case IRCCHAT:
	  return "IRC Chat";
        case BBSNET:
	  return "BBSNet";
        case FOURM:
	  return "4m Chat";
	default:
	  return "Udef Mode" ;
	}
}

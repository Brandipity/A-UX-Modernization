/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifdef AUX
#include <sys/file.h>
#endif

#include "bbs.h"

jmp_buf byebye ;

FILE *ufp ;
long ti ;
int talkrequest = NA ;
int bfinger = 0;

struct user_info uinfo ;

extern char *boardmargin() ;
extern char *genpasswd();

char fromhost[STRLEN] ;
char BoardName[STRLEN] ;

int utmpent = -1 ;
u_enter()
{
	uinfo.active = YEA ;
	uinfo.pid    = getpid() ;
#ifdef PERMS
	if (HAS_PERM(PERM_LOGINCLOAK))
#else
	if (currentuser.userlevel >= CLOAKONLOGIN)
#endif
	    uinfo.invisible = currentuser.flags[0] & CLOAK_FLAG ? YEA : NA;
	else uinfo.invisible = NA;
	uinfo.sockactive = NA ;
	uinfo.sockaddr = 0 ;
	uinfo.destuid = 0 ;
	uinfo.mode = LOGIN ;
	uinfo.pager = !(currentuser.flags[0] & PAGER_FLAG);
	uinfo.in_chat = NA ;
	bzero(uinfo.chatid, sizeof(uinfo.chatid));
	uinfo.uid = usernum ;
	strncpy(uinfo.from,fromhost,STRLEN) ;
	utmpent = getnewutmpent(&uinfo) ;
}

setflags(mask, value)
int mask, value;
{
	if (((currentuser.flags[0] & mask) && 1) != value) {
	    if (value) currentuser.flags[0] |= mask;
	    else currentuser.flags[0] &= ~mask;
	    return 1;
	}
	else return 0;
}

u_exit()
{
	int f1 = 0, f2 = 0;	
	f1 = setflags(PAGER_FLAG, !uinfo.pager);
#ifdef PERMS
 	if (HAS_PERM(PERM_LOGINCLOAK))
#else
 	if (currentuser.userlevel >= CLOAKONLOGIN)
#endif
	    f2 = setflags(CLOAK_FLAG, uinfo.invisible);
	if (f1 || f2) 
	    substitute_record(PASSFILE,&currentuser,sizeof(currentuser),usernum);
	uinfo.active = NA ;
	uinfo.pid = 0 ;
	uinfo.invisible = YEA ;
	uinfo.sockactive = NA ;
	uinfo.sockaddr = 0 ;
	uinfo.destuid = 0 ;
	substitute_record(ULIST,&uinfo,sizeof(uinfo),utmpent) ;
}

int
cmpuids(uid,up)
char *uid ;
struct userec *up ;
{
    return !ci_strncmp(uid,up->userid,sizeof(up->userid)) ;
}


int
dosearchuser(userid)
char *userid ;
{
	return usernum = search_record(PASSFILE,&currentuser,sizeof(currentuser),
                                   cmpuids,userid) ;
}

int started = 0;

void
talk_request()
{
	talkrequest = YEA;
	bell();
	bell();   /* Second beep voted in by Eagle's Nest users */
/* Take care of systems that don't restart signal handlers. */
#if LINUX || AIX
	signal(SIGUSR1, talk_request);
#endif
#if CLIX
        signal(SIGUSR1, (void (*)(int))talk_request);
#endif
}

void
abort_bbs()
{
	if (started)
	  if((ufp = fopen("usies","a")) != NULL) {
		  ti = time(0) ;
		  fprintf(ufp,"AXXED %-10s %-20s %s",currentuser.userid,currentuser.username,ctime(&ti)) ;
		  fflush(ufp) ;
		  u_exit() ;
		  fclose(ufp) ;
	  }
	exit(0) ;
}

cmpuids2(unum, urec)
int unum;
struct user_info *urec;
{
	return (unum == urec->uid);
}


multi_user_check()
{
	struct user_info uin;
	char buffer[40];
#ifdef PERMS
	if (HAS_PERM(PERM_MULTILOG)) return;  /* don't check sysops */
#else
	if (currentuser.userlevel >= MULTILOGOK) return;  /* don't check sysops */
#endif
	if (!search_record(ULIST, &uin, sizeof(uin), cmpuids2, usernum))
	    return;  /* user isn't logged in */
	if (!uin.active || (kill(uin.pid,0) == -1))
	    return;  /* stale entry in utmp file */
        prints("I'm sorry.  You are already logged in.\nMultiple logins not allowed.\n\n");
        prints("Would you like to kill your other login?\n");
        getdata(0,0,"(Yes, or No) [N]: ",genbuf,4,DOECHO,NULL) ;
        if(genbuf[0] != 'Y' && genbuf[0] != 'y') {
            printf("\nOK.\nGoodbye!\n\n") ;
	    sleep(1);
	    exit(1);
        }
        else {
            kill(uin.pid,9);
            sprintf(buffer, "kicked (multi-login)" );
            report(buffer);
            if ((ufp = fopen("usies", "a")) != NULL) {
                ti = time(0);
                fprintf(ufp, "KICK  %-10s %-20s %s", currentuser.userid,
	        currentuser.username, ctime(&ti));
                fflush(ufp);
                fclose(ufp);
            }
	}
}
	
account_disabled(userid)
char *userid;
{
    FILE *fp;
    char buf[STRLEN];
    int blen;
    if ((fp = fopen(".disabled", "r")) == NULL)
	return 0;
    while (fgets(buf, STRLEN, fp) != NULL) {
        blen = strlen(buf);
        if (buf[blen-1] == '\n')
	    buf[--blen] = '\0';
        if (!strncmp(buf, userid, blen)) {
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}
#ifndef AUX
#include <sys/file.h> 
#endif

#include <signal.h>

#if !defined(AIX) && !defined(NEXT)
extern char *index();
#endif

main(argc, argv)
int argc ;
char **argv ;
{
	char uid[STRLEN] ;
	char *pass, *getpass() ;
	char passbuf[PASSLEN] ;
	char ans[4];
	int cmd, nu = 0, numbad ;
	int fd ;
	int getin ;
	int baduserid, attempts = 0;
#ifdef LINUX
	struct sigaction sa;
#endif

#ifdef SINGLE
    { char c[256] ;
      gethostname(c,256) ;
      if(strcmp(c,SINGLE)) {
          printf("Not on a valid machine!\n") ;
          exit(-1) ;
      } }
#endif
	getin = NA ;	
	if(argc == 2) {
		switch(*argv[1]) {
		  case 'U':
   		  case 'u':
			/* User status check */
			UserStatus() ;
			exit(0) ;
		  case 's':
		  case 'S':
		  	getin = YEA ;
		  break;

		  case 'l':
		  case 'L':
			bfinger = 1;
            		dumb_user_list() ;
			exit(0) ;
          	  case 'a':
               		list_all_users() ;
            		exit(0) ;
		  default:
			fprintf(stderr,"UNKNOWN OPTION\n") ;
			exit(0) ;
		}
	}
	if(argc == 3)
          strncpy(fromhost,argv[2],STRLEN) ;
	else
          fromhost[0] = '\0' ;

#ifndef lint
#if CLIX
	signal(SIGHUP,(void (*)(int))abort_bbs) ;
#else
	signal(SIGHUP,abort_bbs) ;
#endif
	signal(SIGINT,SIG_IGN) ;
	signal(SIGQUIT,SIG_IGN) ;
	signal(SIGPIPE,SIG_IGN) ;
#ifdef DOTIMEOUT
	init_alarm();
#else
	signal(SIGALRM,SIG_IGN) ;
#endif
	signal(SIGTERM,SIG_IGN) ;
	signal(SIGURG,SIG_IGN) ;
	signal(SIGTSTP,SIG_IGN) ;
	signal(SIGTTIN,SIG_IGN) ;
	signal(SIGTTOU,SIG_IGN) ;
#if CLIX
	signal(SIGUSR1,(void (*)(int))talk_request);
#else
	signal(SIGUSR1,talk_request) ;
#endif
	signal(SIGUSR2,SIG_IGN) ;
#endif /* !lint */
	
/* added from pbbs 1.8 --gtv */
	if(!getin && num_active_users() >= MAXACTIVE) {
    	    if((ufp = fopen("boot.off","r")) == NULL)
      		fprintf(stderr,"\nSorry, BBS system is full.\nCall again later.\n");
            else
      	        while(fgets(genbuf,256,ufp) != NULL)
	          fprintf(stderr,"%s",genbuf) ;
	    exit(-1) ;
    	}
/* added from pbbs 1.8 --gtv */

	if(setjmp(byebye)) {
		if (started)
		  if((ufp = fopen("usies","a")) != NULL) {
			  ti = time(0) ;
			  fprintf(ufp,"ABORT %-10s %-20s %s",currentuser.userid,currentuser.username,ctime(&ti)) ;
			  fflush(ufp) ;
			  u_exit() ;
			  fclose(ufp) ;
		  }
		printf("goodbye\n") ;
		exit(0) ;
	}
	get_tty() ;
	init_tty() ;
	if((fd = open(NAMEFILE,O_RDONLY)) > 0) {
            char *t;
            int cc = read(fd,BoardName,STRLEN) ;
            BoardName[cc] = '\0' ;
            if(t = index(BoardName,'\n'))
              *t = '\0' ;
            close(fd) ;
	} else
            strcpy(BoardName,BOARDNAME) ;
  grok:
	prints("\n\nWelcome to %s\n\n",BoardName) ; 
	more("etc/issue", NA);
#ifdef LOGINASNEW
	getdata(0,0,"\nuser id ('new' for new user): ",uid,STRLEN,DOECHO,NULL) ;
#else
	getdata(0,0,"\nuser id: ",uid,STRLEN,DOECHO,NULL) ;
#endif
	if(uid[0] == '\0')
	  goto grok ;
	if(!strcmp(uid,"new")) {
#ifdef LOGINASNEW
		struct userec newuser ;
		char *s ;
		int allocid ;

		nu = 1 ;
		bzero(&newuser, sizeof(newuser));
		allocid = getnewuserid()  ;
		if(allocid >= MAXUSERS || allocid <= 0) {
			prints("No space for new users on the system!\n") ;
			sleep(1) ;
			exit(1) ;
		}
	  redo:
		prints("Welcome! New user, Please enter your user id \n(a single word nickname or call sign)\n") ;
		getdata(0,0,"Enter user id: ",newuser.userid,IDLEN+1,DOECHO,NULL) ;
		if(*newuser.userid == '\0') {
			prints("Invalid user id.\n") ;
			goto redo ;
		}
		for(s=newuser.userid;*s != '\0';s++)
		  if(!isalpha(*s)) {
			  prints("Invalid user id (Use letters only)\n") ;
			  goto redo ;
		  }
		if(dosearchuser(newuser.userid)) {
			prints("Userid already exists\n") ;
			goto redo ;
		}
	dopassagain:
	        getdata(0,0,"Enter Passwd: ",passbuf,PASSLEN,NOECHO,NULL) ;
        	if(passbuf[0] == '\0') {
            		prints("You must enter a passwd\n") ;
            		goto dopassagain ;
        	}
		strncpy(newuser.passwd,passbuf,PASSLEN) ;
		getdata(0,0,"Renter Passwd: ",passbuf,PASSLEN,NOECHO,NULL) ;
		if(strncmp(passbuf,newuser.passwd,PASSLEN)) {
			prints("Error entering passwd\n") ;
			goto dopassagain ;
		}
        	newuser.passwd[8] = '\0' ;
        	strncpy(newuser.passwd,genpasswd(newuser.passwd),PASSLEN) ;
		getdata(0,0,"User name: ",newuser.username,STRLEN,DOECHO,NULL) ;
#ifdef REALINFO
		getdata(0,0,"Real name: ",newuser.realname,STRLEN-40,DOECHO,NULL);
		getdata(0,0,"Postal address: ", newuser.address,STRLEN,DOECHO,NULL);
#endif
		getdata(0,0,"E-mail address: ", newuser.email,STRLEN,DOECHO,NULL);
	  getterm:
		getdata(0,0,"Termtype (ansi,vt100,vt102,h19a,dumb,...): ",
                newuser.termtype,STRLEN,DOECHO,NULL) ;
		if(!term_init(newuser.termtype)) {
			prints("Invalid terminal type, please enter termcap termtype\n") ;
			goto getterm ;
		}
#ifdef PERMS
		newuser.userlevel = PERM_DEFAULT;
#else
		newuser.userlevel = 0 ;
#endif
		newuser.lastlogin = time(NULL) ;
		newuser.protocol = 0 ;
		if(substitute_record(PASSFILE,&newuser,sizeof(newuser),allocid) == -1) {
			fprintf(stderr,"too much, good bye!\n") ;
			exit(1) ;
		}
	        touchnew() ;
		if(!dosearchuser(newuser.userid)) {
			fprintf(stderr,"User failed to create\n") ;
			exit(1) ;
		}
		report("new account");
#else
		prints("Invalid userid.\n");
		oflush();
		goto grok;
#endif
	} else 
		{
		baduserid = NA;
		if(!dosearchuser(uid)) baduserid = YEA;
		getdata(0,0,"Enter Passwd: ",passbuf,PASSLEN,NOECHO,NULL) ;
        	passbuf[8] = '\0' ;
		if(baduserid || !checkpasswd(currentuser.passwd,passbuf)) {
			logattempt(baduserid?uid:currentuser.userid,fromhost,baduserid);
			prints("Invalid userid or password\n") ;
            		oflush() ;
			attempts++;
			if (attempts == LOGINATTEMPTS) {
				prints("Please try to remember your userid & password!\n");
				oflush();
				reset_tty();
				exit(1);
			}
			else goto grok;
		}
		if (account_disabled(currentuser.userid)) {
			prints("Sorry, this account has been temporarily disabled.\n");
			prints("Goodbye!\n\n");
			oflush();
			exit(1);
		}
#ifndef MULTI_LOGINS
		multi_user_check();
#endif
	}
        if(!term_init(currentuser.termtype)) {
            prints("Bad terminal type.  Defaulting to 'dumb'\n") ;
            term_init("dumb") ;
        }
	if(!strcmp(currentuser.userid,"SYSOP"))
#ifdef PERMS
	  currentuser.userlevel = ~0;   /* SYSOP gets all permission bits */
#else
	  currentuser.userlevel = 255 ;
#endif
	if((ufp = fopen("usies","a")) != NULL) {
	        fromhost[16] = '\0' ;
		ti = time(0) ;
		fprintf(ufp,"ENTER %-10s %-20s %-16s %s",currentuser.userid,currentuser.username,
                fromhost,ctime(&ti)) ;
		u_enter() ;
		if(nu) {
			uinfo.mode = NEW ;
			substitute_record(ULIST,&uinfo,sizeof(uinfo),utmpent) ;
		}
		fflush(ufp) ;
		fclose(ufp) ;
	}
	report("Enter") ;
	started = 1 ;
	initscr() ;
	scrint = 1 ;
	clr() ;
	move(0,0) ;
        more("Welcome", NA);
        if ((numbad = countattempts()) <= 0) {
	    if (numbad < 0) showattempts(NA);
	    pressreturn();
	}
        else {
	    refresh();
	    sprintf(genbuf, "NOTICE: %d new bad login attempts on this account. View (Y/N)? [Y]: ", numbad);
	    getdata(t_lines-1, 0, genbuf, ans, 4, DOECHO, NULL);
	    if (*ans == 'N' || *ans == 'n') showattempts(NA);
	    else showattempts(YEA);
	}
	strncpy(currentuser.lasthost, fromhost, 16);
	currentuser.lasthost[15] = '\0';   /* dumb mistake on my part */
	currentuser.lastlogin = time(NULL) ;
	currentuser.numlogins++;
	substitute_record(PASSFILE,&currentuser,sizeof(currentuser),usernum) ;
	m_init() ;
#ifdef NO_FLOCK
	if (get_semaphore() == -1) {
		printf("Can't get semaphore! Exiting...\n");
		exit(1);
	}
#endif
#ifdef VOTE
	closepolls();
#endif
	if(nu || !HAS_PERM(PERM_BASIC) || currentuser.numlogins == 1)
	  cmd = 'h' ;
	else
	  cmd = 'n' ;
	if(chkmail())
	  cmd = 'm' ;

	uinfo.mode = MMENU;
	substitute_record(ULIST,&uinfo,sizeof(uinfo),utmpent) ;
	docmd(BoardName,"Enter Command: ",cmd,cmdlist,boardmargin) ;
		
	exit(0) ;
}

char *
boardmargin()
{
	static char buf[STRLEN] ;
	if(selboard)
	  sprintf(buf,"Current Board = '%s'",currboard) ;
	else {
	  strcpy(currboard, DEFAULTBOARD) ;
	  if (getbnum(currboard)) {
	    selboard = 1 ;
	    sprintf(buf,"Current Board = '%s'",currboard) ;
	  }
	  else sprintf(buf,"No Board Currently Selected") ;
	}
	return buf ;
}

int refscreen = NA ;

int
egetch()
{
	char c ;
	int rval ;

	if(talkrequest) {
		talkreply() ;
		refscreen = YEA ;
		return -1 ;
	}
  egetagain:
    c = igetch() ;
    if(talkrequest) {
        talkreply() ;
        refscreen = YEA ;
        return -1 ;
    }
#ifdef BIT8
    if(!isprint2(c)) {
#else
    if(!isprint(c)) {
#endif
        switch(c) {
          case '\r':
          case '\n':
          case '\010':
          case '\177':
            break ;
          case CTRL('L'):
            redoscr() ;
          default:
            goto egetagain ;
        }
    }
	rval = c ;
	refscreen = NA ;
	return rval ;
}
			
docmd(cmdtitle,cmdprompt,firstcmd,cmdtable,marginnote)
char *cmdtitle,*cmdprompt ;
int firstcmd ;
struct commands cmdtable[] ;
char *(*marginnote)() ;
{
	int cmd, lastcmdptr ;
	int cmdplen ;
	int reprint ;

	cmdplen = strlen(cmdprompt) ;
  grok:
	clr() ;
	reprint = YEA ;
	prints("%s ",cmdtitle) ;
	move(0,30) ;
	if(chkmail())
      	  prints("(You have mail.)") ;
	else
          prints("                ") ;
	move(0,50) ;
	prints("%s\n",(*marginnote)()) ;
	move(1,0) ;
	prints("%s",cmdprompt) ;
	cmd = firstcmd ;
	lastcmdptr = 0 ;
	do {
          extern int dumb_term ;
	  int i=0 ;
	  int err ;
	
	  if(cmd == '\n' || cmd == '\r') {
            if(dumb_term)
              prints("\n") ;
            else {
                move(1,cmdplen) ;
                clrtoeol() ;
                refresh() ;
            }
            clrstandout() ;
	    if((err = (*cmdtable[lastcmdptr].cmdfunc)()) == QUIT)
	      return ;
	    move(0,0) ;
	    clrtoeol();
            reprint = YEA ;
            prints("%s ",cmdtitle) ;
            move(0,30) ;
            if(chkmail())
              prints("(You have mail.)") ;
	    else
              prints("                ") ;
	    move(0,50) ;
	    prints("%s\n",(*marginnote)()) ;
	    move(1,0) ;
	    prints("%s",cmdprompt) ;
	    clrtoeol() ;
	    if(err)
		  cmd = *(cmdtable[lastcmdptr].errorcmd) ;
	    else
		  cmd = *(cmdtable[lastcmdptr].nextcmd) ;
	  }
	  while(i != 100) {
		if(cmdtable[i].cmdname == NULL)
		  break ;
		if((*(cmdtable[i].cmdname) & ~0x20) == (cmd & ~0x20))
		  break ;
		i++ ;
	  }
	  if(cmdtable[i].cmdname == NULL) {
		bell() ;
		continue ;
	  }
#ifdef PERMS
	  if(!HAS_PERM(cmdtable[i].level)) {
#else
	  if(cmdtable[i].level > currentuser.userlevel) {
#endif
		bell() ;
		continue ;
	  }
          if(dumb_term) {
            int lastcmdlen ;
            int newcmdlen ;
            register int j ;

            if(reprint) {
                reprint = NA ;
                prints("%s",cmdtable[i].cmdname) ;
                lastcmdptr = i ;
                continue ;
            }
            if(lastcmdptr == i)
              continue ;
            if(lastcmdptr == 0) {
                prints("%s",cmdtable[i].cmdname) ;
                lastcmdptr = i ;
                continue ;
            }
            lastcmdlen = strlen(cmdtable[lastcmdptr].cmdname) ;
            newcmdlen = strlen(cmdtable[i].cmdname) ;
            for(j=0;j<lastcmdlen;j++)
              ochar(CTRL('H')) ;
            prints("%s",cmdtable[i].cmdname) ;
            if(lastcmdlen > newcmdlen) {
                register int k = lastcmdlen - newcmdlen ;
                for(j=0;j<k;j++)
                  ochar(' ') ;
                for(j=0;j<k;j++)
                  ochar(CTRL('H')) ;
            }
            lastcmdptr = i ;
        } else {
            lastcmdptr = i ;
            move(1,cmdplen) ;
            standout() ;
            prints("%s",cmdtable[i].cmdname) ;
            standend() ;
            clrtoeol() ;
      }
    } while ((cmd = egetch()) != EOF) ;
    if(refscreen)
      goto grok ;
    abort_bbs() ;
}


m_adduser()
{
		struct userec newuser;
		struct userec saveuser;
		char *s ;
		int allocid, saveunum;
		char passbuf[PASSLEN], ans[4];
		clr();
		bcopy(&currentuser, &saveuser, sizeof(saveuser));
		bzero(&newuser, sizeof(newuser));
		saveunum = usernum;
		allocid = getnewuserid()  ;
		if(allocid >= MAXUSERS || allocid <= 0) {
			prints("No space for new users on the system!\n") ;
			sleep(1) ;
			return 0 ;
		}
		standout();
		prints("Add New User");
		standend();
		clrtoeol();		
	  redo:
		getdata(1,0,"Enter user id: ",newuser.userid,IDLEN+1,DOECHO,NULL) ;
		if(*newuser.userid == '\0') {
			prints("Invalid user id.\n") ;
			goto redo ;
		}
		for(s=newuser.userid;*s != '\0';s++)
		  if(!isalpha(*s)) {
			  prints("Invalid user id (Use letters only)\n") ;
			  goto redo ;
		  }
		if(dosearchuser(newuser.userid)) {
			prints("Userid already exists\n") ;
			goto redo ;
		}
	      dopassagain:
        	getdata(2,0,"Enter Passwd: ",passbuf,PASSLEN,NOECHO,NULL) ;
         	if(passbuf[0] == '\0') {
            	  prints("You must enter a passwd\n") ;
            	  goto dopassagain ;
        	}
		strncpy(newuser.passwd,passbuf,PASSLEN) ;
		getdata(2,0,"Renter Passwd: ",passbuf,PASSLEN,NOECHO,NULL) ;
		if(strncmp(passbuf,newuser.passwd,PASSLEN)) {
			prints("Error entering passwd\n") ;
			goto dopassagain ;
		}
        	newuser.passwd[8] = '\0' ;
        	strncpy(newuser.passwd,genpasswd(newuser.passwd),PASSLEN) ;
		getdata(3,0,"Name: ",newuser.username,STRLEN,DOECHO,NULL) ;
	      getterm:
		getdata(4,0,"Termtype (ansi,vt100,vt102,h19a,dumb,...): ",
                newuser.termtype,STRLEN,DOECHO,NULL) ;
#ifdef PERMS
		newuser.userlevel = PERM_DEFAULT;
#else
		newuser.userlevel = 0 ;
#endif
		newuser.lastlogin = time(NULL) ;
		newuser.protocol = 0 ;
#ifdef REALINFO
		getdata(5,0,"Real name: ", newuser.realname,STRLEN-40,DOECHO,NULL);
		getdata(6,0,"Address: ", newuser.address,STRLEN,DOECHO,NULL);
		getdata(7,0,"E-mail path: ", newuser.email,STRLEN,DOECHO,NULL);
#else
		getdata(5,0,"E-mail path: ", newuser.email,STRLEN,DOECHO,NULL);
#endif
		bcopy(&saveuser, &currentuser, sizeof(currentuser));
		usernum = saveunum;
		getdata(9,0,"Add this account (Y/N)? [Y]: ",ans,4,DOECHO,NULL);
		if(ans[0]=='n' || ans[0]=='N') {
			newuser.userid[0] = '\0';
			substitute_record(PASSFILE, &newuser, sizeof(newuser), allocid);
			prints("New account NOT created.\n");
			pressreturn();
			clr();
			return(0);
		}
		if(substitute_record(PASSFILE,&newuser,sizeof(newuser),allocid) == -1) {
			prints("No space in password file!\n");
			pressreturn();
			clr();
			return 0;
		}
	sprintf(genbuf, "added user %s", newuser.userid);
	report(genbuf);
	prints("\nNew Account Created\n");
	touchnew();
	pressreturn();
	clr();
	return 0;
} 

#define BADLOGINSTRSZ	80
#define BADLOGINFILE	"logins.bad"
extern char *Ctime();

logattempt(uid, frm, badid)
char *uid, *frm;
int badid;
{
    char buf[BADLOGINSTRSZ+1];
    char *timestr;
    time_t t;
    time(&t);
    timestr = Ctime(&t);
    uid[12] = '\0';
    sprintf(buf, "%-12s %-32s %-16s %c               \n", uid,timestr,frm,badid?'Y':'N');	
    append_record(BADLOGINFILE, buf, BADLOGINSTRSZ);
    return;
}

countattempts()
{
    int fd, cnt = 0;
    char buf[BADLOGINSTRSZ];
#ifdef PERMS
    if (!HAS_PERM(PERM_BASIC))
        return -1;    /* don't show the bad login attempts */
#endif
    if ((fd = open(BADLOGINFILE, O_RDONLY)) == -1)
        return 0;
    while (read(fd, buf, BADLOGINSTRSZ) == BADLOGINSTRSZ)
        if (!strncmp(buf, currentuser.userid, strlen(currentuser.userid)) 
            && buf[63] == 'N') cnt++;
    close(fd);
    return cnt;
}	

showattempts(really)
int really;
{
    int fd, ln = 1;
    char buf[BADLOGINSTRSZ];
    if ((fd = open(BADLOGINFILE, O_RDWR)) == -1)
        return;
    if (really) clr();
    while (read(fd, buf, BADLOGINSTRSZ) == BADLOGINSTRSZ) {
        if (!strncmp(buf, currentuser.userid, strlen(currentuser.userid)) 
	             && buf[63] == 'N') {
	    buf[63] = 'Y';
	    flock(fd, LOCK_EX);
	    if (lseek(fd, -BADLOGINSTRSZ, L_INCR) != -1)
	        write(fd, buf, BADLOGINSTRSZ);
	    flock(fd, LOCK_UN);
	    if (really) {
		buf[45] = buf[62] = '\0';
		if (ln >= t_lines) {
		    prints("More -- press a key to continue\n");
		    igetch();
		    clr();
		    ln = 1;
		}
		prints("UNSUCCESSFUL LOGIN from %s on %s\n", &buf[46], &buf[13]);
		ln++;
	    }
	}
    }
    close(fd);
    if (really) {
	pressreturn();
	clr();
    }
    return;
}

/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"

#define HIGHLIGHT 1
#define LOWLIGHT  0

struct help_info {
    int x,y ;
    int highlight ;
    int level ;
    char *text ;
} ;

struct help_info MainHelp[]  = {
     4,  0, HIGHLIGHT,   	0, "HELP SCREEN\n",
    -1, -1,  LOWLIGHT,   	0, "(I)nfo          Get Version and Copyright Information\n",
    -1, -1,  LOWLIGHT,   	0, "(B)oards        List boards on system\n",
    -1, -1,  LOWLIGHT,   	0, "(C)ount         Count posts by board\n",
    -1, -1,  LOWLIGHT,   	0, "(S)elect        Select current board\n",
    -1, -1,  LOWLIGHT,   	0, "(R)ead          Enter multifunction Read Menu\n",
    -1, -1,  LOWLIGHT, PERM_BASIC, "(N)ew           Read all new messages\n",
    -1, -1,  LOWLIGHT, PERM_BASIC, "(V)isit         Make all messages current\n",
    -1, -1,  LOWLIGHT,  PERM_POST, "(P)ost          Post a message on current board\n",
    -1, -1,  LOWLIGHT, PERM_BASIC, "(U)sers         List ALL users of this BBS\n",
    -1, -1,  LOWLIGHT, 		0, "(T)alk          Enter Talk Menu (Talk, Chat, Query, User List)\n",
    -1, -1,  LOWLIGHT,   	0, "(M)ail          Enter Mail Menu (Send, Read Local Mail)\n",
#ifdef FILES
    -1, -1,  LOWLIGHT, PERM_BASIC, "(F)iles         Enter File Transfer Menu\n",
#endif
    -1, -1,  LOWLIGHT,   	0, "(X)yz           Utilities (Vote, Change passwd, term type, sig file and plan)\n",
    -1, -1,  LOWLIGHT, PERM_ADMINMENU, "(A)dmin         Enter Admin Menu\n",
    -1, -1,  LOWLIGHT, PERM_BASIC, "(Z)ap           Zap Boards from (N)ew Search\n", 
    -1, -1,  LOWLIGHT,   	0, "(W)elcome       Look at the Welcome Screen\n",
    -1, -1,  LOWLIGHT,   	0, "(G)oodbye       Leave This BBS\n",
    -1, -1,  LOWLIGHT,   	0, "(H)elp          Get this Help Screen\n",
    -1, -1,  LOWLIGHT,   	0, NULL,
  } ;

struct help_info MailHelp[] = {
     4,  0, HIGHLIGHT,  	0, "Mail Menu Help Screen\n",
    -1, -1,  LOWLIGHT, PERM_READMAIL, "(N)ew           See New Mail Messages\n",
    -1, -1,  LOWLIGHT, PERM_SENDMAIL, "(S)end          Send a Mail Message to another user\n",
    -1, -1,  LOWLIGHT, PERM_READMAIL, "(R)ead          Enter Multi purpose Read Menu\n",
    -1, -1,  LOWLIGHT,   	0, "(E)xit          EXIT Mail Menu\n",
    -1, -1,  LOWLIGHT,   	0, "(H)elp          Get this Help Screen\n",
    -1, -1,  LOWLIGHT,   	0, NULL
  } ;

#ifdef FILES
struct help_info FileHelp[] = {
     4,  0, HIGHLIGHT,   	0, "File Transfer Menu Help Screen\n",
    -1, -1,  LOWLIGHT,   	0, "(S)elect        Select a File Sub-board\n",
    -1, -1,  LOWLIGHT,   	0, "(L)ist          List the files on current Sub-board\n",
    -1, -1,  LOWLIGHT,   	0, "(P)rotocol      Select download/upload protocol\n",
    -1, -1,  LOWLIGHT,   	0, "(D)ownload      Download a file from this bbs\n",
    -1, -1,  LOWLIGHT, PERM_UPLOAD, "(U)pload        Upload a file to this bbs\n",
    -1, -1,  LOWLIGHT,   	0, "(T)ext          View a text file\n",
    -1, -1,  LOWLIGHT,   	0, "(E)xit          EXIT File Menu\n",
    -1, -1,  LOWLIGHT,   	0, "(H)elp          Get this Help Screen\n",
    -1, -1,  LOWLIGHT,   	0, NULL
  } ;
#endif

struct help_info XyzHelp[] = {
     4,  0, HIGHLIGHT,   	0, "XYZ Menu Help Screen\n",
    -1, -1,  LOWLIGHT,   	0, "(G)NU GENERAL PUBLIC LICENSE\n",
    -1, -1,  LOWLIGHT, PERM_CLOAK, "(C)loak         Hide from other users\n",
    -1, -1,  LOWLIGHT, PERM_BASIC, "(P)asswd        Set User Passwd\n",
    -1, -1,  LOWLIGHT, PERM_BASIC, "(N)ame          Set User Name\n",
#ifdef INTERNET_EMAIL
    -1, -1,  LOWLIGHT, PERM_SETADDR, "(A)ddress       Set Your Internet Mail Address\n",
#endif
    -1, -1,  LOWLIGHT, PERM_BASIC, "(U)sers         List Users Online Now\n",
    -1, -1,  LOWLIGHT,   	0, "(T)erminal      Set Terminal Type\n",
    -1, -1,  LOWLIGHT,   	0, "(E)xit          EXIT XYZ Menu\n",
#ifdef REALINFO
    -1, -1,  LOWLIGHT, PERM_BASIC, "(I)nfo          Show Your PASSFILE info\n",
#endif
#ifdef VOTE
    -1, -1,  LOWLIGHT, PERM_VOTE, "(V)ote          The BBS Voting Booth\n",
    -1, -1,  LOWLIGHT, PERM_VOTE, "(R)esults       See Results of Previous Ballots\n",
#endif
#ifdef BBSDOORS
    -1, -1,  LOWLIGHT, PERM_BASIC, "(B)BSNet        Doors To Other BBSes\n",
#endif
#ifdef MMMM
    -1, -1,  LOWLIGHT, PERM_CHAT,  "(4)m RC         Edit 4m Chat Config File\n",
#endif
    -1, -1,  LOWLIGHT, PERM_WELCOME, "(W)elcome       Edit The Welcome Screen\n",
    -1, -1,  LOWLIGHT, PERM_BASIC, "(S)ignature     Edit/Delete your Signature File\n",
    -1, -1,  LOWLIGHT, PERM_BASIC, "(Q)ueryEdit     Edit/Delete your Plan\n",
    -1, -1,  LOWLIGHT,   	0, "(D)ate          Show current date/time\n",
    -1, -1,  LOWLIGHT,   	0, "(H)elp          Get this Help Screen\n",
    -1, -1,  LOWLIGHT,  	0, NULL
  } ;

struct help_info TalkHelp[] = {
     4,  0, HIGHLIGHT,  	0, "Talk Menu Help Screen\n",
    -1, -1,  LOWLIGHT,   	0, "(U)sers         List Users Online Now\n",
#ifdef REALINFO
    -1, -1,  LOWLIGHT, PERM_BASIC, "(R)ealname      Show Online Users By Real Name\n",
#endif
    -1, -1,  LOWLIGHT,   	0, "(L)ist          Short Version of (U)sers\n",
    -1, -1,  LOWLIGHT, PERM_BASIC, "(M)onitor       Monitor User List\n", 
    -1, -1,  LOWLIGHT,   	0, "(Q)uery         Read a user's Plan\n",
    -1, -1,  LOWLIGHT,  PERM_PAGE, "(T)alk          Talk to another user\n", 
    -1, -1,  LOWLIGHT, PERM_BASIC, "(P)ager         Toggle Pager on/off\n",
    -1, -1,  LOWLIGHT, PERM_BASIC, "(O)verride      Let users override Pager Off\n",
    -1, -1,  LOWLIGHT, PERM_CLOAK, "(C)loak         Hide from other users\n",
    -1, -1,  LOWLIGHT,  PERM_CHAT, "(1)Chat         Enter Chat Room 1\n",
    -1, -1,  LOWLIGHT,  PERM_CHAT, "(2)Chat         Enter Chat Room 2\n", 
    -1, -1,  LOWLIGHT, PERM_CHAT, "(3)Chat         Enter Chat Room 3\n",
    -1, -1,  LOWLIGHT, PERM_SEECLOAK, "(4)Chat         Enter Chat Room 4\n",
#ifdef IRC
    -1, -1,  LOWLIGHT,  PERM_CHAT, "(I)RC           Enter IRC Chat\n",
#endif
#ifdef MMMM
    -1, -1,  LOWLIGHT,  PERM_CHAT, "(F)our M        Enter 4m Intercom Chat\n",
#endif
    -1, -1,  LOWLIGHT, PERM_SYSOP, "(K)ick          Kick User Off System\n",
    -1, -1,  LOWLIGHT,   	0, "(D)ate          Show current date/time\n",
    -1, -1,  LOWLIGHT,   	0, "(E)xit          EXIT Talk Menu\n",
    -1, -1,  LOWLIGHT,   	0, "(H)elp          Get this Help Screen\n",
    -1, -1,  LOWLIGHT,   	0, NULL
  } ;

struct help_info AdminHelp[] = {
     4,  0, HIGHLIGHT,   	0, "Admin Menu Help Screen\n",
    -1, -1,  LOWLIGHT, PERM_UCLEAN, "(U)ser Clean    Clean all accounts inactive over 30 days\n",
    -1, -1,  LOWLIGHT, PERM_UCLEAN, "(X)empt         Exempt a user from User Cleans\n",
    -1, -1,  LOWLIGHT, PERM_SYSOP,   "(L)evel         Change User Level\n",
    -1, -1,  LOWLIGHT, PERM_SYSOP,   "(S)hell         Get Unix Shell\n",
    -1, -1,  LOWLIGHT, PERM_ACCOUNTS, "(I)nfo          Get and change user info\n",
    -1, -1,  LOWLIGHT, PERM_ACCOUNTS, "(A)dd User      Add a new account\n",
    -1, -1,  LOWLIGHT, PERM_ACCOUNTS, "(D)elete User   Delete a user\n",
    -1, -1,  LOWLIGHT, PERM_BOARDS,  "(N)ew Board     Create a new board\n",
    -1, -1,  LOWLIGHT, PERM_BOARDS,  "(B)oard Delete  Delete a board\n",
    -1, -1,  LOWLIGHT, PERM_BOARDS,  "(C)hange Board  Change Board Information\n",
    -1, -1,  LOWLIGHT, PERM_SYSOP,   "(M)ail Clean    Clean Old/Unmarked Mail\n",
    -1, -1,  LOWLIGHT, PERM_SYSOP,   "(T)race         Set Tracing Options\n",
#ifdef VOTE
    -1, -1,  LOWLIGHT, PERM_OVOTE,   "(V)ote          Open The Polls for Voting\n",
#endif
    -1, -1,  LOWLIGHT,   	  0, "(E)xit          EXIT Admin Menu\n",
    -1, -1,  LOWLIGHT, 	          0, "(H)elp          Get this Help Screen\n",
    -1, -1,  LOWLIGHT,   	  0, NULL
  } ;

struct help_info MainRead[] = {
     0,  0, HIGHLIGHT,   0, "Main Read Menu Help Screen\n",
     2,  0, HIGHLIGHT,   0, "Movement Commands\n",
    -1, -1,  LOWLIGHT,   0, "p            Previous Message\n",
    -1, -1,  LOWLIGHT,   0, "n            Next Message\n",
    -1, -1,  LOWLIGHT,   0, "P            Previous Page\n",
    -1, -1,  LOWLIGHT,   0, "N            Next Page\n",
    -1, -1,  LOWLIGHT,   0, "## <cr>      Goto Message ##\n",
    -1, -1,  LOWLIGHT,   0, "$            Goto Last Message\n",
    -1, -1,  LOWLIGHT,   0, "\n",
    -1, -1, HIGHLIGHT,   0, "Miscellaneous Commands\n",
    -1, -1,  LOWLIGHT,   0, "r            Read a Message\n",
    -1, -1,  LOWLIGHT,   PERM_POST, "CTRL-P       Post a Message\n",
    -1, -1,  LOWLIGHT,   PERM_BASIC, "d            Delete Current Message if owned\n",
    -1, -1,  LOWLIGHT,   PERM_BOARDS, "D            Delete Range of Posts\n",
    -1, -1,  LOWLIGHT,   PERM_MARKPOST, "m            Mark post to be ignored by Delete Range\n",
    -1, -1,  LOWLIGHT,   PERM_SYSOP, "E            Edit Current Post\n",
    -1, -1,  LOWLIGHT,   0, "s            Select a New Board\n",
    -1, -1,  LOWLIGHT,   0, "S            Sequentially read unread messages starting at cursor\n",
#ifdef INTERNET_EMAIL
    -1, -1,  LOWLIGHT,   PERM_FORWARD, "F            Forward post to your Internet mailbox\n",
#endif
    -1, -1,  LOWLIGHT,   0, "CTRL-L       Redraw Screen\n",
    -1, -1,  LOWLIGHT,   0, "h            This Help Screen\n",
    -1, -1, HIGHLIGHT,   0, "e            EXIT Read Menu\n",
    -1, -1,  LOWLIGHT,   0, NULL
  } ;

struct help_info MailRead[] = {
     0,  0, HIGHLIGHT,   0, "Mail Read Menu Help Screen\n",
     2,  0, HIGHLIGHT,   0, "Movement Commands\n",
    -1, -1,  LOWLIGHT,   0, "p            Previous Message\n",
    -1, -1,  LOWLIGHT,   0, "n            Next Message\n",
    -1, -1,  LOWLIGHT,   0, "P            Previous Page\n",
    -1, -1,  LOWLIGHT,   0, "N            Next Page\n",
    -1, -1,  LOWLIGHT,   0, "## <cr>      Goto Message ##\n",
    -1, -1,  LOWLIGHT,   0, "$            Goto Last Message\n",
    -1, -1,  LOWLIGHT,   0, "\n",
    -1, -1, HIGHLIGHT,   0, "Miscellaneous Commands\n",
    -1, -1,  LOWLIGHT,   0, "r            Read a Message\n",
    -1, -1,  LOWLIGHT,   0, "R            Reply to Sender\n",
#ifdef INTERNET_EMAIL
    -1, -1,  LOWLIGHT, PERM_FORWARD, "F            Forward Message to your Internet Box\n",
#endif
    -1, -1,  LOWLIGHT,   0, "d            Delete Current Message\n",
    -1, -1,  LOWLIGHT,   0, "D            Delete Range of Messages\n",
    -1, -1,  LOWLIGHT,   0, "m            Mark/Unmark message for non-deletion\n",
    -1, -1,  LOWLIGHT,   0, "CTRL-L       Redraw Screen\n",
    -1, -1,  LOWLIGHT,   0, "h            This Help Screen\n",
    -1, -1,  LOWLIGHT,   0, "e            EXIT Read Menu\n",
    -1, -1,  LOWLIGHT,   0, NULL
  } ;


do_the_help(p)
struct help_info *p ;
{
    while(p->text) {
        if(p->highlight)
          standout() ;
        if(p->x != -1)
          move(p->x, p->y) ;
#ifdef PERMS
	if(HAS_PERM(p->level))
#else
        if(currentuser.userlevel >= p->level)
#endif
          prints("%s",p->text) ;
        if(p->highlight)
          standend() ;
        p++ ;
    }
    return ;
}


Help()
{
    move(3,0) ;
    clrtoeol() ;
    do_the_help(MainHelp) ;
    clrtobot() ;
}

m_help()
{
    move(3,0) ;
    clrtoeol() ;
    do_the_help(MailHelp) ;
    clrtobot() ;
}

#ifdef FILES
f_help()
{
    move(3,0) ;
    clrtoeol() ;
    do_the_help(FileHelp) ;
    clrtobot() ;
}
#endif

x_help()
{
    move(3,0) ;
    clrtoeol() ;
    do_the_help(XyzHelp) ;
    clrtobot() ;
}

t_help()
{
    move(3,0) ;
    clrtoeol() ;
    do_the_help(TalkHelp) ;
    clrtobot() ;
}

a_help()
{
    move(3,0) ;
    clrtoeol() ;
    do_the_help(AdminHelp) ;
    clrtobot() ;
}

mainreadhelp()
{
    clr() ;
    do_the_help(MainRead) ;
    pressreturn() ;
    clr() ;
    return FULLUPDATE ;
}

mailreadhelp()
{
    clr() ;
    do_the_help(MailRead) ;
    pressreturn() ;
    clr() ;
    return FULLUPDATE ;
}



#include "bbs.h"

extern char *genpasswd();

main(argc, argv)
int argc;
char *argv[];
{
    struct userec urec;
    int fd;
    if (argc <= 1) {
	fprintf(stderr, "Usage: %s <file>\n", argv[0]);
	return 2;
    }
    
    fd = open(argv[1], O_WRONLY|O_CREAT|O_EXCL, 0600);
    if (fd == -1) {
	perror(argv[0]);
        return 1;
    }

    memset(&urec, 0, sizeof(urec));
    strcpy(urec.userid, "SYSOP");
    strcpy(urec.passwd, genpasswd("password"));
    strcpy(urec.username, "Sysop");
    strcpy(urec.termtype, "dumb");
    urec.userlevel = ~0;
    
    write(fd, &urec, sizeof(urec));
    close(fd);

    return 0;
}    

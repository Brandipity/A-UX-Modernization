 /*
  * Short stubby program that starts the BBS and findshostname.
  * First written by Jim Jagielski.
  * Major re-do by Nathan Neulinger.
  */
 
#include <stdio.h>
#include <string.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <utmp.h>
#include <pwd.h>

/* Makes it easy to define the home dir for bbs */
#define BBS           "/users/bbs/bin/bbs"
#define BUFSIZE               1024
 
#ifndef UTMP_FILE
#define UTMP_FILE       "/etc/utmp"
#endif

extern char *ttyname(), *index(), *rindex() ;

struct utmp *
invis()
{
        static struct utmp data ;
        int fd ;
        int flag = 0 ;
        char *name, *tp ;
        struct passwd *pp ;

        tp = ttyname(0) ;
        if(!tp)
        return NULL ;
        tp = rindex(tp,'/') + 1 ;
        pp = getpwuid(getuid()) ;
        if(!pp)
                exit(0) ;

        name = pp->pw_name ;

        if((fd = open(UTMP_FILE, O_RDONLY)) == -1)
        {
                return NULL;
        }

        while(read(fd,&data,sizeof(struct utmp))>0)
        {
                if(
                   !strcmp(tp,data.ut_line))
                {
                        struct utmp nildata ;
                        flag = 1 ;
                        bcopy(&data, &nildata, sizeof(nildata)) ;

                        close(fd) ;
                        return &data ;
                }
        }
        close(fd) ;
        return NULL ;
}


main()
{
        struct utmp *whee ;
		char newbuf[BUFSIZE];

        char host[17] ;

        host[0] = '\0';

        whee = invis() ;

        if(whee) {
            if (whee->ut_host[0])
                strncpy(host, whee->ut_host, 16) ;
            else
                gethostname(host, 16);
            host[16] = '\0' ;
        }
        else
        {
	    strcpy(host,"unknown.host");
	}

        strcpy(newbuf,"h ");  
        strcat(newbuf, host);
/*
   * Uncomment the below line if you 
   * want that to display not needed though
*/
/*	printf("Connecting to BBS from host: %s\n",host); */
	execl(BBS, "bbs", "h", host, 0); 

      /*
      * if we get to here, there's been some problem.
      * At this point, we could print out some error message...
      */
     exit(1);
}

/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#ifdef AUX
#include <sys/types.h>
#include <sys/file.h>
#include "bbs.h"
#include <fcntl.h>
#ifndef XINU
#include <sys/stat.h>
#endif
#endif

#ifndef AUX
#include "bbs.h"
#include <fcntl.h>
#include <sys/types.h>
#include <sys/file.h>
#ifndef XINU
#include <sys/stat.h>
#endif
#endif

extern char saveboard[STRLEN] ;
extern int mot ;

struct fileheader fh ;

read_boards(fptr)
struct fileheader *fptr ;
{
    register int i, offset ;
    int numfiles = 0;
    int fd ;
    int readone = NA;
    int statusbyte;
    unsigned char ch ;
    char ans[6];
    struct stat st ;
    int own = 0, vis = 0, unread = 0;
    
    if (fptr->accessed[0] & ZAPPED) return 0;
    offset =  ((int)&(fh.accessed[usernum]) - (int)&(fh)) ;
    getstats(fptr->filename, &numfiles, &own, &vis, &unread, genbuf);
    if (numfiles == 0 || unread == 0) return 0;
    sprintf(genbuf,"boards/%s/%s",fptr->filename,DIR) ;
    if((fd = open(genbuf, O_RDWR)) < 0)
      return 0 ;

    for(i = 0 ; i < numfiles ; i++) {
        fstat(fd, &st);
        statusbyte = offset+i*sizeof(fh);
        if (st.st_size < statusbyte) break;   /* bail! now! */
        lseek(fd, statusbyte, L_SET);
        read(fd,&ch,1) ;
        if(!(ch & FILE_READ)) {
            mot = 1 ;
            lseek(fd,i*sizeof(fh),L_SET) ;
            read(fd,&fh,((int)&(fh.accessed[0])-(int)&(fh))) ;
            clr() ;
            prints("Read Message [%d more] on board '%s' entitled:\n\"%s\"\n",
                   unread--, fptr->filename,fh.title) ;
            prints("Posted by: %s.\n",fh.owner) ;
            getdata(3,0,"(Yes or No or Quit or SkipBoard) [Y]: ",
                    genbuf,12,DOECHO,NULL) ;
	    genbuf[0] = toupper(genbuf[0]);
            if(genbuf[0] == 'N' || genbuf[0] == 'Q' || genbuf[0] == 'S') {
                if(genbuf[0] == 'q' || genbuf[0] == 'Q') {
                    move(3,0) ;
                    clrtoeol() ;
                    refresh() ;
                    close(fd) ;
		    mot = -1;
                    return QUIT ;
                }
                if(genbuf[0] == 's' || genbuf[0] == 'S') {
                    move(3,0) ;
                    clrtoeol() ;
                    refresh() ;
                    close(fd) ;
                    return 0 ;
                }
                fstat(fd, &st);
                if (st.st_size > statusbyte) {
                    lseek(fd,statusbyte,L_SET) ;
                    ch |= FILE_VISIT ;
                    write(fd,&ch,1) ;
                }
                continue ;
            }
            sprintf(genbuf,"boards/%s/%s",fptr->filename,fh.filename) ;
	    readone = YEA;
#ifdef NOREPLY
	    if (unread == 0) more(genbuf,NA);
	    else more(genbuf,YEA);
#else
                more(genbuf,NA) ;
#ifdef PERMS
	    if (haspostperm(fptr->filename)) {
#endif
	       getdata(t_lines-1,0,"Reply (Y/N)? [N]: ",ans,6,DOECHO,NULL);
	       if (ans[0] == 'Y' || ans[0] == 'y') {
		   strncpy(saveboard, currboard, STRLEN);
		   strncpy(currboard, fptr->filename, STRLEN);
	           do_reply(fh.title);
		   strncpy(currboard, saveboard, STRLEN);
    	       }	
#ifdef PERMS
	    }
	    else pressreturn();
#endif
            clr() ;
#endif
            fstat(fd, &st);
            if (st.st_size > statusbyte) {
                lseek(fd,statusbyte,L_SET) ;
                ch |= FILE_READ ;
                ch &= ~FILE_VISIT ;
                write(fd,&ch,1) ;
	    }
        }
    }
    close(fd) ;
#ifdef NOREPLY
#ifdef PERMS
    if (readone == YEA && haspostperm(fptr->filename)) {
#endif
	char localbuf[STRLEN];
	int lineno = t_lines-1;
        strncpy(saveboard, currboard, STRLEN);
        strncpy(currboard, fptr->filename, STRLEN);
        sprintf(localbuf, "End of board '%s'. Post a message (Y/N)? [N]: ", currboard);
        while (1) {
           getdata(lineno,0,localbuf,ans,6,DOECHO,NULL);
           if (ans[0] == 'Y' || ans[0] == 'y')
		do_post();
	   else break;
	   if (lineno == t_lines-1) {
		lineno = 0;
		sprintf(localbuf, "Post another message on board '%s' (Y/N)? [N]: ", currboard);
	    }
        }	
        strncpy(currboard, saveboard, STRLEN);
#ifdef PERMS
    }
    else if (readone == YEA) pressreturn();
#endif
#endif
    return 0 ;
}

New()
{

    /* report("New") ; */
    clr() ;
    mot = 0 ;

    uinfo.mode = READNEW ;
    substitute_record(ULIST,(void *)&uinfo,sizeof(uinfo),utmpent) ;
    apply_boards(read_boards);
    clr() ;
    uinfo.mode = MMENU ;
    substitute_record(ULIST,(void *)&uinfo,sizeof(uinfo),utmpent) ;
    switch (mot) {
      case 1: prints("No more messages\n\n\n") ; break;
      case 0: prints("No new messages\n\n\n") ; break;
      case -1: prints("Quitting read new.\n\n\n");
    }
    pressreturn() ;
    clr() ;
    return -1 ;
}

visit_boards(fptr)
struct fileheader *fptr ;
{
    register int i, offset ;
    register long numfiles ;
    int fd ;
    unsigned char ch ;
    struct stat st ;
    
    offset = ((int)&(fh.accessed[usernum]) - (int)&(fh)) ;
    sprintf(genbuf,"boards/%s/%s",fptr->filename,DIR) ;
    if((fd = open(genbuf, O_RDWR)) < 0)
        return 0 ;
    fstat(fd,&st) ;
    numfiles = st.st_size ;
    numfiles = numfiles/sizeof(fh) ;
    if(numfiles <= 0) {
        close(fd) ;
        return 0 ;
    }
    flock(fd, LOCK_EX);
    lseek(fd,offset,L_SET) ;
    for(i = 0 ; i < numfiles ; i++,lseek(fd,offset+i*sizeof(fh),L_SET)) {
        read(fd,&ch,1) ;
        if(!(ch & FILE_READ)) {
            lseek(fd,offset+i*sizeof(fh),L_SET) ;
            ch |= FILE_READ ;
            ch |= FILE_VISIT ;
            write(fd,&ch,1) ;
        }
    }
    flock(fd, LOCK_UN);
    close(fd) ;
    prints(".") ;
    refresh() ;
    return 0 ;
}

extern int cmpbnames();

Visit()
{
/*    report("Visit") ;*/
    char ans[5];
    char bname[STRLEN];
    struct fileheader fh;
    clr() ;
    refresh() ;
    move(0,0);
    uinfo.mode = VISIT;
    substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
    prints("Visit Board(s)\n");
    move(1,0);
    getdata(1,0,"(A)ll boards, (1) board, or (Q)uit? [Q]: ",ans,5,DOECHO,NULL);
    move(1,0);
    clrtoeol();
    switch(ans[0]) {
	case 'A': case 'a': apply_boards(visit_boards);
	  break;
	case '1': make_blist();
	  prints("Select board: ");
	  namecomplete((char *)NULL, bname);
	  move(5,0);
	  if (*bname == '\0' ||
	    !search_record(BOARDS, &fh, sizeof(fh), cmpbnames, (int)bname)) {
		prints("Invalid board name.\n");
		break;
	  }
	  visit_boards(&fh);
	  prints("..done!\n");
	  break;
	default: move(5,0);
	  prints("Visit aborted.\n");
    }
    pressreturn() ;
    clr() ;
    uinfo.mode = MMENU;
    substitute_record(ULIST, &uinfo, sizeof(uinfo), utmpent);
    return -1 ;
}

chkmail()
{
    static long lasttime = 0;
    static ismail = 0 ;
    struct stat st ;
    int fd ;
    register int i, offset ;
    register long numfiles ;
    unsigned char ch ;
    extern char currmaildir[4096] ;

    offset = ((int)&(fh.accessed[0]) - (int)&(fh)) ;
    if((fd = open(currmaildir,O_RDONLY)) < 0)
      return (ismail = 0) ;
    fstat(fd,&st) ;
    if(lasttime >= st.st_mtime) {
        close(fd) ;
        return ismail ;
    }
    lasttime = st.st_mtime ;
    numfiles = st.st_size ;
    numfiles = numfiles/sizeof(fh) ;
    if(numfiles <= 0) {
      close(fd) ;
      return (ismail = 0) ;
    }
    lseek(fd,offset,L_SET) ;
    for(i = 0 ; i < numfiles ; i++,lseek(fd,offset+i*sizeof(fh),L_SET)) {
        read(fd,&ch,1) ;
        if(!(ch & FILE_READ)) {
            close(fd) ;
            return(ismail = 1) ;
        }
    }
    close(fd) ;
    return(ismail = 0) ;
}

int
getnewuserid()
{
    int fd ;
    int i ;
    struct userec utmp ;

    if((fd = open(PASSFILE,O_RDWR|O_CREAT,0600)) == -1) {
        perror("open") ;
        return -1 ;
    }
    flock(fd,LOCK_EX) ;
    i = 0 ;
    while(read(fd,&utmp,sizeof(utmp)) == sizeof(utmp)) {
        if(utmp.userid[0] == '\0')
            break ;
        i++ ;
    }
    if(i >= MAXUSERS) {
      flock(fd, LOCK_UN);
      return -1 ;
    }
    strcpy(utmp.userid,"new") ;
    if(lseek(fd,sizeof(utmp)*i,L_SET) == -1) {
        flock(fd,LOCK_UN) ;
        close(fd) ;
        return -1 ;
    }
    write(fd,&utmp,sizeof(utmp)) ;
    flock(fd,LOCK_UN) ;
    close(fd) ;
    return i+1 ;
}

int
getnewutmpent(up)
struct user_info *up ;
{
    int fd ;
    int i ;
    struct user_info utmp ;

    if((fd = open(ULIST,O_RDWR|O_CREAT,0600)) == -1) {
        perror("open") ;
        return -1 ;
    }
    flock(fd,LOCK_EX) ;
    i = 0 ;
    while(read(fd,&utmp,sizeof(utmp)) == sizeof(utmp)) {
        if(!utmp.active || !utmp.pid)
          break ;
        if(kill(utmp.pid,0) == -1)
          break ;
        i++ ;
    }
    if(lseek(fd,sizeof(utmp)*i,L_SET) == -1) {
        flock(fd,LOCK_UN) ;
        close(fd) ;
        return -1 ;
    }
    write(fd,up,sizeof(utmp)) ;
    flock(fd,LOCK_UN) ;
    close(fd) ;
    return i+1 ;
}


unsigned char uarray[MAXUSERS] ;

genuarray(s)
char *s ;
{
    int id ;

    if(*s == '*')
      return 0 ;
    if(!(id = searchuser(s)))
      return 0 ;
    uarray[id] = 1 ;
    return 0 ;
}

mass_delete(fptr)
struct fileheader *fptr ;
{
    register int i,j, offset ;
    register long numfiles ;
    int fd ;
    unsigned char ch ;
    struct stat st ;

    offset = ((int)&(fh.accessed[usernum]) - (int)&(fh)) ;
    sprintf(genbuf,"boards/%s/%s",fptr->filename,DIR) ;
    if((fd = open(genbuf, O_RDWR)) < 0)
      return 0 ;
    fstat(fd,&st) ;
    numfiles = st.st_size ;
    numfiles = numfiles/sizeof(fh) ;
    if(numfiles <= 0) {
        close(fd) ;
        return 0 ;
    }
    ch = 0 ;
    flock(fd, LOCK_EX);
    for(i=0; i < numfiles; i++) {
        for(j=0; j<MAXUSERS; j++) {
            if(uarray[j]) {
                offset = ((int)&(fh.accessed[j]) - (int)&(fh)) ;
                lseek(fd,offset+i*sizeof(fh),L_SET) ;
                write(fd,&ch,1) ;
            }
        }
    }
    flock(fd, LOCK_UN);
    close(fd) ;
    return 0 ;
}

mass_delmail(s)
char *s ;
{
    struct stat st ;
    
    if(*s == '*')
      return 0 ;
    if(*s == '\0')
      return 0 ;
    if (!isalpha(s[0])) return -1;   /* rrr - extra precaution */
    sprintf(genbuf,"mail/%s",s) ;
    if(stat(genbuf,&st) < 0)
      return 0 ;
    sprintf(genbuf,"/bin/rm -fr mail/%s signatures/%s plans/%s overrides/%s",s, s, s, s) ;
    system(genbuf) ;

    return 0 ;
}
    
mass_delusers(s)
char *s ;
{
    int id ;

    if(*s == '*')
      return 0 ;
    if(!(id = searchuser(s)))
      return 0 ;
    substitute_record(PASSFILE,&lookupuser,sizeof(lookupuser),id) ;
    return 0 ;
}

newclean(s,id)
char *s ;
{
    if(strcmp(s,"new"))
      return 0 ;
    substitute_record(PASSFILE,&lookupuser,sizeof(lookupuser),id) ;
    return 0 ;
}


fastdelete()
{
    bzero(uarray,sizeof(uarray)) ;
    ApplyToNameList(genuarray) ;
    prints("Begin Delete...\n") ;
    refresh() ;
    apply_boards(mass_delete) ;
    prints("Users files Info Deleted....\n") ;
    refresh() ;
    ApplyToNameList(mass_delmail) ;
    prints("Mail Queues Cleaned....\n") ;
    refresh() ;
    bzero(&lookupuser,sizeof(lookupuser)) ;
    ApplyToNameList(mass_delusers) ;
    prints("Users Cleaned....\n") ;
    refresh() ;
    apply_users(newclean) ;
    truncate(PASSFILE,MAXUSERS*sizeof(lookupuser)) ;
    prints("Mass delete complete.\n") ;
    refresh() ;
    touchnew() ;
}

#if CLIX           /* CLIX libc has no truncate */

truncate(path, sz)
char *path;
int sz;
{
    int rc;
    int fd = open(path, O_RDWR);
    if (fd == -1) return -1;
    rc = ftruncate(fd, sz);
    close(fd);
    return rc;
}

#endif


/*
   These are the 16 basic permission bits. 
   All but the last one are used in comm_lists.c and help.c to control user 
   access to priviliged functions. The symbolic names are given to roughly
   correspond to their actual usage; feel free to use them for different
   purposes though. The PERM_SPECIAL1 and PERM_SPECIAL2 are not used by 
   default and you can use them to set up restricted boards or chat rooms.
*/

#define	PERM_BASIC	000001
#define PERM_CHAT	000002
#define	PERM_PAGE	000004
#define PERM_POST	000010
#define	PERM_SPECIAL1	000020
#define PERM_SPECIAL2	000040
#define PERM_CLOAK	000100
#define PERM_SEECLOAK	000200
#define PERM_UPLOAD	000400
#define PERM_WELCOME	001000
#define PERM_BOARDS	002000
#define PERM_ACCOUNTS	004000
#define PERM_CHATCLOAK	010000
#define	PERM_OVOTE	020000
#define PERM_SYSOP	040000
#define PERM_POSTMASK	0100000     /* means the rest is a post mask */

/* This is the default permission granted to all new accounts. */
#define PERM_DEFAULT 	(PERM_BASIC | PERM_CHAT | PERM_PAGE | PERM_POST)

/* These permissions are bitwise ORs of the basic bits. They work that way
   too. For example, anyone with PERM_SYSOP or PERM_BOARDS or both has
   PERM_SEEBLEVELS. */

#define PERM_ADMINMENU	(PERM_ACCOUNTS | PERM_BOARDS | PERM_OVOTE | PERM_SYSOP)
#define PERM_MULTILOG	PERM_SYSOP
#define PERM_LOGINCLOAK	(PERM_SYSOP | PERM_ACCOUNTS | PERM_BOARDS | PERM_WELCOME)
#define PERM_SEEULEVELS PERM_SYSOP
#define PERM_SEEBLEVELS (PERM_SYSOP | PERM_BOARDS)
#define PERM_MARKPOST   (PERM_SYSOP | PERM_BOARDS)
#define PERM_UCLEAN	(PERM_SYSOP | PERM_ACCOUNTS)
#define PERM_NOTIMEOUT  PERM_SYSOP

#define PERM_SENDMAIL	0
#define PERM_READMAIL	PERM_BASIC
#define PERM_VOTE	PERM_BASIC

/* These are used only in Internet Mail Forwarding */
/* You may want to be more restrictive than the default, especially for an
   open access BBS. */

#define PERM_SETADDR	PERM_BASIC     /* to set address for forwarding */
#define PERM_FORWARD	PERM_BASIC     /* to do the forwarding */

/* Don't mess with this. */
#define HAS_PERM(x)	((x)?currentuser.userlevel&(x):1)

#ifndef EXTERN
extern char *permstrings[];
#else

#define NUMPERMS 15
/* You might want to put more descriptive strings for SPECIAL1 and SPECIAL2
   depending on how/if you use them. */
char *permstrings[] = {
	"Basic permissions",	/* PERM_BASIC */
	"Chat", 		/* PERM_CHAT */
	"Page",			/* PERM_PAGE */
	"Post",			/* PERM_POST */
	"Special 1",		/* PERM_SPECIAL1 */
	"Special 2",		/* PERM_SPECIAL2 */
	"Cloak",		/* PERM_CLOAK */
	"See cloaked",		/* PERM_SEECLOAK */
	"Upload files",		/* PERM_UPLOAD */
	"Edit Welcome",		/* PERM_WELCOME */
	"Board Manager",	/* PERM_BOARDS */
	"Account Manager",	/* PERM_ACCOUNTS */
	"Cloak in chat",	/* PERM_CHATCLOAK */
	"Vote manager",		/* PERM_OVOTE */
	"Sysop"			/* PERM_SYSOP */
};
#endif

/*
    Pirate Bulletin Board System
    Copyright (C) 1990, Edward Luke, lush@Athena.EE.MsState.EDU
    Eagles Bulletin Board System
    Copyright (C) 1992, Raymond Rocker, rocker@rock.b11.ingr.com
                        Guy Vega, gtvega@seabass.st.usm.edu
                        Dominic Tynes, dbtynes@seabass.st.usm.edu

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "bbs.h"
#include <sys/param.h>
extern char *getenv();

#if defined(IRIX) || defined(AIX) || defined(AUX)
#define vfork fork
#endif

pressreturn()
{
    char buf[2] ;
    getdata(t_lines-1,0,"Press [RETURN] to continue",buf,2,NOECHO,NULL) ;
    move(t_lines-1,0) ;
    clrtoeol() ;
    refresh() ;
    return 0 ;
}

dumbreturn()
{
	char ch ;
	prints("Press [RETURN] to continue") ;
	while((ch = igetch()) != EOF)
	  if(ch == '\n' || ch == '\r')
		break ;
}

bell()
{
    fprintf(stderr,"%c",CTRL('G')) ;
}

Getyn(s)
char *s ;
{
	CreateNameList() ;
	AddNameList("Yes") ;
	AddNameList("No") ;
	namecomplete("(Yes or No): ",s) ;
}

touchnew()
{
    int fd ;
    if((fd = open(FLUSH,O_WRONLY|O_CREAT,0644)) == -1)
      return ;
    write(fd,"NEW\n",4) ;
    close(fd) ;
}


/* rrr - Snagged from pbbs 1.8 */

#define LOOKFIRST  (0)
#define LOOKLAST   (1)
#define QUOTEMODE  (2)
#define MAXCOMSZ (1024)
#define MAXARGS (40)
#define MAXENVS (20)
#define BINDIR "bin/"

char *bbsenv[MAXENVS] ;
int numbbsenvs = 0 ;

/* Case Independent strncmp */

int
ci_strncmp(s1,s2,n)
register char *s1,*s2 ;
register int n ;
{
    for(;n;s1++,s2++,n--) {
        if(*s1=='\0' && *s2 == '\0')
          break ;
        if((isalpha(*s1)?*s1|0x20:*s1) != (isalpha(*s2)?*s2|0x20:*s2))
          return YEA ;
    }
    return NA ;
}

bbssetenv(env,val)
char *env, *val ;
{
    register int i,len ;
    extern char *malloc() ;

    if(numbbsenvs == 0)
      bbsenv[0] = NULL ;
    len = strlen(env) ;
    for(i=0;bbsenv[i];i++)
      if(!ci_strncmp(env,bbsenv[i],len))
        break ;
    if(i>=MAXENVS)
      return -1 ;
    if(bbsenv[i])
      free(bbsenv[i]) ;
    else
      bbsenv[++numbbsenvs] = NULL ;
    bbsenv[i] = malloc(strlen(env)+strlen(val)+2) ;
    strcpy(bbsenv[i],env) ;
    strcat(bbsenv[i],"=") ;
    strcat(bbsenv[i],val) ;
}

do_exec(com,wd)
char *com, *wd ;
{
    char path[MAXPATHLEN] ;
    char pcom[MAXCOMSZ] ;
    char *arglist[MAXARGS] ;
    char *tz;
    register int i,len ;
    register int argptr ;
    register char *lparse ;
    int status, pid, w ;
    int pmode ;
    void (*isig)(), (*qsig)() ;

    strncpy(path,BINDIR,MAXPATHLEN) ;
    strncpy(pcom,com,MAXCOMSZ) ;
    len = MIN(strlen(com)+1,MAXCOMSZ) ;
    pmode = LOOKFIRST ;
    for(i=0,argptr=0;i<len;i++) {
        if(pcom[i] == '\0')
          break ;
        if(pmode == QUOTEMODE) {
            if(pcom[i] == '\001') {
                pmode = LOOKFIRST ;
                pcom[i] = '\0' ;
                continue ;
            }
            continue ;
        }
        if(pcom[i] == '\001') {
            pmode = QUOTEMODE ;
            arglist[argptr++] = &pcom[i+1] ;
            if(argptr+1 == MAXARGS)
              break ;
            continue ;
        }
        if(pmode == LOOKFIRST)
          if(pcom[i] != ' ') {
              arglist[argptr++] = &pcom[i] ;
              if(argptr+1 == MAXARGS)
                break ;
              pmode = LOOKLAST ;
          } else continue ;
        if(pcom[i] == ' ') {
            pmode = LOOKFIRST ;
            pcom[i] = '\0' ;
        }
    }
    arglist[argptr] = NULL ;
    if(argptr == 0)
      return -1 ;
    if(*arglist[0] == '/')
      strncpy(path,arglist[0],MAXPATHLEN) ;
    else
      strncat(path,arglist[0],MAXPATHLEN) ;
    reset_tty() ;
    alarm(0) ;
    if((pid = vfork()) == 0) {
        if(wd)
          if(chdir(wd)) {
              fprintf(stderr,"Unable to chdir to '%s'\n",wd) ;
              exit(-1) ;
          }
	bbssetenv("PATH", "/bin:.");
	bbssetenv("TERM", currentuser.termtype);
	bbssetenv("USER", currentuser.userid);
	bbssetenv("USERNAME", currentuser.username);
	if ((tz = getenv("TZ")) != NULL)
          bbssetenv("TZ", tz);	
        if(numbbsenvs == 0)
          bbsenv[0] = NULL ;
        execve(path,arglist,bbsenv) ;
        fprintf(stderr,"EXECV FAILED... path = '%s'\n",path) ;
        exit(-1) ;
    }
    isig = signal(SIGINT, SIG_IGN) ;
    qsig = signal(SIGQUIT, SIG_IGN) ;
    while((w = wait(&status)) != pid && w != 1)
      /* NULL STATEMENT */ ;
    signal(SIGINT, isig) ;
    signal(SIGQUIT, qsig) ;
    restore_tty() ;
#ifdef DOTIMEOUT
    alarm(IDLE_TIMEOUT) ; 
#endif
    return((w == -1)? w: status) ;
}


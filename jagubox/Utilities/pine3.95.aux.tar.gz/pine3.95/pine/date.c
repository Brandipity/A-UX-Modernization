char datestamp[]="Sun Sep 15 14:59:58 CDT 1996";
char hoststamp[]="uro";
